import { CBTQuestion, ModuleId } from '../types/cardio';

// Medical Scenario Seed Database & Templates for 12,000 Questions
interface ScenarioTemplate {
  moduleId: ModuleId;
  moduleName: string;
  skdiLevel: 'SKDI 1' | 'SKDI 2' | 'SKDI 3A' | 'SKDI 3B' | 'SKDI 4A';
  difficulty: 'Mudah' | 'Sedang' | 'Sulit';
  ageRanges: [number, number];
  genders: ('Laki-laki' | 'Perempuan')[];
  chiefComplaints: string[];
  historyVariations: string[];
  vitalsGenerator: (seed: number) => {
    bp: string;
    hr: string;
    rr: string;
    temp: string;
    cardiacFindings: string;
    otherFindings: string;
  };
  diagnosticTestsGenerator: (seed: number) => string;
  prompt: string;
  optionsGenerator: (seed: number) => {
    options: { label: 'A' | 'B' | 'C' | 'D' | 'E'; text: string }[];
    correctIndex: number;
    explanation: {
      coreConcept: string;
      rationaleCorrect: string;
      rationaleIncorrect: Record<string, string>;
      clinicalTakeaway: string;
    };
  };
}

const TEMPLATES: ScenarioTemplate[] = [
  // 1. ANATOMI: Oklusi Koroner & Lokalisasi Infark
  {
    moduleId: 'anatomi',
    moduleName: 'Anatomi Sistem Kardiovaskular',
    skdiLevel: 'SKDI 4A',
    difficulty: 'Sedang',
    ageRanges: [45, 68],
    genders: ['Laki-laki', 'Perempuan'],
    chiefComplaints: [
      'Nyeri dada retrosternal seperti tertindih beban berat menjalar ke lengan kiri dan rahang',
      'Nyeri dada kiri substernal mendadak tembus ke punggung disertai keringat dingin',
      'Rasa tertekan di dada anterior saat istirahat tidak mereda dengan istirahat'
    ],
    historyVariations: [
      'Pasien memiliki riwayat perokok aktif 20 tahun dan dislipidemia tidak terkontrol.',
      'Pasien menderita diabetes melitus tipe 2 dan hipertensi stadium II selama 8 tahun.',
      'Pasien mengeluhkan keluhan bertambah berat dalam 2 jam terakhir disertai rasa mual.'
    ],
    vitalsGenerator: (seed) => ({
      bp: `${100 + (seed % 35)}/${65 + (seed % 20)} mmHg`,
      hr: `${75 + (seed % 30)} x/menit, regular`,
      rr: `${20 + (seed % 6)} x/menit`,
      temp: '36.8°C',
      cardiacFindings: 'Bunyi jantung S1 dan S2 terdengar reguler, tidak ada bising katup, terdengar S4 gallop samar di apeks',
      otherFindings: 'Ekstremitas akral hangat, CRT < 2 detik, diaforesis (+)'
    }),
    diagnosticTestsGenerator: (seed) => {
      const types = [
        'EKG 12-sadapan: Elevasi segmen ST setinggi 3.5 mm pada sadapan V1, V2, V3, dan V4 dengan reciprocal ST depresi di II, III, aVF.',
        'EKG 12-sadapan: Elevasi segmen ST setinggi 2.5 mm pada sadapan II, III, dan aVF disertai reciprocal ST depresi di I dan aVL.',
        'EKG 12-sadapan: Elevasi segmen ST pada sadapan I, aVL, V5, dan V6 disertai depresi ST di V1-V2.'
      ];
      return types[seed % types.length];
    },
    prompt: 'Berdasarkan temuan elektrokardiogram dan korelasi vaskularisasi anatomis, pembuluh darah koroner manakah yang paling mungkin mengalami oklusi akut?',
    optionsGenerator: (seed) => {
      const variant = seed % 3;
      if (variant === 0) {
        return {
          options: [
            { label: 'A', text: 'Ramus Interventricularis Anterior (Left Anterior Descending Artery)' },
            { label: 'B', text: 'Arteria Coronaria Dextra (Right Coronary Artery)' },
            { label: 'C', text: 'Ramus Circumflexus (Left Circumflex Artery)' },
            { label: 'D', text: 'Arteria Marginalis Dextra' },
            { label: 'E', text: 'Ramus Interventricularis Posterior (Posterior Descending Artery)' }
          ],
          correctIndex: 0,
          explanation: {
            coreConcept: 'Anatomi vaskularisasi arteri koroner pada sadapan anteroseptal EKG.',
            rationaleCorrect: 'Elevasi segmen ST pada sadapan V1-V4 mencerminkan infark miokard anterior-septal. Area dinding anterior ventrikel kiri dan dua pertiga anterior septum interventrikularis divaskularisasi oleh Ramus Interventricularis Anterior (LAD) yang merupakan cabang utama Arteria Coronaria Sinistra.',
            rationaleIncorrect: {
              B: 'RCA mensuplai dinding inferior (sadapan II, III, aVF), bukan anteroseptal.',
              C: 'LCx mensuplai dinding lateral ventrikel kiri (sadapan I, aVL, V5, V6).',
              D: 'A. marginalis dextra mensuplai dinding ventrikel kanan.',
              E: 'PDA mensuplai dinding posterior dan sepertiga posterior septum.'
            },
            clinicalTakeaway: 'LAD adalah cabang koroner yang paling sering terlibat pada infark miokard anteroseptal dengan risiko disfungsi sistolik LV yang signifikan.'
          }
        };
      } else if (variant === 1) {
        return {
          options: [
            { label: 'A', text: 'Ramus Interventricularis Posterior dari RCA (Arteria Coronaria Dextra)' },
            { label: 'B', text: 'Left Anterior Descending Artery (LAD)' },
            { label: 'C', text: 'Arteria Subclavia Sinistra' },
            { label: 'D', text: 'Ramus Diagonalis Sinistra' },
            { label: 'E', text: 'Vena Cordis Magna' }
          ],
          correctIndex: 0,
          explanation: {
            coreConcept: 'Anatomi vaskularisasi dinding inferior ventrikel kiri oleh RCA.',
            rationaleCorrect: 'Sadapan II, III, dan aVF merepresentasikan fasad inferior (diafragmatika) ventrikel. Pada sekitar 85-90% populasi (right-dominant), dinding inferior dan nodus AV disuplai oleh Arteria Coronaria Dextra (RCA) melalui cabangnya Posterior Descending Artery (PDA).',
            rationaleIncorrect: {
              B: 'LAD mensuplai dinding anterior dan apeks jantung (V1-V4).',
              C: 'A. subclavia bukan arteri penyuplai miokardium langsung.',
              D: 'Ramus diagonalis mencabangkan vaskularisasi dinding anterolateral LV.',
              E: 'Vena cordis magna adalah pembuluh balik vena, bukan arteri penyuplai.'
            },
            clinicalTakeaway: 'Infark inferior berkaitan erat dengan oklusi RCA; selalu waspadai keterlibatan infark ventrikel kanan dan gangguan konduksi nodus AV.'
          }
        };
      } else {
        return {
          options: [
            { label: 'A', text: 'Ramus Circumflexus (Left Circumflex Artery / LCx)' },
            { label: 'B', text: 'Arteria Coronaria Dextra (RCA)' },
            { label: 'C', text: 'Ramus Coni Arteriosi' },
            { label: 'D', text: 'Arteria Mammaria Interna' },
            { label: 'E', text: 'Sinus Coronarius' }
          ],
          correctIndex: 0,
          explanation: {
            coreConcept: 'Anatomi vaskularisasi dinding lateral ventrikel kiri oleh LCx.',
            rationaleCorrect: 'Sadapan I, aVL, V5, dan V6 merekam kelistrikan dinding lateral ventrikel kiri yang mendapat perfusi utama dari Ramus Circumflexus (LCx) yang berjalan di dalam sulcus coronarius sinistra.',
            rationaleIncorrect: {
              B: 'RCA mensuplai dinding inferior dan ventrikel kanan.',
              C: 'Ramus coni arteriosi mensuplai konus pulmonal.',
              D: 'A. mammaria interna adalah graft bedah CABG, bukan arteri koroner natif.',
              E: 'Sinus coronarius adalah pembuluh balik vena utama jantung.'
            },
            clinicalTakeaway: 'Infark lateral tinggi dan lateral rendah dikaitkan dengan lesi pada arteri sirkumfleksa kiri.'
          }
        };
      }
    }
  },

  // 2. FISIOLOGI: Fase Siklus Jantung & Wiggers Diagram
  {
    moduleId: 'fisiologi',
    moduleName: 'Fisiologi Sistem Kardiovaskular',
    skdiLevel: 'SKDI 4A',
    difficulty: 'Sedang',
    ageRanges: [20, 55],
    genders: ['Laki-laki', 'Perempuan'],
    chiefComplaints: [
      'Evaluasi hasil pemeriksaan fonokardiogram dan siklus hemodinamik jantung',
      'Pemeriksaan fisiologis kardiovaskular pada atlet maraton saat uji latih beban',
      'Analisis kurva tekanan ventrikel dan bunyi jantung pada mahasiswa kedokteran'
    ],
    historyVariations: [
      'Pemeriksaan hemodinamik non-invasif menunjukkan fungsi ventrikel normal dengan Ejection Fraction 65%.',
      'Pemeriksaan auskultasi menemukan pemisahan bunyi jantung S2 yang melebar secara fisiologis saat fase inspirasi.',
      'Pemeriksaan tekanan intrakardiak mencatat tekanan akhir diastolik ventrikel kiri (LVEDP) sebesar 8 mmHg.'
    ],
    vitalsGenerator: (seed) => ({
      bp: `${115 + (seed % 15)}/${75 + (seed % 10)} mmHg`,
      hr: `${60 + (seed % 25)} x/menit, regular`,
      rr: '16 x/menit',
      temp: '36.6°C',
      cardiacFindings: 'Bunyi jantung S1 tunggal di apeks, bunyi jantung S2 terdengar fisiologis splitting saat inspirasi di area pulmonal',
      otherFindings: 'Pulsasi perifer teraba kuat, simetris, tidak ada bising karotis'
    }),
    diagnosticTestsGenerator: (seed) => {
      const tests = [
        'Diagram Wiggers: Terjadi peningkatan mendadak tekanan ventrikel kiri dari 8 mmHg ke 82 mmHg tanpa adanya perubahan volume darah ventrikel (volume tetap pada 125 mL).',
        'Fonokardiogram: Terekam vibrasi frekuensi tinggi bertepatan dengan titik penutupan katup semilunar aorta dan pulmonal serta insisura dikrotik.',
        'Kurva Tekanan-Volume: Titik di mana katup mitral baru saja menutup dan katup aorta belum terbuka.'
      ];
      return tests[seed % tests.length];
    },
    prompt: 'Fase siklus jantung manakah yang secara tepat menggambarkan peristiwa biofisika tersebut?',
    optionsGenerator: (seed) => {
      const variant = seed % 3;
      if (variant === 0 || variant === 2) {
        return {
          options: [
            { label: 'A', text: 'Kontraksi Isovolumetrik (Isovolumetric Contraction)' },
            { label: 'B', text: 'Ejeksi Cepat (Rapid Ejection)' },
            { label: 'C', text: 'Relaksasi Isovolumetrik (Isovolumetric Relaxation)' },
            { label: 'D', text: 'Pengisian Cepat Ventrikel (Rapid Inflow)' },
            { label: 'E', text: 'Sistol Atrium (Atrial Systole)' }
          ],
          correctIndex: 0,
          explanation: {
            coreConcept: 'Fase Kontraksi Isovolumetrik pada Siklus Jantung Wiggers.',
            rationaleCorrect: 'Fase kontraksi isovolumetrik terjadi segera setelah katup mitral tertutup (S1) dan berakhir saat katup aorta terbuka. Pada fase ini, semua katup tertutup sehingga volume darah di dalam ventrikel konstan (EDV), namun tegangan miokardium meningkat tajam sehingga tekanan melonjak melampaui tekanan diastolik aorta.',
            rationaleIncorrect: {
              B: 'Pada ejeksi cepat, katup aorta telah terbuka dan volume ventrikel menurun drastis.',
              C: 'Pada relaksasi isovolumetrik, tekanan ventrikel turun tajam saat diastol setelah katup aorta menutup.',
              D: 'Pengisian cepat terjadi saat katup mitral terbuka dan volume ventrikel bertambah cepat.',
              E: 'Sistol atrium terjadi di akhir diastol dan menyumbang 15-20% volume pengisian ventrikel.'
            },
            clinicalTakeaway: 'Kontraksi isovolumetrik mengonsumsi energi metabolisme miokardium tertinggi per satuan waktu untuk membangun tekanan pembuka katup semilunar.'
          }
        };
      } else {
        return {
          options: [
            { label: 'A', text: 'Relaksasi Isovolumetrik (Isovolumetric Relaxation) bertepatan dengan S2' },
            { label: 'B', text: 'Kontraksi Isovolumetrik bertepatan dengan S1' },
            { label: 'C', text: 'Fase Ejeksi Lambat' },
            { label: 'D', text: 'Diastasis Pengisian Lambat' },
            { label: 'E', text: 'Fase Presistol Atrium' }
          ],
          correctIndex: 0,
          explanation: {
            coreConcept: 'Bunyi Jantung S2 dan Relaksasi Isovolumetrik.',
            rationaleCorrect: 'Bunyi jantung kedua (S2) dihasilkan oleh penutupan katup semilunar (aorta A2 dan pulmonal P2). Peristiwa ini menandai awal dari fase relaksasi isovolumetrik di mana ventrikel berelaksasi dengan semua katup tertutup sebelum katup AV terbuka.',
            rationaleIncorrect: {
              B: 'S1 bertepatan dengan penutupan katup atrioventrikular (mitral dan trikuspid).',
              C: 'Ejeksi lambat terjadi sebelum katup semilunar menutup.',
              D: 'Diastasis terjadi saat katup mitral terbuka di pertengahan diastol.',
              E: 'Presistol atrium menghasilkan gelombang a pada JVP dan dapat memicu S4 bila ventrikel kaku.'
            },
            clinicalTakeaway: 'Penutupan katup aorta menghasilkan insisura dikrotik pada kurva tekanan arteri sistemik akibat recoil elastis aorta.'
          }
        };
      }
    }
  },

  // 3. HISTOLOGI: Mikroarsitektur Kardiomiosit & Diskus Interkalaris
  {
    moduleId: 'histologi',
    moduleName: 'Histologi Sistem Kardiovaskular',
    skdiLevel: 'SKDI 4A',
    difficulty: 'Sulit',
    ageRanges: [25, 60],
    genders: ['Laki-laki', 'Perempuan'],
    chiefComplaints: [
      'Pemeriksaan biopsi endomiokardial untuk evaluasi kecurigaan displasia aritmogenik',
      'Analisis preparat histopatologis miokardium pada praktikum blok kardiovaskular',
      'Kajian mikroskop elektron transmisi pada spesimen otot jantung donor'
    ],
    historyVariations: [
      'Preparat histologi diwarnai Hematoksilin-Eosin (H&E) dan Mallory Trichrome menunjukkan sel-sel silindris bercabang.',
      'Pemeriksaan mikroskop elektron memperlihatkan taut interselular khusus berundak pada batas perlekatan antar sel miosit.',
      'Tampak struktur taut membran di mana komponen transversal mengikat filamen aktin dan komponen longitudinal memfasilitasi transmisi ion.'
    ],
    vitalsGenerator: () => ({
      bp: '120/80 mmHg',
      hr: '72 x/menit',
      rr: '18 x/menit',
      temp: '36.5°C',
      cardiacFindings: 'Struktur histologis kardiak normal, tidak tampak infiltrat radang sel mononuklear',
      otherFindings: 'Tampak granula pigmen lipofuscin perinuklear coklat-kekuningan'
    }),
    diagnosticTestsGenerator: () => 
      'Mikroskop elektron transmisi: Tampak regio taut seluler berundak (stepped structure). Regio longitudinal memperlihatkan struktur pori heksamerik protein connexin-43 yang menghubungkan sitoplasma kedua sel secara langsung.',
    prompt: 'Struktur taut interselular manakah yang dimaksud dan apakah fungsi biologis utamanya pada miokardium?',
    optionsGenerator: () => ({
      options: [
        { label: 'A', text: 'Gap Junction (Nexus); memfasilitasi kopling elektrik cepat sehingga miokardium berfungsi sebagai sinsitium' },
        { label: 'B', text: 'Fascia Adherens; menambatkan filamen intermediet keratin untuk mencegah deslokasi sel' },
        { label: 'C', text: 'Macula Adherens (Desmosom); menyalurkan influks kalsium ekstraselular ke retikulum sarkoplasma' },
        { label: 'D', text: 'Tight Junction (Zonula Occludens); membentuk sawar kedap air intraseluler' },
        { label: 'E', text: 'Hemidesmosom; menambatkan kardiomiosit ke lamina elastika interna' }
      ],
      correctIndex: 0,
      explanation: {
        coreConcept: 'Komponen Diskus Interkalaris: Gap Junction dan Sinsitium Fungsional.',
        rationaleCorrect: 'Pada diskus interkalaris, komponen longitudinal mengandung banyak Gap Junctions (nexus) yang dibentuk oleh protein connexin-43. Struktur ini menyediakan saluran konduktansi ionik beresistensi rendah, memungkinkan potensial aksi merambat secara instan dari satu kardiomiosit ke sel sebelahnya sehingga jantung berkontraksi sebagai satu kesatuan fungsional (functional syncytium).',
        rationaleIncorrect: {
          B: 'Fascia adherens terletak di komponen transversal dan menambatkan mikrofilamen aktin sarkomer, bukan filamen keratin.',
          C: 'Desmosom menambatkan filamen desmin untuk kekuatan mekanik, bukan saluran kalsium.',
          D: 'Zonula occludens merupakan ciri khas sel endotel sawar darah otak, bukan kardiomiosit.',
          E: 'Hemidesmosom menambatkan sel ke membrana basalis epitel.'
        },
        clinicalTakeaway: 'Kerusakan atau de-fosforilasi connexin-43 pada iskemia miokard memicu disosiasi konduksi elektrik dan sirkuit re-entry aritmia ventrikel.'
      }
    })
  },

  // 4. BIOKIMIA: Kinetika Biomarker Troponin & Peptida Natriuretik
  {
    moduleId: 'biokimia',
    moduleName: 'Biokimia Sistem Kardiovaskular',
    skdiLevel: 'SKDI 4A',
    difficulty: 'Sedang',
    ageRanges: [50, 72],
    genders: ['Laki-laki', 'Perempuan'],
    chiefComplaints: [
      'Nyeri dada tipikal dialami sejak 3 jam yang lalu sebelum masuk IGD rumah sakit',
      'Sesak napas progresif yang memberat saat berbaring dan pembengkakan kedua tungkai',
      'Evaluasi biomarker jantung serial pada pasien pasca-angioplasti koroner'
    ],
    historyVariations: [
      'Pasien memiliki riwayat dislipidemia dengan kadar LDL 195 mg/dL dan hipertensi.',
      'Pasien mengonsumsi obat gagal jantung rutin dan mengeluhkan batuk malam hari.',
      'Pemeriksaan laboratorium dilakukan pada jam ke-3 dan jam ke-6 setelah onset nyeri dada.'
    ],
    vitalsGenerator: (seed) => ({
      bp: `${135 + (seed % 30)}/${85 + (seed % 15)} mmHg`,
      hr: `${88 + (seed % 20)} x/menit`,
      rr: `${22 + (seed % 4)} x/menit`,
      temp: '37.0°C',
      cardiacFindings: 'S1 S2 reguler, terdengar suara S3 gallop di apeks kordis',
      otherFindings: 'Peningkatan tekanan vena jugularis R+3 cmH2O, edema pretibial bilateral (+)'
    }),
    diagnosticTestsGenerator: (seed) => {
      const tests = [
        'Laboratorium: High-sensitivity cardiac Troponin I (hs-cTnI) terukur 850 ng/L (nilai rujukan < 14 ng/L). CK-MB terukur 42 U/L. Serum laktat 2.8 mmol/L.',
        'Laboratorium: N-terminal pro-B-type Natriuretic Peptide (NT-proBNP) terukur 4,200 pg/mL (nilai batas usia 50-75 tahun > 900 pg/mL).',
        'Serial Enzim Jantung: Pada jam ke-3 hs-cTnT meningkat 5 kali lipat dari batas atas nilai normal dan mencapai puncaknya pada jam ke-24.'
      ];
      return tests[seed % tests.length];
    },
    prompt: 'Manakah pernyataan yang paling tepat mengenai biokimia molekuler dan kinetika pelepasan biomarker tersebut?',
    optionsGenerator: (seed) => {
      const variant = seed % 2;
      if (variant === 0) {
        return {
          options: [
            { label: 'A', text: 'Cardiac Troponin memiliki isoform asam amino spesifik miokardium yang mulai meningkat 2-4 jam pasca-cedera dan bertahan hingga 10-14 hari di sirkulasi' },
            { label: 'B', text: 'CK-MB lebih spesifik dibanding Troponin karena tidak pernah ditemukan di jaringan otot rangka' },
            { label: 'C', text: 'Myoglobin merupakan biomarker paling lambat meningkat dan bertahan paling lama di dalam darah' },
            { label: 'D', text: 'Troponin I dilepaskan secara eksklusif hanya jika terjadi ruptur plak aterosklerosis intraluminal' },
            { label: 'E', text: 'Peningkatan asam laktat kardiak menandakan dominasi metabolisme beta-oksidasi asam lemak di mitokondria' }
          ],
          correctIndex: 0,
          explanation: {
            coreConcept: 'Kinetika dan Spesifisitas Biomarker Cardiac Troponin (cTnI & cTnT).',
            rationaleCorrect: 'Cardiac Troponin I dan T memiliki sekuens asam amino yang berbeda dengan isoform otot rangka (dikode oleh gen TNNI3 dan TNNT2). Pada nekrosis miosit, troponin dilepaskan ke darah mulai 2-4 jam, memuncak pada 24 jam, dan tetap terdeteksi hingga 10-14 hari karena pelepasan bertahap dari aparatus miofilamen yang terdegradasi.',
            rationaleIncorrect: {
              B: 'CK-MB terdapat juga dalam jumlah kecil di otot rangka dan dapat meningkat pada rhabdomyolisis.',
              C: 'Myoglobin adalah biomarker paling cepat meningkat (1-2 jam) namun paling cepat hilang (dalam 24 jam).',
              D: 'Troponin dapat meningkat pada infark tipe 2 (sepsis, takiaritmia berat) tanpa ruptur plak.',
              E: 'Peningkatan laktat menandakan glikolisis anaerobik akibat hipoksia seluler, bukan beta-oksidasi.'
            },
            clinicalTakeaway: 'Troponin adalah gold standard nekrosis miokard, sementara CK-MB tetap berharga untuk mendeteksi re-infark dini dalam 48-72 jam.'
          }
        };
      } else {
        return {
          options: [
            { label: 'A', text: 'NT-proBNP dilepaskan oleh miosit ventrikel akibat peningkatan wall stress dan regangan dinding, memiliki waktu paruh lebih panjang daripada peptida aktif BNP' },
            { label: 'B', text: 'BNP disintesis dan disekresikan secara eksklusif hanya oleh sel endotel kapiler paru-paru' },
            { label: 'C', text: 'Pemberian obat golongan ARNI (Sacubitril) akan menurunkan kadar BNP darah secara drastis' },
            { label: 'D', text: 'BNP bekerja melalui aktivasi adenilat siklase untuk menurunkan kadar cGMP di otot polos pembuluh darah' },
            { label: 'E', text: 'NT-proBNP dimetabolisme dan dibersihkan dari plasma oleh enzim neprilisin' }
          ],
          correctIndex: 0,
          explanation: {
            coreConcept: 'Biokimia Peptida Natriuretik BNP dan NT-proBNP.',
            rationaleCorrect: 'ProBNP dipecah menjadi fragmen aktif BNP (32 asam amino) dan fragmen inaktif NT-proBNP (76 asam amino). NT-proBNP memiliki waktu paruh sirkulasi lebih panjang (~120 menit vs ~20 menit untuk BNP) dan dibersihkan terutama melalui filtrasi ginjal. Keduanya dilepaskan akibat regangan miokardium ventrikel (wall stress).',
            rationaleIncorrect: {
              B: 'BNP disintesis oleh kardiomiosit ventrikel, bukan endotel kapiler paru.',
              C: 'Sacubitril menghambat neprilisin sehingga justru meningkatkan kadar BNP darah.',
              D: 'BNP bekerja melalui reseptor NPR-A yang mengaktivasi guanylyl cyclase dan meningkatkan cGMP.',
              E: 'NT-proBNP bukan substrat neprilisin dan dibersihkan lewat ekskresi ginjal.'
            },
            clinicalTakeaway: 'Gunakan NT-proBNP untuk memantau status gagal jantung pada pasien yang sedang menerima terapi sacubitril/valsartan.'
          }
        };
      }
    }
  },

  // 5. EMBRIOLOGI: Looping & Septasi Jantung Janin
  {
    moduleId: 'embriologi',
    moduleName: 'Embriologi Sistem Kardiovaskular',
    skdiLevel: 'SKDI 3B',
    difficulty: 'Sulit',
    ageRanges: [0, 5],
    genders: ['Laki-laki', 'Perempuan'],
    chiefComplaints: [
      'Bayi baru lahir tampak sianosis sentral pada bibir dan ujung jari yang memberat saat menangis',
      'Anak usia 3 tahun sering berjongkok (squatting) setelah beraktivitas lari di taman bermain',
      'Bayi usia 2 bulan teraba murmur kontinu machinery like di infraklavikula sinistra'
    ],
    historyVariations: [
      'Ekokardiografi menunjukkan adanya defek septum ventrikel besar disertai overriding aorta dan stenosis infundibular pulmonal.',
      'Bayi lahir prematur pada usia kehamilan 32 minggu dengan respiratory distress syndrome.',
      'Pemeriksaan rontgen toraks memperlihatkan gambaran jantung berbentuk sepatu bot (boot-shaped heart).'
    ],
    vitalsGenerator: (seed) => ({
      bp: `${75 + (seed % 15)}/${45 + (seed % 10)} mmHg`,
      hr: `${135 + (seed % 25)} x/menit`,
      rr: `${45 + (seed % 10)} x/menit`,
      temp: '36.7°C',
      cardiacFindings: 'Terdengar bising ejeksi sistolik derajat 3/6 di sela iga II linea sternalis sinistra',
      otherFindings: 'Saturasi O2 perifer 76% pada udara ruangan, jari tabuh (clubbing fingers) minimal'
    }),
    diagnosticTestsGenerator: (seed) => {
      const tests = [
        'Ekokardiogram: Deviasi anterior dan sefalad dari septum infundibular/konotrunkal, menghasilkan 4 kelainan struktural simultan.',
        'Pemeriksaan Doppler: Terdeteksi aliran darah pirau kiri-ke-kanan melalui duktus arteriosus persisten antara aorta desendens dan percabangan arteria pulmonalis.',
        'Pemeriksaan Ultrasonografi: Terdapat defek ostium secundum pada fossa ovalis akibat resorpsi berlebihan septum primum.'
      ];
      return tests[seed % tests.length];
    },
    prompt: 'Apakah diagnosis klinis yang paling tepat dan mekanisme embriologis yang mendasarinya?',
    optionsGenerator: (seed) => {
      const variant = seed % 3;
      if (variant === 0) {
        return {
          options: [
            { label: 'A', text: 'Tetralogy of Fallot; akibat deviasi anterosuperior septum infundibular (konus) kardiak' },
            { label: 'B', text: 'Transposisi Arteri Besar (TGA); akibat kegagalan total pelipatan D-looping tabung jantung' },
            { label: 'C', text: 'Koarktasio Aorta; akibat hipertrofi berlebihan katup semilunar aorta' },
            { label: 'D', text: 'Defek Septum Atrium Tipe Primum; akibat kegagalan fusi bantalan endokardium inferior' },
            { label: 'E', text: 'Trunkus Arteriosus Persisten; akibat ketiadaan total sel mesoderm splanknik primer' }
          ],
          correctIndex: 0,
          explanation: {
            coreConcept: 'Embriogenesis Tetralogy of Fallot (TOF).',
            rationaleCorrect: 'Tetralogy of Fallot timbul akibat pergeseran abnormal (deviasi anterosuperior) dari septum infundibular/konotrunkal selama septasi outflow tract. Deviasi ini memicu empat anomali klasik: 1) Stenosis infundibulum pulmonal, 2) Defek Septum Ventrikel (VSD), 3) Overriding Aorta, dan 4) Hipertrofi Ventrikel Kanan (RVH).',
            rationaleIncorrect: {
              B: 'TGA disebabkan kegagalan rotasi spiral 180 derajat septum aortikopulmonal, bukan deviasi septum konus.',
              C: 'Koarktasio aorta berhubungan dengan penyempitan lumen aorta dekat insersi duktus arteriosus.',
              D: 'ASD primum merupakan bagian dari defek bantalan endokardium (AV canal defect).',
              E: 'Trunkus arteriosus persisten timbul akibat ketiadaan pembentukan sekat spiral oleh krista neuralis.'
            },
            clinicalTakeaway: 'Derajat stenosis pulmonal menentukan arah pirau (shunt) dan tingkat keparahan sianosis pada pasien Tetralogy of Fallot.'
          }
        };
      } else if (variant === 1) {
        return {
          options: [
            { label: 'A', text: 'Patent Ductus Arteriosus (PDA); kegagalan penutupan fungsional derivat arkus faring ke-6 sinistra' },
            { label: 'B', text: 'Persistent Truncus Arteriosus; defek migrasi sel krista neuralis cranial' },
            { label: 'C', text: 'Koarktasio Aorta Pre-duktal; regresi arkus aorta ke-4' },
            { label: 'D', text: 'Ventricular Septal Defect membranasea' },
            { label: 'E', text: 'Anomali Ebstein katup trikuspid' }
          ],
          correctIndex: 0,
          explanation: {
            coreConcept: 'Embriologi Duktus Arteriosus dari Arkus Faring ke-6.',
            rationaleCorrect: 'Duktus arteriosus merupakan derivat dari arkus faringeal ke-6 sinistra. Pada janin, struktur ini mengalirkan darah dari arteri pulmonalis ke aorta. Kegagalan konstriksi otot polos pasca-lahir (sering pada prematuritas akibat hipoksia atau persistensi PGE2) menghasilkan PDA dengan bising kontinu machinery murmur.',
            rationaleIncorrect: {
              B: 'Persistent truncus menghasilkan satu pembuluh arteri tunggal tanpa pemisahan aorta dan a. pulmonalis.',
              C: 'Koarktasio menimbulkan perbedaan tekanan darah ekstremitas atas dan bawah.',
              D: 'VSD membranasea menghasilkan murmur pansistolik di LSB, bukan murmur kontinu.',
              E: 'Anomali Ebstein adalah pergeseran kuspis katup trikuspid ke arah apikal ventrikel kanan.'
            },
            clinicalTakeaway: 'Indometasin atau Ibuprofen (inhibitor sintesis prostaglandin) diberikan untuk menutup PDA pada bayi prematur.'
          }
        };
      } else {
        return {
          options: [
            { label: 'A', text: 'Atrial Septal Defect (ASD) Tipe Secundum; akibat resorpsi berlebihan septum primum atau defisiensi septum secundum' },
            { label: 'B', text: 'ASD Tipe Primum; akibat kegagalan fusi katup vena kava inferior' },
            { label: 'C', text: 'Sinus Venosus Defect; anomali insersi vena kava superior' },
            { label: 'D', text: 'Patent Foramen Ovale tanpa defek struktural' },
            { label: 'E', text: 'Ventricular Septal Defect pars muskularis' }
          ],
          correctIndex: 0,
          explanation: {
            coreConcept: 'Embriogenesis Septum Interatriale dan Defek Secundum.',
            rationaleCorrect: 'ASD tipe sekundum merupakan 80% dari seluruh defek septum atrium. Defek ini timbul di regio fossa ovalis karena fenestrasi/resorpsi berlebihan pada septum primum sebelum foramen ovale tertutup, atau pembentukan septum sekundum yang tidak sempurna, meninggalkan defek pirau kiri-ke-kanan.',
            rationaleIncorrect: {
              B: 'ASD primum terletak di bagian bawah septum dekat katup AV dan berasal dari defek bantalan endokardium.',
              C: 'Sinus venosus defect terletak di dekat muara VCS atau VCI.',
              D: 'PFO adalah kegagalan fusi flap katup tanpa defek jaringan septum yang sebenarnya.',
              E: 'VSD muskularis melibatkan septum interventrikularis, bukan interatrial.'
            },
            clinicalTakeaway: 'ASD sekundum ditandai dengan fixed wide splitting S2 dan bising ejeksi sistolik pulmonal akibat hipervolume sirkulasi paru.'
          }
        };
      }
    }
  },

  // 6. PENYAKIT & PATOLOGI: Sindrom Koroner Akut & Gagal Jantung GDMT
  {
    moduleId: 'penyakit',
    moduleName: 'Penyakit Terkait Sistem Kardiovaskular',
    skdiLevel: 'SKDI 4A',
    difficulty: 'Sedang',
    ageRanges: [48, 75],
    genders: ['Laki-laki', 'Perempuan'],
    chiefComplaints: [
      'Nyeri dada kiri seperti tertindih beban berat tembus ke punggung berlangsung 45 menit tidak membaik dengan istirahat',
      'Sesak napas bertambah berat saat tidur rata, terbangun malam hari karena sesak (PND), dan bengkak kedua pergelangan kaki',
      'Denyut jantung berdebar-debar cepat dan tidak teratur disertai pusing melayang sejak 6 jam yang lalu'
    ],
    historyVariations: [
      'Pasien memiliki riwayat hipertensi 10 tahun dan riwayat konsumsi rokok 1 bungkus per hari.',
      'Pasien memiliki riwayat serangan jantung 1 tahun lalu dengan fraksi ejeksi ventrikel kiri (LVEF) 32%.',
      'Pasien tidak pernah minum obat pengencer darah dan memiliki riwayat stroke iskemik 2 tahun lalu.'
    ],
    vitalsGenerator: (seed) => ({
      bp: `${95 + (seed % 40)}/${60 + (seed % 20)} mmHg`,
      hr: `${90 + (seed % 35)} x/menit`,
      rr: `${24 + (seed % 6)} x/menit`,
      temp: '36.9°C',
      cardiacFindings: 'JVP meningkat R+4 cmH2O, batas jantung melebar ke kiri SIC VI LMC sinistra, terdengar gallop S3',
      otherFindings: 'Auskultasi paru terdengar ronki basah halus bilateral pada basal hingga pertengahan lapang paru, edema pretibial (+/+)'
    }),
    diagnosticTestsGenerator: (seed) => {
      const tests = [
        'EKG: ST elevasi konveks setinggi 3 mm pada sadapan V1-V4 dengan elevasi enzim hs-Troponin I 1200 ng/L. Pasien berada di rumah sakit tipe B dengan fasilitas kateterisasi jantung (Cath Lab) aktif.',
        'Ekokardiografi: Fraksi Ejeksi Ventrikel Kiri (LVEF) 28%, dilatasi ruang ventrikel kiri dengan hipokinetik global. Rontgen toraks: Kardiomegali (CTR 62%) dengan gambaran Batwing appearance dan garis Kerley B.',
        'EKG 12-sadapan: Tidak ditemukan gelombang P teratur, terdapat gelombang f fibrilasi ireguler dengan interval R-R yang sama sekali tidak beraturan (irregularly irregular) dengan laju ventrikel 132 x/menit.'
      ];
      return tests[seed % tests.length];
    },
    prompt: 'Apakah diagnosis definitif dan langkah tatalaksana farmakoterapi atau intervensi awal yang paling tepat sesuai pedoman klinis?',
    optionsGenerator: (seed) => {
      const variant = seed % 3;
      if (variant === 0) {
        return {
          options: [
            { label: 'A', text: 'STEMI Anteroseptal; Segera lakukan Primary Percutaneous Coronary Intervention (PCI) dengan target door-to-device < 90 menit' },
            { label: 'B', text: 'NSTEMI; Berikan terapi fibrinolisis dengan Streptokinase intravena segera' },
            { label: 'C', text: 'Unstable Angina Pectoris; Rawat jalan dengan aspirin dosis rendah dan observasi di rumah' },
            { label: 'D', text: 'Perikarditis Akut; Berikan terapi NSAID dosis tinggi dan kortikosteroid oral' },
            { label: 'E', text: 'Diseksi Aorta Tipe B; Segera berikan antikoagulan heparin bolus dosis tinggi' }
          ],
          correctIndex: 0,
          explanation: {
            coreConcept: 'Tatalaksana STEMI Akut dan Strategi Reperfusi PCI Primer.',
            rationaleCorrect: 'Elevasi segmen ST pada V1-V4 dengan nyeri dada tipikal dan biomarker positif mendiagnosis STEMI Anteroseptal. Bila fasilitas kateterisasi jantung tersedia dan door-to-device dapat dicapai < 90 menit (atau transfer < 120 menit), Primary PCI adalah terapi reperfusi pilihan utama dibanding fibrinolisis.',
            rationaleIncorrect: {
              B: 'Fibrinolisis dikontraindikasikan pada NSTEMI dan hanya diberikan pada STEMI bila PCI tidak tersedia dalam 120 menit.',
              C: 'Pasien mengalami STEMI akut yang merupakan kegawatdaruratan medis, bukan rawat jalan.',
              D: 'Perikarditis menunjukkan elevasi ST difus konkav di hampir semua sadapan dengan PR depresi, bukan elevasi lokal V1-V4.',
              E: 'Diseksi aorta adalah kontraindikasi mutlak pemberian antikoagulan dosis penuh tanpa konfirmasi CTA.'
            },
            clinicalTakeaway: 'Berikan DAPT loading (Aspirin 160-320 mg + Ticagrelor 180 mg atau Clopidogrel 600 mg) sebelum tindakan kateterisasi emergensi.'
          }
        };
      } else if (variant === 1) {
        return {
          options: [
            { label: 'A', text: 'Gagal Jantung dengan Fraksi Ejeksi Menurun (HFrEF) NYHA III; berikan Diuretik Loop IV untuk kongesti akut, lanjutkan 4 pilar GDMT (ARNI, Beta-bloker, MRA, SGLT2i)' },
            { label: 'B', text: 'Gagal Jantung dengan Fraksi Ejeksi Terpreservasi (HFpEF); berikan Digoxin dosis tinggi intravena' },
            { label: 'C', text: 'Gagal Jantung Akut; segera berikan infus Dopamin dan hentikan seluruh terapi oral' },
            { label: 'D', text: 'Kor Pulmonale Kronik; berikan terapi oksigen hiperbarik dan antibiotik empirik' },
            { label: 'E', text: 'Hipertensi Emergensi; turunkan tekanan darah ke 90/60 mmHg dalam 15 menit pertama' }
          ],
          correctIndex: 0,
          explanation: {
            coreConcept: 'Empat Pilar GDMT pada HFrEF (Guideline-Directed Medical Therapy).',
            rationaleCorrect: 'LVEF 28% (< 40%) mendefinisikan HFrEF. Pada kondisi hipervolemia (ronki, edema, peningkatan JVP), diuretik loop (furosemid) IV diberikan untuk dekongesti simtomatik. Setelah euvolemik, terapi empat pilar GDMT wajib diberikan untuk menurunkan mortalitas: ARNI (Sacubitril/Valsartan), Beta-bloker berbasis bukti (Bisoprolol/Carvedilol), MRA (Spironolakton), dan SGLT2 inhibitor (Dapagliflozin/Empagliflozin).',
            rationaleIncorrect: {
              B: 'LVEF 28% adalah HFrEF, bukan HFpEF (yang membutuhkan LVEF >= 50%).',
              C: 'Inotropik seperti dopamin hanya diberikan pada syok kardiogenik dengan hipoperfusi berat.',
              D: 'Kor pulmonale adalah gagal jantung kanan primer akibat hipertensi pulmonal paru.',
              E: 'Penurunan tekanan darah drastis pada hipertensi emergensi dapat mencetuskan iskemia serebral dan miokard.'
            },
            clinicalTakeaway: 'Empat pilar GDMT HFrEF harus dititrasi optimal karena telah terbukti secara kuat menurunkan mortalitas dan rehospitalisasi kardiovaskular.'
          }
        };
      } else {
        return {
          options: [
            { label: 'A', text: 'Fibrilasi Atrium dengan Rapid Ventricular Response (AF RVR); evaluasi stabilitas hemodinamik, berikan rate control dan hitung skor CHA2DS2-VASc untuk antikoagulasi' },
            { label: 'B', text: 'Takikardia Supraventrikular (SVT); lakukan manuver vagal dan injeksi adenosin bolus cepat' },
            { label: 'C', text: 'Sinus Takikardia Fisiologis; berikan cairan rehidrasi oral dan edukasi istirahat' },
            { label: 'D', text: 'Ventricular Tachycardia; segera lakukan kardioversi asinkron (defibrilasi 200 Joule)' },
            { label: 'E', text: 'Atrial Flutter; berikan terapi atropin sulfat intravena' }
          ],
          correctIndex: 0,
          explanation: {
            coreConcept: 'Diagnosis dan Manajemen Fibrilasi Atrium (AFib).',
            rationaleCorrect: 'Ketiadaan gelombang P dengan interval R-R yang tidak teratur secara mutlak (irregularly irregular) adalah tanda patognomonik Fibrilasi Atrium. Bila hemodinamik stabil, terapi laju ventrikel (Beta-bloker seperti bisoprolol atau Diltiazem) diberikan, dan antikoagulan oral (DOAC/Warfarin) diindikasikan berdasarkan stratifikasi risiko tromboemboli CHA2DS2-VASc.',
            rationaleIncorrect: {
              B: 'SVT memiliki irama reguler dengan kompleks QRS sempit, bukan irregularly irregular.',
              C: 'Sinus takikardia memiliki gelombang P normal yang diikuti QRS secara teratur.',
              D: 'VT ditandai dengan kompleks QRS lebar reguler; defibrilasi asinkron hanya untuk VF dan Pulseless VT.',
              E: 'Atrial flutter ditandai dengan gambaran gigi gergaji (sawtooth pattern) yang reguler di sadapan inferior.'
            },
            clinicalTakeaway: 'Pada pasien AFib dengan riwayat stroke iskemik (nilai skor CHA2DS2-VASc minimal 2 poin), antikoagulasi oral merupakan indikasi mutlak untuk mencegah stroke embolik berulang.'
          }
        };
      }
    }
  },

  // 7. BIOLOGI MOLEKULER & FARMAKOLOGI DETAIL: Kanal Ion & Jalur Sinyal
  {
    moduleId: 'biologi_detail',
    moduleName: 'Biologi Seluler & Molekuler Kardiovaskular',
    skdiLevel: 'SKDI 4A',
    difficulty: 'Sulit',
    ageRanges: [18, 45],
    genders: ['Laki-laki', 'Perempuan'],
    chiefComplaints: [
      'Pria muda mengalami sinkop berulang saat beristirahat di malam hari dan memiliki riwayat keluarga henti jantung mendadak',
      'Pemeriksaan elektrokardiogram skrining atlet menunjukkan pemanjangan interval QTc sebesar 510 ms',
      'Analisis molekuler jaringan kardiomiopati menunjukkan mutasi rantai berat beta-miosin MYH7'
    ],
    historyVariations: [
      'Paman pasien meninggal mendadak saat tidur pada usia 35 tahun tanpa riwayat penyakit sebelumnya.',
      'Pasien mengonsumsi antibiotik makrolida (eritromisin) untuk infeksi saluran napas 3 hari sebelum timbul keluhan berdebar.',
      'Pemeriksaan ekokardiografi menunjukkan hipertrofi septum asimetris (ketebalan septum 24 mm) dengan obstruksi alur keluar ventrikel kiri (LVOT).'
    ],
    vitalsGenerator: (seed) => ({
      bp: `${110 + (seed % 20)}/${70 + (seed % 15)} mmHg`,
      hr: `${68 + (seed % 22)} x/menit, regular`,
      rr: '18 x/menit',
      temp: '36.5°C',
      cardiacFindings: 'Bunyi jantung S1 S2 normal, terdengar bising ejeksi sistolik kasar kresendo-dekresendo di batas sternal kiri yang mengeras saat manuver Valsalva',
      otherFindings: 'Tidak ada edema perifer, tidak ada pembesaran kelenjar tiroid'
    }),
    diagnosticTestsGenerator: (seed) => {
      const tests = [
        'EKG 12-sadapan: Elevasi segmen ST tipe coved (kubah) >= 2 mm diikuti gelombang T negatif pada sadapan V1 dan V2 (tipe 1 Brugada pattern).',
        'EKG 12-sadapan: Interval QTc memanjang hingga 520 ms dengan gelombang T bifasik berlekuk pada sadapan prekordial.',
        'Pemeriksaan Genetik: Teridentifikasi varian patogenik mutasi missense pada gen MYH7 atau MYBPC3.'
      ];
      return tests[seed % tests.length];
    },
    prompt: 'Apakah kelainan genetik/molekuler yang mendasari kondisi tersebut dan implikasi klinisnya?',
    optionsGenerator: (seed) => {
      const variant = seed % 3;
      if (variant === 0) {
        return {
          options: [
            { label: 'A', text: 'Sindrom Brugada; akibat mutasi loss-of-function pada gen SCN5A yang mengkode kanal natrium jantung Nav1.5' },
            { label: 'B', text: 'Sindrom Long QT Tipe 1; mutasi pada gen KCNQ1 yang mengkode kanal kalium IKs' },
            { label: 'C', text: 'Katekolaminergik Polimorfik Ventrikular Takikardia (CPVT); mutasi reseptor Ryanodine RyR2' },
            { label: 'D', text: 'Sindrom Marfan; defisiensi protein fibrilin-1 pada matriks ekstraseluler tunika media' },
            { label: 'E', text: 'Atrial Septal Defect familiaris; mutasi faktor transkripsi NKX2-5' }
          ],
          correctIndex: 0,
          explanation: {
            coreConcept: 'Patobiologi Molekuler Sindrom Brugada dan Kanal Nav1.5.',
            rationaleCorrect: 'Sindrom Brugada merupakan kanalopati kardiak herediter autosomal dominan. Sekitar 20-25% kasus diakibatkan oleh mutasi loss-of-function gen SCN5A yang mengkode subunit alfa kanal natrium jantung (Nav1.5). Penurunan arus masuk natrium (INa) fase 0 menyebabkan disparitas repolarisasi transmembran antara epikardium dan endokardium ventrikel kanan, memicu pola EKG tipe coved pada V1-V2 dan aritmia ventrikel fatal (VF).',
            rationaleIncorrect: {
              B: 'LQT1 disebabkan oleh mutasi loss-of-function kanal kalium IKs (KCNQ1) dan terpicu oleh olahraga/berenang.',
              C: 'CPVT diakibatkan mutasi RyR2 atau calsequestrin (CASQ2) dan terpicu oleh lonjakan adrenergik/stres emosional.',
              D: 'Sindrom Marfan melibatkan mutasi FBN1 yang menyebabkan dilatasi arkus aorta, bukan kelainan ritme Brugada.',
              E: 'Mutasi NKX2-5 menyebabkan ASD sekundum dan blok konduksi AV progresif.'
            },
            clinicalTakeaway: 'Implantable Cardioverter-Defibrillator (ICD) adalah terapi lini pertama pencegahan kematian jantung mendadak pada pasien simtomatik Sindrom Brugada.'
          }
        };
      } else if (variant === 1) {
        return {
          options: [
            { label: 'A', text: 'Drug-Induced Long QT Syndrome; blokade farmakologis kanal kalium IKr (gen KCNH2/hERG) oleh antibiotik makrolida berisiko memicu Torsades de Pointes' },
            { label: 'B', text: 'Sindrom Wolff-Parkinson-White; eksitasi dini ventrikel via bundle of Kent' },
            { label: 'C', text: 'Hiperkalemia berat dengan pemendekan interval QT' },
            { label: 'D', text: 'Toksisitas Digoxin dengan gambaran Salvador Dali mustache ST depression' },
            { label: 'E', text: 'Infark miokard hiperakut dinding anterior' }
          ],
          correctIndex: 0,
          explanation: {
            coreConcept: 'Farmakogenomik Kanal Kalium hERG (KCNH2) dan Torsades de Pointes.',
            rationaleCorrect: 'Obat-obatan seperti makrolida (eritromisin, klaritromisin), fluoroquinolon, antipsikotik, dan antiaritmia kelas IA/III dapat berikatan dengan rongga dalam kanal kalium hERG (IKr). Hambatan arus kalium repolarisasi fase 3 ini memperpanjang durasi potensial aksi dan interval QT, membuka peluang timbulnya early afterdepolarizations (EAD) yang dapat memicu takikardia ventrikel polimorfik Torsades de Pointes.',
            rationaleIncorrect: {
              B: 'WPW memperpendek interval PR (< 0.12 s) dan memunculkan gelombang delta, bukan memanjangkan QT.',
              C: 'Hiperkalemia menyebabkan gelombang T tinggi lancip (peaked T wave) dan pemendekan QT.',
              D: 'Toksisitas digoxin memperpendek interval QT dan memicu depresi ST bentuk sekop.',
              E: 'Infark hiperakut menunjukkan gelombang T raksasa simetris lokal sadapan tertentu.'
            },
            clinicalTakeaway: 'Koreksi elektrolit (terutama magnesium dan kalium serum) serta penghentian segera obat pemicu adalah tatalaksana utama Long QT terinduksi obat.'
          }
        };
      } else {
        return {
          options: [
            { label: 'A', text: 'Kardiomiopati Hipertrofik (HCM); mutasi gen protein sarkomer (MYH7/MYBPC3) yang menyebabkan disarray histologis miosit dan risiko aritmia ventrikel' },
            { label: 'B', text: 'Kardiomiopati Dilatasi familial akibat mutasi gen lamin A/C (LMNA)' },
            { label: 'C', text: 'Amiloidosis kardiak akibat deposisi ekstraseluler protein transthyretin (ATTR)' },
            { label: 'D', text: 'Miokarditis virus akut akibat infeksi Coxsackievirus B' },
            { label: 'E', text: 'Penyakit Jantung Hipertensi dengan hipertrofi konsentrik simetris' }
          ],
          correctIndex: 0,
          explanation: {
            coreConcept: 'Genetika Molekuler Kardiomiopati Hipertrofik (HCM).',
            rationaleCorrect: 'Kardiomiopati Hipertrofik adalah penyakit monogenik kardiovaskular tersering (1:500 populasi), diturunkan secara autosomal dominan. Lebih dari 50% kasus disebabkan mutasi gen sarkomer kardiak: MYH7 (beta-myosin heavy chain) dan MYBPC3 (myosin-binding protein C). Obstruksi LVOT khas bermanifestasi dengan murmur ejeksi sistolik yang mengeras saat preload berkurang (manuver Valsalva).',
            rationaleIncorrect: {
              B: 'Mutasi LMNA menyebabkan kardiomiopati dilatasi dengan gangguan konduksi AV dini.',
              C: 'Amiloidosis kardiak adalah penyakit restriktif dengan dinding ventrikel tebal namun voltase EKG rendah.',
              D: 'Miokarditis virus adalah penyakit inflamasi akut pasca-infeksi saluran napas atau cerna.',
              E: 'Penyakit jantung hipertensi biasanya menyebabkan hipertrofi ventrikel konsentrik simetris tanpa obstruksi dinamis LVOT khas.'
            },
            clinicalTakeaway: 'Skrining ekokardiografi dan konseling genetik dianjurkan untuk seluruh anggota keluarga derajat pertama (first-degree relatives) pasien HCM.'
          }
        };
      }
    }
  }
];

// Helper to deterministically build question N from 1 to 12000
export function getCBTQuestion(questionId: number): CBTQuestion {
  // Normalize id into 1 .. 12000
  const normalizedId = Math.max(1, Math.min(12000, questionId));
  
  // Distribute across modules based on ID ranges:
  // 1 - 1700: Anatomi
  // 1701 - 3400: Fisiologi
  // 3401 - 5100: Histologi
  // 5101 - 6800: Biokimia
  // 6801 - 8500: Embriologi
  // 8501 - 10500: Penyakit
  // 10501 - 12000: Biologi Detail
  let templateIndex = 0;
  if (normalizedId <= 1700) {
    templateIndex = 0; // Anatomi
  } else if (normalizedId <= 3400) {
    templateIndex = 1; // Fisiologi
  } else if (normalizedId <= 5100) {
    templateIndex = 2; // Histologi
  } else if (normalizedId <= 6800) {
    templateIndex = 3; // Biokimia
  } else if (normalizedId <= 8500) {
    templateIndex = 4; // Embriologi
  } else if (normalizedId <= 10500) {
    templateIndex = 5; // Penyakit
  } else {
    templateIndex = 6; // Biologi Detail
  }

  const template = TEMPLATES[templateIndex];
  const seed = normalizedId * 31 + 17;

  const age = template.ageRanges[0] + (seed % (template.ageRanges[1] - template.ageRanges[0] + 1));
  const gender = template.genders[seed % template.genders.length];
  const complaint = template.chiefComplaints[seed % template.chiefComplaints.length];
  const history = template.historyVariations[seed % template.historyVariations.length];
  const vitals = template.vitalsGenerator(seed);
  const diagnostics = template.diagnosticTestsGenerator(seed);

  const { options, correctIndex, explanation } = template.optionsGenerator(seed);
  const correctLabel = (['A', 'B', 'C', 'D', 'E'] as const)[correctIndex];

  // Full medical vignette
  const vignetteText = `Pasien ${gender}, berusia ${age} tahun, datang ke Instalasi Gawat Darurat / Poliklinik Kardiovaskular dengan keluhan: ${complaint}. ${history} Pada pemeriksaan fisik didapatkan tanda-tanda vital: Tekanan Darah ${vitals.bp}, Denyut Jantung ${vitals.hr}, Laju Pernapasan ${vitals.rr}, Suhu ${vitals.temp}. Auskultasi kardiak: ${vitals.cardiacFindings}. Temuan fisik lainnya: ${vitals.otherFindings}. Hasil pemeriksaan diagnostik penunjang: ${diagnostics}`;

  return {
    id: normalizedId,
    moduleId: template.moduleId,
    moduleName: template.moduleName,
    skdiLevel: template.skdiLevel,
    difficulty: template.difficulty,
    clinicalScenario: {
      patientAge: age,
      patientGender: gender,
      chiefComplaint: complaint,
      historyOfPresentIllness: history,
      physicalExam: vitals,
      diagnosticTests: diagnostics
    },
    vignetteText,
    questionPrompt: template.prompt,
    options,
    correctAnswer: correctLabel,
    explanation
  };
}

export const CBT_STATS = {
  totalQuestions: 12000,
  modules: [
    { id: 'anatomi', name: '1. Anatomi Sistem Kardiovaskular', range: 'No. 00001 - 01700', count: 1700 },
    { id: 'fisiologi', name: '2. Fisiologi Sistem Kardiovaskular', range: 'No. 01701 - 03400', count: 1700 },
    { id: 'histologi', name: '3. Histologi Sistem Kardiovaskular', range: 'No. 03401 - 05100', count: 1700 },
    { id: 'biokimia', name: '4. Biokimia Sistem Kardiovaskular', range: 'No. 05101 - 06800', count: 1700 },
    { id: 'embriologi', name: '5. Embriologi Sistem Kardiovaskular', range: 'No. 06801 - 08500', count: 1700 },
    { id: 'penyakit', name: '6. Penyakit Terkait Kardiovaskular', range: 'No. 08501 - 10500', count: 2000 },
    { id: 'biologi_detail', name: '7. Biologi Detail & Farmakologi', range: 'No. 10501 - 12000', count: 1500 }
  ]
};
