export interface BeginnerConcept {
  id: string;
  moduleId: string;
  title: string;
  coreIdea: string;
  realWorldAnalogy: {
    analogyTitle: string;
    analogyStory: string;
    explanation: string;
  };
  stepByStepGuide: {
    stepNumber: number;
    title: string;
    description: string;
  }[];
  commonMisconceptions: {
    myth: string;
    fact: string;
  }[];
  quickQuiz: {
    question: string;
    options: string[];
    correctIndex: number;
    explanation: string;
  };
}

export interface GlossaryTerm {
  term: string;
  simpleMeaning: string;
  clinicalContext: string;
  pronunciation?: string;
}

export const BEGINNER_GLOSSARY: GlossaryTerm[] = [
  {
    term: 'Sistol (Systole)',
    simpleMeaning: 'Fase ketika bilik jantung memeras/memompa darah keluar ke pembuluh darah.',
    clinicalContext: 'Angka atas pada tensimeter (misal: 120/80 mmHg -> 120 adalah tekanan sistol).'
  },
  {
    term: 'Diastol (Diastole)',
    simpleMeaning: 'Fase ketika bilik jantung rileks dan mengembang untuk mengisi ulang darah.',
    clinicalContext: 'Angka bawah pada tensimeter (misal: 120/80 mmHg -> 80 adalah tekanan diastol).'
  },
  {
    term: 'Preload',
    simpleMeaning: 'Berapa banyak darah yang masuk dan meregangkan bilik jantung sebelum dipompa.',
    clinicalContext: 'Semakin banyak darah yang kembali ke jantung (venous return), semakin tinggi preload-nya.'
  },
  {
    term: 'Afterload',
    simpleMeaning: 'Beban tahanan pipa pembuluh darah yang harus dilawan jantung agar darah bisa keluar.',
    clinicalContext: 'Pada penderita darah tinggi (hipertensi), afterload sangat berat sehingga otot jantung harus bekerja ekstra keras.'
  },
  {
    term: 'Cardiac Output (Curah Jantung)',
    simpleMeaning: 'Total volume darah yang dipompa jantung dalam 1 menit (rata-rata 5 liter per menit saat istirahat).',
    clinicalContext: 'Dihitung dari: Denyut Jantung (HR) x Jumlah Darah Sekali Pompa (Stroke Volume).'
  },
  {
    term: 'Nodus SA (SA Node)',
    simpleMeaning: 'Pembangkit listrik alami di atap jantung yang menentukan irama detak jantung normal (60-100 kali/menit).',
    clinicalContext: 'Sering disebut "baterai alami" jantung atau pacemaker.'
  },
  {
    term: 'Troponin',
    simpleMeaning: 'Protein khusus di dalam sel otot jantung yang baru bocor keluar ke darah jika ada sel otot jantung yang mati/rusak.',
    clinicalContext: 'Pemeriksaan darah utama di IGD untuk memastikan apakah pasien terkena serangan jantung.'
  },
  {
    term: 'Arteri Koroner',
    simpleMeaning: 'Pipa pembuluh darah khusus yang memberi makan dan oksigen langsung ke otot jantung itu sendiri.',
    clinicalContext: 'Jika pipa ini tersumbat kolesterol dan gumpalan darah, terjadilah serangan jantung (infark miokard).'
  },
  {
    term: 'Murmur / Bising Jantung',
    simpleMeaning: 'Suara desiran tidak normal saat dokter mendengarkan detak jantung dengan stetoskop, akibat aliran darah yang berputar kasar (turbulen) melewati katup yang sempit atau bocor.',
    clinicalContext: 'Bisa disebabkan oleh katup kaku (stenosis) atau katup tidak menutup rapat (regurgitasi).'
  },
  {
    term: 'Aorta',
    simpleMeaning: 'Pipa arteri terbesar di tubuh manusia yang langsung menerima semprotan darah kaya oksigen dari bilik kiri jantung.',
    clinicalContext: 'Berbentuk melengkung seperti pegangan payung (arkus aorta) di bagian atas dada.'
  }
];

export const BLOOD_FLOW_STEPS = [
  {
    step: 1,
    title: 'Darah Kotor dari Seluruh Tubuh Tiba di Atrium Kanan',
    chamber: 'Vena Cava Superior & Inferior -> Atrium Kanan',
    oxygenState: 'Deoksigenasi (Kaya CO2 - Biru)',
    description: 'Setelah tubuh menggunakan oksigen, darah mengalir kembali melalui pipa vena besar (Vena Cava) dan masuk ke serambi kanan (Atrium Dextrum).'
  },
  {
    step: 2,
    title: 'Melewati Katup Trikuspid ke Ventrikel Kanan',
    chamber: 'Atrium Kanan -> Valva Tricuspidalis -> Ventrikel Kanan',
    oxygenState: 'Deoksigenasi (Biru)',
    description: 'Pintu katup berdaun tiga (trikuspid) membuka, darah mengalir turun mengisi bilik kanan (Ventriculus Dexter).'
  },
  {
    step: 3,
    title: 'Dipompa Menuju Paru-Paru untuk Mengambil Oksigen',
    chamber: 'Ventrikel Kanan -> Arteri Pulmonalis -> Paru-Paru',
    oxygenState: 'Deoksigenasi Berubah Jadi Kaya Oksigen di Paru',
    description: 'Bilik kanan memeras darah melewati katup pulmonal menuju paru-paru. Di paru, darah membuang CO2 dan menghirup O2 segar.'
  },
  {
    step: 4,
    title: 'Darah Bersih Segar Kembali ke Atrium Kiri',
    chamber: 'Paru-Paru -> Vena Pulmonalis -> Atrium Kiri',
    oxygenState: 'Oksigenasi Tinggi (Merah Terang)',
    description: 'Empat pipa vena pulmonalis membawa darah yang sudah kaya oksigen masuk ke serambi kiri jantung (Atrium Sinistrum).'
  },
  {
    step: 5,
    title: 'Melewati Katup Mitral ke Ventrikel Kiri yang Super Kuat',
    chamber: 'Atrium Kiri -> Valva Mitralis -> Ventrikel Kiri',
    oxygenState: 'Oksigenasi Tinggi (Merah)',
    description: 'Darah meluncur melewati katup mitral berdaun dua ke bilik kiri (Ventriculus Sinister) yang memiliki dinding otot paling tebal (3x lebih tebal dari bilik kanan).'
  },
  {
    step: 6,
    title: 'Disemprotkan ke Pipa Utama Aorta Menuju Otak & Seluruh Tubuh',
    chamber: 'Ventrikel Kiri -> Katup Aorta -> Aorta -> Seluruh Tubuh',
    oxygenState: 'Oksigenasi Tinggi (Merah)',
    description: 'Bilik kiri memeras dengan tekanan kuat (~120 mmHg) membuka katup aorta dan menyemburkan darah ke aorta untuk menghidupi otak, ginjal, otot, dan semua organ tubuh!'
  }
];

export const BEGINNER_MODULE_CONCEPTS: Record<string, BeginnerConcept> = {
  anatomi: {
    id: 'beg_anatomi',
    moduleId: 'anatomi',
    title: 'Konsep Dasar Anatomi Jantung untuk Pemula',
    coreIdea: 'Jantung bukanlah organ berbentuk simbol cinta (love), melainkan kepalan tangan otot berongga berbentuk kerucut miring yang terdiri dari 2 pompa terpisah berdampingan (sisi kanan dan sisi kiri).',
    realWorldAnalogy: {
      analogyTitle: 'Analogi Pompa Air Dua Saluran di Rumah',
      analogyStory: 'Bayangkan rumah bertingkat dengan 2 pompa air terpisah di satu boks mesin. Pompa Kiri berkekuatan tinggi untuk mengalirkan air bersih ke lantai atas dan seluruh penjuru rumah (sirkulasi sistemik). Pompa Kanan berkekuatan sedang hanya untuk mengalirkan air bekas ke tangki penyaringan filter di atap (paru-paru) agar air kembali bersih.',
      explanation: 'Sisi kiri jantung berdinding jauh lebih tebal karena harus memompa darah melawan gravitasi ke ujung kepala hingga ujung jari kaki, sedangkan sisi kanan hanya perlu memompa jarak dekat ke paru-paru di sebelahnya.'
    },
    stepByStepGuide: [
      {
        stepNumber: 1,
        title: 'Mengenal 4 Ruang Jantung',
        description: 'Dua ruang di atas disebut Serambi (Atrium) bertugas sebagai wadah penampung awal. Dua ruang di bawah disebut Bilik (Ventrikel) bertugas sebagai pompa pendorong utama.'
      },
      {
        stepNumber: 2,
        title: 'Mengenal 4 Pintu Gerbang (Katup Jantung)',
        description: 'Katup adalah pintu satu arah berdaun tipis fleksibel. Darah hanya boleh maju, tidak boleh balik ke belakang. Trikuspid & Mitral (pintu antara serambi dan bilik), Aorta & Pulmonal (pintu keluar bilik menuju pipa arteri).'
      },
      {
        stepNumber: 3,
        title: 'Mengenal Pipa Bahan Bakar Jantung (Arteri Koroner)',
        description: 'Jantung memompa darah ke seluruh tubuh, tetapi jantung sendiri juga butuh makan! Pipa Arteri Koroner kiri (LAD, LCx) dan kanan (RCA) menempel di permukaan luar jantung memberi makan sel-sel otot jantung.'
      }
    ],
    commonMisconceptions: [
      {
        myth: 'Jantung berada persis di sisi kiri dada secara penuh.',
        fact: 'Sebenarnya jantung berada di tengah dada (mediastinum), hanya saja ujung bawahnya (apex) agak miring condong ke sebelah kiri dada.'
      },
      {
        myth: 'Darah kotor berwarna biru di dalam tubuh kita.',
        fact: 'Darah deoksigenasi sebenarnya berwarna merah gelap/marun pekat, bukan biru. Warna biru pada buku dan gambar hanyalah kode warna diagram medis untuk membedakan kadar oksigen.'
      }
    ],
    quickQuiz: {
      question: 'Ruang jantung manakah yang memiliki dinding otot paling tebal dan mengapa?',
      options: [
        'Atrium Kanan, karena menampung darah dari seluruh tubuh',
        'Ventrikel Kiri, karena memompa darah ke seluruh sirkulasi tubuh',
        'Ventrikel Kanan, karena memompa darah ke paru-paru',
        'Atrium Kiri, karena menerima darah langsung dari paru-paru'
      ],
      correctIndex: 1,
      explanation: 'Ventrikel kiri memiliki ketebalan otot 3x lipat dibanding ventrikel kanan karena harus menghasilkan tekanan tinggi (~120 mmHg) untuk mengalirkan darah ke seluruh tubuh.'
    }
  },

  fisiologi: {
    id: 'beg_fisiologi',
    moduleId: 'fisiologi',
    title: 'Konsep Dasar Fisiologi & Denyut Jantung',
    coreIdea: 'Denyut jantung (Lub-Dub) bukanlah suara gesekan otot, melainkan suara pintu katup jantung yang menutup secara mendadak saat tekanan berubah.',
    realWorldAnalogy: {
      analogyTitle: 'Analogi Suara Pintu Terbanting Angin (LUB-DUB)',
      analogyStory: 'Saat pintu kamar terbanting kencang oleh hembusan angin mendadak, Anda mendengar bunyi "BUMM!". Anda tidak mendengar suara udara mengalir, melainkan suara benturan daun pintu yang menutup rapat.',
      explanation: 'Suara pertama "LUB" (S1) adalah suara tertutupnya katup Mitral dan Trikuspid saat bilik mulai memeras. Suara kedua "DUB" (S2) adalah suara tertutupnya katup Aorta dan Pulmonal saat bilik selesai memompa.'
    },
    stepByStepGuide: [
      {
        stepNumber: 1,
        title: 'Hukum Ketapel Frank-Starling',
        description: 'Seperti karet ketapel, semakin kita tarik ke belakang (semakin banyak darah yang mengisi bilik jantung saat diastol), maka saat dilepaskan peluru kerikil akan terlontar semakin kencang (gaya pompa semakin kuat).'
      },
      {
        stepNumber: 2,
        title: 'Sistem Kabel Listrik Jantung',
        description: 'Setiap detakan dipicu sengatan listrik mikroskopis dari Nodus SA di serambi kanan, merambat ke Nodus AV (gardu penunda agar bilik sempat terisi penuh), lalu merambat cepat lewat serat Purkinje.'
      }
    ],
    commonMisconceptions: [
      {
        myth: 'Otot jantung membutuhkan perintah dari otak untuk setiap kali berdenyut.',
        fact: 'Jantung bersifat otomatis (otonom). Bahkan jika semua saraf dari otak diputus atau jantung dikeluarkan untuk donor transplantasi, jantung tetap bisa berdenyut sendiri selama mendapat oksigen dan nutrisi berkat Nodus SA.'
      }
    ],
    quickQuiz: {
      question: 'Apakah penyebab bunyi jantung pertama (S1 / LUB)?',
      options: [
        'Darah mengalir cepat masuk ke paru-paru',
        'Penutupan mendadak katup Mitral dan Trikuspid di awal sistol',
        'Penutupan katup Aorta di akhir sistol',
        'Otot bilik jantung saling bergesekan'
      ],
      correctIndex: 1,
      explanation: 'Bunyi S1 terjadi akibat penutupan katup atrioventrikular (Mitral dan Trikuspid) saat ventrikel mulai berkontraksi.'
    }
  },

  histologi: {
    id: 'beg_histologi',
    moduleId: 'histologi',
    title: 'Konsep Dasar Histologi & Mikroskop Otot Jantung',
    coreIdea: 'Otot jantung tampak seperti anyaman batu bata bergaris di bawah mikroskop, di mana setiap sel dihubungkan oleh sambungan kabel berpori yang disebut diskus interkalaris.',
    realWorldAnalogy: {
      analogyTitle: 'Analogi Pasukan Sorak Gelombang Manusia di Stadion',
      analogyStory: 'Di stadion sepak bola, ketika 50.000 penonton melakukan gerakan gelombang berdiri serentak, mereka tidak berbicara satu per satu lewat telepon. Mereka saling berpegangan tangan dan langsung merespons gerakan tetangga di sebelahnya secara instan.',
      explanation: 'Diskus interkalaris memiliki "lubang terowongan kecil" (gap junctions) antar-sel. Begitu ion listrik menyentuh satu sel otot, ion langsung menyebar ke sel sebelahnya dalam hitungan milidetik sehingga seluruh bilik memeras serentak sebagai satu kesatuan.'
    },
    stepByStepGuide: [
      {
        stepNumber: 1,
        title: 'Bentuk Sel Bercabang',
        description: 'Berbeda dengan otot paha yang lurus panjang, sel otot jantung berbentuk silinder yang bercabang-cabang dan saling menyatu membentuk anyaman jala yang fleksibel.'
      },
      {
        stepNumber: 2,
        title: 'Pabrik Energi Super (Mitokondria)',
        description: 'Sekitar 40% dari isi sel otot jantung adalah mitokondria (pembangkit energi). Jantung tidak pernah istirahat tidur selama kita hidup, sehingga membutuhkan pasokan energi tanpa henti.'
      }
    ],
    commonMisconceptions: [
      {
        myth: 'Otot jantung bisa mengalami kram seperti otot betis saat lari maraton.',
        fact: 'Otot jantung dirancang dengan periode refrakter yang sangat panjang; otot jantung secara biologis TIDAK BISA mengalami kram/tetani agar selalu memiliki waktu untuk relaksasi dan mengisi darah.'
      }
    ],
    quickQuiz: {
      question: 'Struktur apakah yang memungkinkan sel-sel otot jantung berkontraksi serentak sebagai satu kesatuan sinsitium?',
      options: [
        'Lapisan lemak subepikardial',
        'Diskus interkalaris dengan Gap Junctions',
        'Bantalan kartilago anulus fibrosus',
        'Pigmen lipofuscin di dalam sitoplasma'
      ],
      correctIndex: 1,
      explanation: 'Diskus interkalaris mengandung Gap Junction (nexus) yang menghubungkan sitoplasma sel tetangga secara langsung sehingga arus listrik merambat instan.'
    }
  },

  biokimia: {
    id: 'beg_biokimia',
    moduleId: 'biokimia',
    title: 'Konsep Dasar Biokimia & Enzim Jantung',
    coreIdea: 'Saat sel otot jantung kekurangan oksigen dan mati, dinding selnya pecah dan membocorkan enzim-enzim khusus ke aliran darah yang dapat diukur oleh dokter di laboratorium.',
    realWorldAnalogy: {
      analogyTitle: 'Analogi Telur yang Pecah di Dalam Keranjang',
      analogyStory: 'Bayangkan sebutir telur mentah dengan kuning telur di dalamnya. Selama cangkang telur utuh, isi kuning telur tidak akan keluar ke lantai. Namun jika cangkang telur retak terinjak, cairan kuning telur akan tumpah ke mana-mana.',
      explanation: 'Troponin adalah seperti kuning telur yang berada di dalam sel otot jantung. Bila terjadi serangan jantung, sel otot rusak dan troponin tumpah ke pembuluh darah. Dokter cukup mengambil sedikit darah dari lengan untuk mendeteksinya.'
    },
    stepByStepGuide: [
      {
        stepNumber: 1,
        title: 'Bahan Bakar Makanan Jantung',
        description: 'Jantung paling suka "makan" asam lemak (60-80% energinya berasal dari pembakaran lemak dengan oksigen). Saat kekurangan oksigen, jantung terpaksa membakar gula secara anaerobik dan menghasilkan asam laktat yang menimbulkan rasa nyeri dada.'
      },
      {
        stepNumber: 2,
        title: 'Troponin Ultrasensitif (hs-cTn)',
        description: 'Tes biomarker paling akurat saat ini. Dapat mendeteksi kerusakan otot jantung hanya dalam 1-2 jam pertama setelah rasa sakit dada muncul.'
      }
    ],
    commonMisconceptions: [
      {
        myth: 'Troponin positif di darah pasti disebabkan oleh sumbatan plak kolesterol.',
        fact: 'Troponin menandakan kerusakan otot jantung, tetapi kerusakannya bisa juga disebabkan oleh infeksi miokarditis berat, sepsis, atau detak jantung yang terlalu cepat (takiaritmia ekstrem) tanpa sumbatan plak koroner.'
      }
    ],
    quickQuiz: {
      question: 'Biomarker darah manakah yang menjadi standar baku emas (gold standard) untuk mendeteksi serangan jantung akut?',
      options: [
        'Hemoglobin A1c',
        'Cardiac Troponin I / T',
        'Asam Urat serum',
        'Kalsium total'
      ],
      correctIndex: 1,
      explanation: 'Cardiac Troponin I dan T memiliki bentuk protein khusus yang hanya ada di sel otot jantung, menjadikannya penanda paling spesifik dan sensitif.'
    }
  },

  embriologi: {
    id: 'beg_embriologi',
    moduleId: 'embriologi',
    title: 'Konsep Dasar Embriologi & Jantung Janin',
    coreIdea: 'Pada usia kehamilan 3 minggu, jantung berawal hanya dari sebatang tabung lurus sederhana yang berdenyut, lalu melipat membentuk huruf S (looping) dan menyekat diri menjadi 4 ruang.',
    realWorldAnalogy: {
      analogyTitle: 'Analogi Balon Panjang yang Ditekuk dan Disekat',
      analogyStory: 'Bayangkan Anda meniup balon pesta yang panjang dan lurus. Agar bisa menjadi bentuk binatang atau rumah, Anda harus menekuk balon tersebut ke arah kanan, lalu memasang sekat di tengah-tengahnya.',
      explanation: 'Jika tabung jantung janin keliru melipat ke arah kiri (bukan ke kanan), jantung bayi akan berada di sebelah kanan dada (Dekstrokardia). Jika sekat pemisah tidak menutup sempurna, terbentuklah lubang kebocoran jantung (seperti ASD atau VSD).'
    },
    stepByStepGuide: [
      {
        stepNumber: 1,
        title: 'Hari ke-21: Organ Pertama yang Berfungsi',
        description: 'Jantung adalah organ pertama janin yang mulai berdenyut aktif untuk mengalirkan nutrisi dari ibu ke seluruh jaringan bakal janin yang sedang tumbuh pesat.'
      },
      {
        stepNumber: 2,
        title: 'Sirkulasi Khusus Janin di Dalam Kandungan',
        description: 'Di dalam rahim, janin tidak bernapas lewat paru-parunya sendiri (paru terendam cairan). Oksigen didapat dari plasenta ibu lewat tali pusar. Jantung janin memiliki jalan pintas (Foramen Ovale dan Duktus Arteriosus) yang secara normal akan langsung menutup begitu bayi lahir dan menangis pertama kali.'
      }
    ],
    commonMisconceptions: [
      {
        myth: 'Semua kelainan jantung bawaan langsung membuat bayi membiru sejak lahir.',
        fact: 'Tidak semua. Kelainan seperti kebocoran kecil VSD atau ASD tidak membuat bayi biru (non-sianotik) karena darah bersih mengalir ke darah kotor. Kelainan yang membuat bayi membiru (sianotik) adalah jika darah kotor langsung melompat ke sirkulasi tubuh, seperti pada Tetralogy of Fallot.'
      }
    ],
    quickQuiz: {
      question: 'Lubang alami di sekat serambi jantung janin yang memungkinkan darah beroksigen memotong paru-paru disebut:',
      options: [
        'Duktus Venosus',
        'Foramen Ovale',
        'Sinus Karotikus',
        'Ligamentum Teres'
      ],
      correctIndex: 1,
      explanation: 'Foramen Ovale adalah pintu berkatup antara atrium kanan dan kiri pada janin yang normalnya menutup pasca-kelahiran menjadi Fossa Ovalis.'
    }
  },

  penyakit: {
    id: 'beg_penyakit',
    moduleId: 'penyakit',
    title: 'Konsep Dasar Penyakit Jantung untuk Mahasiswa',
    coreIdea: 'Sebagian besar penyakit jantung bermula dari dua masalah pokok: Masalah Pemipaan (Arteri Koroner tersumbat) atau Masalah Pompa (Otot jantung lemah / bocor katup).',
    realWorldAnalogy: {
      analogyTitle: 'Analogi Pipa Air Tersumbat Kerak vs Mesin Pompa Jebol',
      analogyStory: '1) Jika pipa selang bensin motor Anda tersumbat endapan kotoran, mesin motor akan mogok mendadak karena kehabisan bensin (Serangan Jantung Koroner). 2) Jika mesin pompa air sumur Anda sudah tua dan aus klepnya, air tetap mengalir tapi lemah dan tidak sampai ke torn atas, sehingga air meluap membanjiri garasi (Gagal Jantung Kongestif dengan edema bengkak kaki).',
      explanation: 'Serangan jantung adalah masalah pasokan darah ke otot jantung; sedangkan gagal jantung adalah ketidakmampuan pompa membagikan darah ke organ tubuh.'
    },
    stepByStepGuide: [
      {
        stepNumber: 1,
        title: 'Gejala Bahaya Serangan Jantung (Angina Pectoris)',
        description: 'Nyeri dada terasa seperti ditimpa batu berat atau diremas di tengah dada, menjalar ke lengan kiri, leher, atau rahang, disertai keringat dingin mengucur dan sesak napas.'
      },
      {
        stepNumber: 2,
        title: 'Gejala Gagal Jantung (Heart Failure)',
        description: 'Sesak napas saat berjalan sedikit, harus tidur dengan 2-3 bantal tinggi agar tidak sesak (ortopnea), terbangun tengah malam megap-megap mencari udara (PND), dan kedua pergelangan kaki bengkak jika ditekan cekung (pitting edema).'
      }
    ],
    commonMisconceptions: [
      {
        myth: 'Serangan jantung selalu ditandai dengan jatuh pingsan mendadak sambil memegangi dada kiri seperti di film.',
        fact: 'Banyak pasien (terutama lansia dan penderita diabetes) mengalami serangan jantung tanpa rasa nyeri yang dramatis; mereka hanya mengeluh cepat lelah, mual, keringat dingin, atau sesak napas (silent myocardial infarction).'
      }
    ],
    quickQuiz: {
      question: 'Manakah tanda khas pada pemeriksaan fisik pasien yang mengalami gagal jantung dengan penumpukan cairan?',
      options: [
        'Kulit terasa sangat kering dan panas',
        'Bengkak pada kedua tungkai bawah dan sesak saat tidur terlentang',
        'Tekanan darah turun drastis di bawah 50 mmHg',
        'Pupil mata melebar maksimal'
      ],
      correctIndex: 1,
      explanation: 'Kelebihan cairan akibat gagal jantung menyebabkan penumpukan darah di sirkulasi balik (edema perifer di kedua tungkai) dan kongesti paru saat berbaring (ortopnea).'
    }
  },

  biologi_detail: {
    id: 'beg_biologi_detail',
    moduleId: 'biologi_detail',
    title: 'Konsep Dasar Biologi Molekuler & Kanal Ion',
    coreIdea: 'Setiap kontraksi jantung digerakkan oleh tarian pertukaran ion garam kecil (Natrium, Kalium, dan Kalsium) yang keluar masuk melalui pintu-pintu mikroskopis (kanal ion) di dinding sel.',
    realWorldAnalogy: {
      analogyTitle: 'Analogi Pintu Gerbang Tol Otomatis Gardu Ion',
      analogyStory: 'Bayangkan stasiun gerbang tol tol dengan 3 gerbang berbeda: Gerbang Kuning (Natrium) membuka sekejap membuat arus mobil melesat masuk (depolarisasi). Gerbang Merah (Kalsium) membuka agak lama memberi tenaga mekanik mesin. Gerbang Biru (Kalium) membuka di akhir untuk mengalirkan mobil keluar membersihkan jalur kembali tenang (repolarisasi).',
      explanation: 'Jika gerbang pintu ion tersebut rusak karena mutasi genetik (kanalopati), arus listrik menjadi kacau dan dapat memicu irama jantung liar yang mematikan (seperti pada Sindrom Brugada atau Long QT).'
    },
    stepByStepGuide: [
      {
        stepNumber: 1,
        title: 'Kalsium: Pemicu Tarikan Otot',
        description: 'Kalsium adalah saklar kimiawi. Begitu kalsium menyentuh protein Troponin C, kawat tropomiosin tergeser, memungkinkan kepala miosin mencengkeram aktin dan memeras otot memendek.'
      },
      {
        stepNumber: 2,
        title: 'Gas Nitric Oxide (NO): Pelemas Pembuluh Darah',
        description: 'Dinding pembuluh darah memproduksi gas alami Nitric Oxide (NO) yang memerintahkan otot pembuluh darah untuk rileks melebar (vasodilatasi), sehingga tekanan darah turun dan aliran darah lancar.'
      }
    ],
    commonMisconceptions: [
      {
        myth: 'Kalsium dalam tubuh hanya berfungsi untuk memperkuat tulang dan gigi.',
        fact: 'Kalsium bebas intraseluler adalah molekul mutlak yang mengendalikan setiap detakan jantung; tanpa influks kalsium, otot jantung tidak akan pernah bisa berkontraksi.'
      }
    ],
    quickQuiz: {
      question: 'Molekul gas alami apakah yang diproduksi oleh lapisan endotel pembuluh darah untuk menyebabkan pelebaran pembuluh darah (vasodilatasi)?',
      options: [
        'Karbon Monoksida (CO)',
        'Nitric Oxide (NO)',
        'Oksigen murni (O2)',
        'Nitrogen dioksida (NO2)'
      ],
      correctIndex: 1,
      explanation: 'Nitric Oxide (NO) diproduksi oleh enzim eNOS pada sel endotel dan mengaktifkan cGMP untuk memicu relaksasi otot polos vaskular.'
    }
  }
};
