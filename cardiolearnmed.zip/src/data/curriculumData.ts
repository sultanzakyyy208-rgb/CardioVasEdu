import { CurriculumModule } from '../types/cardio';

export const CURRICULUM_MODULES: CurriculumModule[] = [
  {
    id: 'anatomi',
    order: 1,
    title: '1. Anatomi Sistem Kardiovaskular',
    subtitle: 'Morfologi Makroskopis Jantung, Vaskularisasi Koroner, Katup & Sistem Konduksi',
    skdiCompetence: 'Tingkat Kemampuan 4A',
    duration: '18 Jam Pembelajaran Kuliah & Praktikum Anatomi',
    image: '/src/assets/images/hero_cardio_faculty_1791009153598.jpg',
    overview: 'Mempelajari arsitektur anatomi jantung manusia secara topografis dan fungsional, mencakup mediastinum medium, 4 rongga jantung, aparatus katup atrioventrikular dan semilunar, percabangan arteri koronaria sinistra dan dextra, serta jalur konduksi intrinsik.',
    subtopics: [
      {
        id: 'anatomi_morfologi',
        title: 'Morfologi Eksterna & Interna 4 Rongga Jantung',
        subtitle: 'Atrium Dextrum, Ventriculus Dexter, Atrium Sinistrum, Ventriculus Sinister',
        summary: 'Jantung terletak di mediastinum medius dibungkus oleh perikardium. Basis cordis menghadap ke posterior superior, sedangkan apex cordis dibentuk oleh ventrikel kiri pada spatium intercostale (SIC) V linea medioclavicularis sinistra.',
        keyPoints: [
          'Atrium Dextrum: Menerima darah vena dari VCS, VCI, dan Sinus Coronarius. Memiliki auricula dextra, crista terminalis, mm. pectinati, serta fossa ovalis (sisa foramen ovale).',
          'Ventriculus Dexter: Memiliki trabeculae carneae, mm. papillares (anterior, posterior, septal), chordae tendineae, trabecula septomarginalis (moderator band yang membawa cabang berkas His kanan), serta infundibulum (conus arteriosus).',
          'Atrium Sinistrum: Memiliki dinding posterior licin menerima 4 venae pulmonales (2 dextra, 2 sinistra). Dinding berotot hanya terdapat pada auricula sinistra.',
          'Ventriculus Sinister: Memiliki dinding miokardium tebal (3x lebih tebal dari ventrikel kanan untuk mengatasi resistensi vaskular sistemik), 2 mm. papillares besar (anterior dan posterior), serta vestibule aorta.'
        ],
        clinicalPearls: [
          'Pungsi perikardium (pericardiocentesis) dilakukan melalui sudut infrasternal (antara proc. xiphoideus dan arcus costalis sinistra) diarahkan ke bahu kiri untuk menghindari tusukan a. thoracica interna.',
          'Apex cordis bergeser ke lateroinferior pada hipertrofi atau dilatasi ventrikel kiri (LVH / cardiomegaly).'
        ],
        medicalContent: [
          {
            heading: 'Orientasi Spasial & Batas Topografis Jantung',
            paragraphs: [
              'Jantung berada miring di dalam cavitas thoracica dengan dua pertiga massanya berada di sebelah kiri garis mediana tubuh. Fasad anterior (sternocostal) utamanya dibentuk oleh ventriculus dexter, fasad inferior (diaphragmatic) dibentuk oleh ventriculus sinister dan sebagian dexter, sedangkan fasad posterior (basis) dibentuk terutama oleh atrium sinistrum.',
              'Sulcus coronarius memisahkan atrium dari ventrikel, sementara sulcus interventricularis anterior dan posterior menandai batas antar-ventrikel tempat berjalannya cabang-cabang vaskular utama.'
            ]
          },
          {
            heading: 'Aparatus Katup Jantung (Valvular Complex)',
            paragraphs: [
              'Katup atrioventrikular terdiri dari Valva Tricuspidalis (tiga kuspis: anterior, posterior, septal) di sisi kanan dan Valva Bicuspidalis/Mitralis (dua kuspis: anterior dan posterior) di sisi kiri. Kedua katup ini dihubungkan dengan mm. papillares melalui chordae tendineae yang mencegah eversi (prolaps) kuspis ke dalam atrium selama sistol ventrikel.',
              'Katup semilunar meliputi Valva Aortae dan Valva Pulmonalis yang masing-masing terdiri dari tiga kuspis semilunaris berbentuk kantung (nodulus dan lunula). Di atas kuspis aorta terdapat sinus aortae (Valsalva) yang merupakan tempat asal arteri koronaria dextra dan sinistra.'
            ]
          }
        ]
      },
      {
        id: 'anatomi_koroner',
        title: 'Vaskularisasi Koroner & Drainase Vena',
        subtitle: 'Left Coronary Artery (LAD & LCx), Right Coronary Artery, Sinus Coronarius',
        summary: 'Perfusi arteri koroner terjadi terutama saat fase diastol ventrikel ketika kompresi miokardium mereda dan sinus Valsalva terisi oleh recoil elastik aorta.',
        keyPoints: [
          'Arteria Coronaria Sinistra (LCA): Berasal dari sinus aortae anterior kiri. Bercabang menjadi Ramus Interventricularis Anterior (LAD) yang mensuplai 2/3 anterior septum interventrikular, apeks, dan dinding anterior LV; serta Ramus Circumflexus (LCx) yang mensuplai dinding lateral LV.',
          'Arteria Coronaria Dextra (RCA): Berasal dari sinus aortae anterior kanan. Mensuplai nodus SA (60%), nodus AV (90%), dinding ventrikel kanan, dan pada 85-90% populasi mempercabangkan Posterior Descending Artery (PDA) -> dominansi kanan (right-dominant).',
          'Vena Cordis Magna, Media, dan Parva bermuara ke dalam Sinus Coronarius yang membuka ke dinding posterior atrium dextrum tepat di medial orifisium VCI.'
        ],
        clinicalPearls: [
          'LAD sering dijuluki "widow maker" karena oklusi akut LAD proksimal menyebabkan infark miokard anterior luas dengan risiko tinggi syok kardiogenik dan sudden cardiac death.',
          'Infark miokard inferior akibat oklusi RCA sering disertai komplikasi bradiaritmia (AV block total) karena iskemia pada nodus AV.'
        ],
        medicalContent: [
          {
            heading: 'Konsep Dominansi Sirkulasi Koroner',
            paragraphs: [
              'Dominansi koroner ditentukan oleh arteri mana yang mempercabangkan Ramus Interventricularis Posterior (PDA) yang berjalan di sulcus interventricularis posterior mensuplai sepertiga posterior septum. Sekitar 85% individu adalah right-dominant (dari RCA), 10% left-dominant (dari LCx), dan 5% codominant (PDA disuplai oleh anastomosis cabang RCA dan LCx).'
            ]
          }
        ]
      },
      {
        id: 'anatomi_konduksi',
        title: 'Sistem Konduksi Jantung Intrinsik',
        subtitle: 'Nodus SA, Nodus AV, Berkas His, Serat Purkinje',
        summary: 'Aktivasi elektrik intrinsik jantung dimulai dari pacemaker fisiologis (Nodus Sinoatrialis) dan disebarkan ke miokardium melalui jaringan serat penghantar khusus yang terkoordinasi.',
        keyPoints: [
          'Nodus SA: Terletak subepikardial pada batas antara vena cava superior dan atrium dextrum di crista terminalis. Memiliki laju otomatisitas intrinsik tertinggi (60-100 kali/menit).',
          'Nodus AV: Terletak subendokardial di basis septum interatriale di segitiga Koch (antara perlekatan kuspis septal katup trikuspid, tendo Todaro, dan orifisium sinus coronarius). Mengalami perlambatan konduksi fisiologis (0.05-0.12 detik) untuk memastikan pengisian ventrikel tuntas sebelum sistol.',
          'Fasciculus Atrioventricularis (Bundle of His): Menembus anulus fibrosus cordis (satu-satunya koneksi elektrik fisiologis antara atrium dan ventrikel) dan bercabang menjadi Crus Dextrum dan Crus Sinistrum (yang terbagi lagi menjadi fasikulus anterior dan posterior).'
        ],
        clinicalPearls: [
          'Jalur aksesori abnormal yang memotong anulus fibrosus (bundle of Kent) menyebabkan pre-eksitasi ventrikel yang dikenal sebagai Sindrom Wolff-Parkinson-White (WPW), dengan gambaran gelombang Delta dan PR interval pendek pada EKG.'
        ],
        medicalContent: [
          {
            heading: 'Kerangka Fibrosa Jantung (Anulus Fibrosus)',
            paragraphs: [
              'Skeleton fibrosum cordis terdiri dari empat cincin fibrosa yang mengelilingi orifisium katup dan dua trigonum fibrosum (dextrum dan sinistrum). Struktur ini berfungsi sebagai tempat perlekatan katup dan miokardium, sekaligus bertindak sebagai insulator elektrik yang mencegah perambatan impuls langsung dari atrium ke ventrikel kecuali melalui berkas His.'
            ]
          }
        ]
      }
    ]
  },
  {
    id: 'fisiologi',
    order: 2,
    title: '2. Fisiologi Sistem Kardiovaskular',
    subtitle: 'Siklus Jantung, Diagram Wiggers, Elektrofisiologi & Hemodinamika',
    skdiCompetence: 'Tingkat Kemampuan 4A',
    duration: '22 Jam Pembelajaran Kuliah, Praktikum EKG & Simulasi Hemodinamika',
    image: '/src/assets/images/hero_cardio_faculty_1791009153598.jpg',
    overview: 'Menganalisis prinsip biofisika dan elektrofisiologi fungsi jantung. Membedah kurva tekanan-volume, relasi Frank-Starling, regulasi barorefleks otonom, dinamika mikrosirkulasi Starling, serta korelasi elektrokardiografi dengan fase mekanis siklus jantung.',
    subtopics: [
      {
        id: 'fisiologi_siklus_wiggers',
        title: 'Siklus Jantung & Analisis Diagram Wiggers',
        subtitle: 'Fase Sistol, Diastol, Fluktuasi Tekanan Aorta-Ventrikel & Bunyi Jantung',
        summary: 'Siklus jantung terdiri dari 7 fase mekanis yang berlangsung sekitar 0.8 detik pada denyut jantung 75 bpm. Diagram Wiggers memadukan kurva tekanan aorta, ventrikel kiri, atrium kiri, volume ventrikel, EKG, dan fonokardiogram secara simultan.',
        keyPoints: [
          'Fase 1 - Kontraksi Atrium (Atrial Systole): Didahului gelombang P pada EKG. Menghasilkan kontribusi aktif pengisian ventrikel sebesar 15-20% (atrial kick). Menghasilkan gelombang "a" pada kurva tekanan vena jugularis (JVP).',
          'Fase 2 - Kontraksi Isovolumetrik: Dimulai setelah penutupan katup mitral (terdengar Bunyi Jantung 1 / S1). Semua katup tertutup, volume darah di ventrikel konstan (End-Diastolic Volume ~120 mL), namun tekanan intraventrikel melonjak tajam melampaui tekanan aorta.',
          'Fase 3 - Ejeksi Cepat (Rapid Ejection): Katup aorta terbuka ketika tekanan ventrikel melebihi 80 mmHg. Sekitar 70% Stroke Volume (SV ~70 mL) diejeksikan ke aorta.',
          'Fase 4 - Ejeksi Lambat: Aliran keluar melambat, repolarisasi ventrikel terjadi (gelombang T). Tekanan ventrikel mulai menurun.',
          'Fase 5 - Relaksasi Isovolumetrik: Katup aorta menutup akibat recoil darah (menimbulkan Bunyi Jantung 2 / S2 dan insisura dikrotik pada kurva tekanan aorta). Semua katup tertutup, volume konstan pada End-Systolic Volume (ESV ~50 mL).',
          'Fase 6 - Pengisian Cepat Ventrikel (Rapid Inflow): Katup mitral membuka ketika tekanan LV turun di bawah tekanan atrium. Menghasilkan bunyi jantung S3 fisiologis pada anak atau patologis pada gagal jantung.',
          'Fase 7 - Diastasis (Pengisian Lambat): Pengisian pasif ventrikel berlanjut hingga kontraksi atrium berikutnya.'
        ],
        clinicalPearls: [
          'Pada Fibrilasi Atrium (AFib), hilangnya kontraksi atrium yang terkoordinasi (loss of atrial kick) dapat menurunkan Cardiac Output hingga 20-30%, memicu dekompensasi akut pada pasien stenosis mitral atau disfungsi diastolik.',
          'Bunyi Jantung S4 (atrial gallop) selalu patologis, terjadi saat atrium memompa melawan ventrikel yang kaku akibat hipertrofi konsentrik (hipertensi kronik, kardiomiopati hipertrofik).'
        ],
        medicalContent: [
          {
            heading: 'Fisiologi Pembentukan Bunyi Jantung S1 dan S2',
            paragraphs: [
              'Bunyi Jantung S1 (LUB) dihasilkan dari vibrasi mendadak akibat penutupan katup atrioventrikular (komponen M1 mitral mendahului T1 trikuspid). S1 terdengar paling keras di apeks kordis.',
              'Bunyi Jantung S2 (DUB) disebabkan oleh penutupan katup semilunar (komponen A2 aorta mendahului P2 pulmonal). Selama inspirasi, peningkatan venous return ke ventrikel kanan memperlambat ejeksi RV sehingga memperlebar pemisahan A2-P2 (fisiologis splitting).'
            ]
          }
        ]
      },
      {
        id: 'fisiologi_potensial_aksi',
        title: 'Elektrofisiologi Selular Jantung & Konduksi',
        subtitle: 'Fast Response Action Potential vs Slow Response Pacemaker Potential',
        summary: 'Sel miokardium kerja (ventrikel dan atrium) memperlihatkan potensial aksi respons cepat dengan fase plateau khas, sedangkan sel pacemaker (nodus SA dan AV) memiliki otomatisitas respons lambat tanpa fase plateau yang diperantarai oleh funny current (If).',
        keyPoints: [
          'Fase 0 (Depolarisasi Cepat): Pembukaan kanal Na+ berpintu voltase (Nav1.5) yang memicu influks masif Na+. Amplitudo melonjak dari -90 mV ke +20 mV.',
          'Fase 1 (Repolarisasi Awal Singkat): Inaktivasi kanal Na+ dan aktivasi singkat kanal K+ efluks transient outward (Ito).',
          'Fase 2 (Plateau Khas): Keseimbangan dinamis antara influks lambat kalsium melalui kanal Ca2+ tipe L (Cav1.2) dan efluks kalium melalui kanal delayed rectifier (IKr dan IKs). Mencegah tetani miokardium.',
          'Fase 3 (Repolarisasi Cepat Akhir): Penutupan kanal Ca2+ dan pembukaan penuh kanal K+ delayed rectifier yang mengembalikan potensial membran ke tingkat istirahat.',
          'Fase 4 (Potensial Membran Istirahat): Dipertahankan stabil pada -90 mV oleh kanal inward rectifier K+ (IK1) dan pompa Na+/K+-ATPase.',
          'Pacemaker (Nodus SA): Potensial istirahat tidak stabil (~ -60 mV). Depolarisasi spontan fase 4 disebabkan oleh kanal If (Funny current yang menghantarkan Na+ teraktivasi hiperpolarisasi) dan kanal Ca2+ tipe T/L.'
        ],
        clinicalPearls: [
          'Obat Ivabradine secara selektif menghambat kanal If di nodus SA, memperlambat denyut jantung tanpa menurunkan kontraktilitas miokardium (efek lusitropik dan inotropik netral).',
          'Kanal IKr yang dikode oleh gen KCNH2 (hERG) sangat rentan diblok oleh berbagai obat non-kardiovaskular (makrolida, kuinolon, antipsikotik), memicu pemanjangan interval QT (Long QT Syndrome) dan risiko aritmia fatal Torsades de Pointes.'
        ],
        medicalContent: [
          {
            heading: 'Periode Refrakter Fisiologis Miokardium',
            paragraphs: [
              'Periode Refrakter Efektif (ERP) berlangsung dari fase 0 hingga pertengahan fase 3. Selama periode ini, tidak ada stimulus elektrik apapun yang dapat mencetuskan potensial aksi baru karena inaktivasi kanal Na+. Hal ini krusial untuk mencegah kontraksi tetanik dan memungkinkan relaksasi serta pengisian ventrikel yang adekuat.'
            ]
          }
        ]
      },
      {
        id: 'fisiologi_hemodinamika',
        title: 'Hemodinamika, Frank-Starling & Regulasi Kardiovaskular',
        subtitle: 'Preload, Afterload, Kontraktilitas, Cardiac Output & Baroreceptor Reflex',
        summary: 'Cardiac Output (CO = Heart Rate x Stroke Volume) diatur secara terkoordinasi oleh mekanisme intrinsik heterometrik (Frank-Starling law) dan regulasi neurohumoral ekstrinsik.',
        keyPoints: [
          'Hukum Frank-Starling: Peningkatan venous return menyebabkan peningkatan volume akhir diastolik (Preload), meregangkan kardiomiosit ke panjang sarkomer optimal (~2.2 um), sehingga meningkatkan sensitivitas troponin C terhadap kalsium dan menghasilkan gaya kontraksi serta Stroke Volume yang lebih besar.',
          'Afterload: Beban resistensi yang harus diatasi ventrikel untuk membuka katup semilunar dan mengejeksikan darah. Dipengaruhi langsung oleh Systemic Vascular Resistance (SVR) dan elastisitas arteri sistemik (dijelaskan oleh hukum Laplace: Tegangan Dinding = [Tekanan x Radius] / [2 x Tebal Dinding]).',
          'Refleks Baroreseptor: Baroreseptor mekanik regangan pada Sinus Caroticus (diinervasi nervus glossopharyngeus / CN IX via n. Hering) dan Arcus Aortae (diinervasi nervus vagus / CN X) mendeteksi perubahan tekanan arteri rata-rata (MAP).',
          'Hipotensi mendadak memicu penurunan firing rate baroreseptor, melepaskan inhibisi pada nucleus tractus solitarius (NTS) -> mengaktivasi sistem saraf simpatis -> vasokonstriksi arteriol, takikardia, dan peningkatan inotropi.'
        ],
        clinicalPearls: [
          'Hukum Laplace menjelaskan mengapa dilatasi ventrikel pada gagal jantung kongestif meningkatkan kebutuhan oksigen miokardium: peningkatan radius ventrikel secara proporsional melipatgandakan wall stress yang harus ditanggung miokardium.',
          'Pemberian vasodilator nitroprusid atau ACE inhibitor menurunkan afterload, meningkatkan Stroke Volume pada ventrikel yang gagal tanpa meningkatkan konsumsi oksigen.'
        ],
        medicalContent: [
          {
            heading: 'Persamaan Matematis Kunci Hemodinamika',
            paragraphs: [
              '1. Cardiac Output (CO) = Heart Rate (HR) x Stroke Volume (SV). Nilai normal dewasa: 4.5 - 6.0 L/menit (Cardiac Index: 2.5 - 4.0 L/min/m2).',
              '2. Mean Arterial Pressure (MAP) = Diastolic Blood Pressure + 1/3 (Systolic Blood Pressure - Diastolic Blood Pressure). Atau MAP = (CO x SVR) + CVP.',
              '3. Ejection Fraction (EF) = (Stroke Volume / End-Diastolic Volume) x 100%. Nilai normal: 55% - 70%.'
            ]
          }
        ]
      }
    ]
  },
  {
    id: 'histologi',
    order: 3,
    title: '3. Histologi Sistem Kardiovaskular',
    subtitle: 'Mikroarsitektur Kardiomiosit, Diskus Interkalaris, dan Struktur Pembuluh Darah',
    skdiCompetence: 'Tingkat Kemampuan 4A',
    duration: '16 Jam Pembelajaran Kuliah & Praktikum Mikroskopis',
    image: '/src/assets/images/histology_myocardium_microscope_1791009169554.jpg',
    overview: 'Mengkaji mikroskopis jaringan kardiak: struktur sinsitium fungsional miosit kardiak, taut interselular (fascia adherens, desmosom, gap junction), histogenesis endokardium dan perikardium, serta diferensiasi histologis arteri elastika, muskularis, arteriol, dan mikrosirkulasi kapiler.',
    subtopics: [
      {
        id: 'histologi_miokardium',
        title: 'Histologi Kardiomiosit & Kompleks Diskus Interkalaris',
        subtitle: 'Sinsitium Fungsional, Retikulum Sarkoplasma, dan Triad vs Dyad',
        summary: 'Kardiomiosit adalah sel silindris bercabang dengan 1-2 inti sentral oval pucat. Sel-sel ini disatukan dari ujung ke ujung oleh diskus interkalaris membentuk sinsitium mekanik dan elektrik fungsional.',
        keyPoints: [
          'Kardiomiosit: Memiliki banyak mitokondria (40% volume sel, mencerminkan ketergantungan mutlak pada metabolisme aerobik), granula glikogen, serta pigmen lipofuscin ("pigmen aus/penuaan") perinuklear pada usia lanjut.',
          'Diskus Interkalaris (Intercalated Disc): Struktur berundak dengan dua komponen:',
          '- Komponen Transversal: Fascia adherens (tempat insersi mikrofilamen aktin dari sarkomer terminal) dan Macula adherens (desmosom yang mengikat filamen intermediet desmin, mencegah pemisahan sel saat kontraksi kuat).',
          '- Komponen Longitudinal: Gap junctions (nexus yang tersusun dari heksamer protein connexin-43) yang memberikan resistensi elektrik sangat rendah, memungkinkan difusi ion cepat dan sinkronisasi eksitasi.',
          'Tubulus T & Diad: Tubulus T kardiomiosit jauh lebih besar daripada otot rangka, terletak pada tingkat garis Z (bukan sambungan A-I). Membentuk struktur "Diad" dengan satu sisterna terminal retikulum sarkoplasma kecil.'
        ],
        clinicalPearls: [
          'Mutasi gen yang mengkode protein desmosom kardiak (seperti plakophilin-2, desmoplakin) menyebabkan penyakit Arrhythmogenic Right Ventricular Cardiomyopathy (ARVC), ditandai dengan penggantian miokardium ventrikel kanan oleh jaringan fibro-adiposa dan aritmia ventrikel fatal pada atlet muda.',
          'Pada iskemia akut, asidosis intraselular menyebabkan penutupan (gating) gap junction connexin-43, mengisolasi sel yang rusak secara elektrik namun memicu aritmia re-entry.'
        ],
        medicalContent: [
          {
            heading: 'Serat Purkinje (Purkinje Fibers)',
            paragraphs: [
              'Serat Purkinje adalah kardiomiosit yang dimodifikasi khusus untuk hantaran impuls cepat (2-4 m/detik vs 0.5 m/detik pada miosit kerja). Berukuran lebih besar, memiliki sedikit myofibril perifer, kaya akan sitoplasma bervakuola yang dipenuhi glikogen, sehingga tampak lebih pucat pada pewarnaan hematoksilin-eosin (H&E).'
            ]
          }
        ]
      },
      {
        id: 'histologi_pembuluh',
        title: 'Histologi Dinding Vaskular & Mikrosirkulasi',
        subtitle: 'Tunika Intima, Media, Adventitia, Arteri Elastika vs Muskularis, dan Kapiler',
        summary: 'Semua pembuluh darah berdiameter lebih besar dari kapiler memiliki pola organisasi trilaminar konsentris: tunika intima, tunika media, dan tunika adventitia.',
        keyPoints: [
          'Tunika Intima: Terdiri dari selapis sel endotel gepeng bertumpu pada lamina basalis, lapisan subendotelial jaringan ikat longgar, dan membrana elastica interna (paling jelas pada arteri muskularis).',
          'Tunika Media: Terdiri dari sel-sel otot polos yang tersusun sirkular dan serabut elastin/kolagen.',
          '- Arteri Elastika (Aorta, Truncus Pulmonalis): Tunika media didominasi oleh 40-70 lembaran fenestrated elastis tebal (membran elastis Konsentris) yang memberikan efek Windkessel.',
          '- Arteri Muskularis (Arteri Distributif): Tunika media didominasi oleh lapisan konsentris otot polos (hingga 40 lapisan), diapit oleh membrana elastica interna dan externa.',
          'Tunika Adventitia: Jaringan ikat fibroelastis longgar yang mengandung kolagen tipe I, vasa vasorum (pembuluh darah penutrisi dinding pembuluh besar), dan nervi vasorum simpatis.',
          'Arteriol: Pembuluh resistensi utama dengan 1-3 lapisan otot polos, mengatur tekanan darah sistemik dan aliran kapiler.',
          'Tipe Kapiler: Kontinu (otot, otak/BBB dengan tight junctions z. occludens), Bertingkap/Fenestrated (glomerulus ginjal, villi usus, kelenjar endokrin), dan Sinusoid/Diskontinu (hati, limpa, sumsum tulang).'
        ],
        clinicalPearls: [
          'Efek Windkessel dari recoil elastis tunika media aorta saat diastol mempertahankan tekanan darah diastolik konstan (~80 mmHg) dan menjamin aliran darah koroner yang kontinu saat katup aorta menutup.',
          'Degenerasi serabut elastis tunika media aorta (cystic medial necrosis) akibat penuaan atau Sindrom Marfan menyebabkan diseksi aorta akut yang mengancam nyawa.'
        ],
        medicalContent: [
          {
            heading: 'Fungsi Biologis Sel Endotel Vaskular',
            paragraphs: [
              'Endotel bukan sekadar sawar fisik pasif, melainkan organ endokrin yang aktif menyintesis molekul antikoagulan (trombomodulin, prostasiklin/PGI2, heparan sulfat), vasodilator (Nitric Oxide, EDHF), vasokonstriktor (Endotelin-1, Angiotensin II), dan molekul adhesi leukosit (ICAM-1, VCAM-1, E-selektin).'
            ]
          }
        ]
      }
    ]
  },
  {
    id: 'biokimia',
    order: 4,
    title: '4. Biokimia Sistem Kardiovaskular',
    subtitle: 'Biomarker Jantung, Metabolisme Energi Miokardium & Patobiokimia Plak Ateroma',
    skdiCompetence: 'Tingkat Kemampuan 4A',
    duration: '18 Jam Pembelajaran Kuliah & Praktikum Kimia Klinik',
    image: '/src/assets/images/pathology_atherosclerosis_plaque_1791009195854.jpg',
    overview: 'Mempelajari dasar biomolekuler fungsi kardiak: kinetika pelepasan Troponin I/T kardiak ultrasensitif (hs-cTn), sintesis dan pemecahan peptida natriuretik (BNP/NT-proBNP), pergeseran substrat energetik dari beta-oksidasi asam lemak ke glikolisis anaerob saat iskemia, serta kaskade oksidasi LDL dan pembentukan sel busa dalam aterogenesis.',
    subtopics: [
      {
        id: 'biokimia_biomarker',
        title: 'Biomarker Nekrosis Miokardium & Gagal Jantung',
        subtitle: 'Kinetika Troponin I/T Ultrasensitif, CK-MB, Myoglobin & Jalur BNP/NT-proBNP',
        summary: 'Kerusakan membran sarkolema miosit pada infark miokard melepaskan protein intraselular ke sirkulasi darah dengan pola kinetika waktu yang khas.',
        keyPoints: [
          'Cardiac Troponin (cTnI dan cTnT): Gold standard biomarker nekrosis miokard. Memiliki isoform asam amino unik yang tidak diekspresikan pada otot rangka. Mulai meningkat pada 2-4 jam pasca-onset, memuncak pada 24 jam, dan menetap tinggi selama 7-14 hari.',
          'High-Sensitivity Troponin (hs-cTn): Mampu mendeteksi konsentrasi troponin pikogram/mL, memungkinkan diagnosis atau eksklusi (rule-out) infark miokard akut dalam 1-2 jam pertama onset.',
          'CK-MB (Creatine Kinase Myocardial Band): Meningkat 4-6 jam, puncak 18-24 jam, kembali normal dalam 48-72 jam. Sangat berguna untuk mendeteksi re-infark (infark berulang) dini karena waktu paruhnya yang singkat.',
          'B-type Natriuretic Peptide (BNP & NT-proBNP): Dilepaskan oleh kardiomiosit ventrikel sebagai respons terhadap regangan dinding ventrikel berlebihan (wall stress) dan kelebihan volume. NT-proBNP memiliki waktu paruh lebih panjang (120 menit vs 20 menit pada BNP) dan diekskresikan melalui ginjal.'
        ],
        clinicalPearls: [
          'Obat golongan ARNI (Sacubitril/Valsartan) menghambat enzim neprilisin yang mendegradasi BNP, sehingga kadar BNP darah akan meningkat semu; oleh karena itu, pemantauan klinis pasien yang mendapat sacubitril harus menggunakan NT-proBNP (karena NT-proBNP bukan substrat neprilisin).',
          'Peningkatan troponin juga dapat terjadi tanpa ruptur plak aterotrombotik (Infark Miokard Tipe 2), misalnya pada takiaritmia berat, sepsis berat, krisis hipertensi, atau emboli paru masif akibat ketidakseimbangan pasokan-kebutuhan oksigen (supply-demand mismatch).'
        ],
        medicalContent: [
          {
            heading: 'Fisiologi Sistem Peptida Natriuretik',
            paragraphs: [
              'Pre-proBNP dipecah menjadi proBNP (108 asam amino), yang kemudian dipecah oleh protease corin atau furin menjadi dua fragmen: peptida aktif BNP (32 asam amino) dan fragmen inaktif NT-proBNP (76 asam amino). BNP berikatan dengan reseptor NPR-A yang mengaktivasi guanylyl cyclase intraselular, meningkatkan siklik GMP (cGMP) dan protein kinase G (PKG), menghasilkan natriuresis, diuresis, vasodilatasi sistemik, serta inhibisi remodeling fibrotik miokardium.'
            ]
          }
        ]
      },
      {
        id: 'biokimia_energetik',
        title: 'Metabolisme Energi & Transisi Substrat Miokardium',
        subtitle: 'Beta-Oksidasi Asam Lemak, Glikolisis, dan Kaskade Iskemia-Reperfusi',
        summary: 'Jantung mengonsumsi energi ATP dalam jumlah masif untuk mempertahankan siklus kontraksi-relaksasi tanpa henti. Dalam kondisi normal, 60-80% ATP dihasilkan dari oksidasi beta asam lemak dan 20-40% dari glukosa/laktat.',
        keyPoints: [
          'Oksidasi Beta Asam Lemak: Merupakan sumber energi paling kaya ATP per mol substrat, berlangsung di matriks mitokondria via sistem carnitine palmitoyltransferase (CPT-1 dan CPT-2). Namun membutuhkan konsumsi molekul oksigen yang lebih tinggi per mol ATP yang dihasilkan dibanding glukosa.',
          'Kondisi Hipoksia/Iskemia: Penurunan PO2 menghentikan fosforilasi oksidatif mitokondria. Terjadi pergeseran ke glikolisis anaerobik, menghasilkan akumulasi laktat, penurunan drastis pH intraselular (asidosis metabolik < 6.8), dan deplesi cepat simpanan fosfokreatin dan ATP.',
          'Cedera Iskemia-Reperfusi (Ischemia-Reperfusion Injury): Pengaliran kembali oksigen secara mendadak memicu pembentukan Reactive Oxygen Species (ROS) masif dari kompleks I/III mitokondria, membuka Mitochondrial Permeability Transition Pore (mPTP), menyebabkan kolaps potensial membran mitokondria dan kematian sel nekro-apoptosis.'
        ],
        clinicalPearls: [
          'Trimetazidine bekerja dengan menghambat enzim 3-ketoacyl CoA thiolase (KAT) pada beta-oksidasi asam lemak, mengalihkan metabolisme energi kardiak ke oksidasi glukosa yang lebih hemat oksigen, digunakan sebagai terapi anti-angina metabolik.',
          'Asidosis intraselular saat iskemia menyebabkan H+ bersaing dengan Ca2+ untuk berikatan pada troponin C, menyebabkan disfungsi kontraktil langsung dalam hitungan detik setelah onset oklusi koroner.'
        ],
        medicalContent: [
          {
            heading: 'Homeostasis Kalsium Eksitasi-Kontraksi (Calcium Cycling)',
            paragraphs: [
              'Influks Ca2+ melalui kanal tipe-L memicu pelepasan kalsium dalam jumlah jauh lebih besar dari retikulum sarkoplasma melalui reseptor Ryanodine (RyR2) - proses Calcium-Induced Calcium Release (CICR). Relaksasi miokardium (lusitropi) membutuhkan pemompaan kembali Ca2+ ke lumen SR oleh pompa SERCA2a yang diregulasi oleh protein fosfolamban (PLN), serta ekstrusi ke ekstraselular oleh penukar Na+/Ca2+ (NCX).'
            ]
          }
        ]
      }
    ]
  },
  {
    id: 'embriologi',
    order: 5,
    title: '5. Embriologi Sistem Kardiovaskular',
    subtitle: 'Medan Kardiogenik, Looping Jantung, Septasi Rongga, dan Kelainan Kongenital',
    skdiCompetence: 'Tingkat Kemampuan 4A',
    duration: '16 Jam Pembelajaran Kuliah & Embriologi Klinis',
    image: '/src/assets/images/embryology_heart_looping_1791009182413.jpg',
    overview: 'Menelusuri perkembangan kardiovaskular sejak gastrulasi: migrasi sel mesoderm splanknik medang kardiogenik primer/sekunder, pembentukan tabung jantung primitif, pelipatan (D-looping), septasi atrium dan ventrikel, migrasi sel krista neuralis pada septasi aorta-pulmonal, derivat arkus aorta faringeal, serta mekanisme embryologis kelainan jantung bawaan sianotik dan non-sianotik.',
    subtopics: [
      {
        id: 'embriologi_looping_septasi',
        title: 'Morfogenesis Tabung Jantung & Pembentukan Sekat',
        subtitle: 'D-Looping, Septasi Atrium, Ventrikel, dan Bantalan Endokardium',
        summary: 'Jantung adalah organ fungsional pertama embrio yang mulai berdenyut pada hari ke-21 hingga 22 pasca-fertilisasi. Tabung jantung primitif mengalami pembelokan ke arah ventral dan dekstral (D-looping) pada hari ke-23-28.',
        keyPoints: [
          'Segmen Tabung Jantung Primitif (Caudal ke Cranial): Sinus venosus -> Atrium primitif -> Ventriculus primitif -> Bulbus cordis -> Truncus arteriosus.',
          'Bulbus Cordis terbagi menjadi: bagian proksimal (membentuk trabekulasi ventrikel kanan), conus cordis (membentuk infundibulum/outflow tract kedua ventrikel), dan truncus arteriosus (membentuk pangkal aorta dan truncus pulmonalis).',
          'Septasi Atrium: Dimulai dari pertumbuhan Septum Primum dari atap atrium menuju bantalan endokardium (endocardial cushion), meninggalkan celah Ostium Primum. Sebelum ostium primum tertutup, apoptosis membentuk Ostium Secundum. Kemudian Septum Secundum tumbuh di sisi kanan, menyisakan lubang oval berkatup yang disebut Foramen Ovale.',
          'Septasi Ventrikel: Septum interventriculare pars muscularis tumbuh ke arah kranial dari dasar ventrikel, sedangkan pars membranacea dibentuk oleh fusi bantalan endokardium atrioventrikular inferior dan rigi bulbar spiral.'
        ],
        clinicalPearls: [
          'Dextrocardia dengan Situs Inversus terjadi akibat defek motilitas silia nodus primitif embrio (Sindrom Kartagener / Dyskinesia Silia Primer) yang mengganggu simetri kiri-kanan dan memicu L-looping tabung jantung ke arah kiri.',
          'Defek septum atrium (ASD) tipe secundum merupakan defek paling sering, timbul akibat resorpsi berlebihan septum primum atau defisiensi pertumbuhan septum secundum.'
        ],
        medicalContent: [
          {
            heading: 'Peran Sel Krista Neuralis (Cardiac Neural Crest Cells)',
            paragraphs: [
              'Sel krista neuralis cranial bermigrasi dari lipatan saraf hindbrain melalui arkus faringeal 3, 4, dan 6 menuju outflow tract jantung. Sel-sel ini membentuk sekat spiral (aorticopulmonary septum) yang membelah truncus arteriosus menjadi aorta ascendens dan truncus pulmonalis. Kegagalan migrasi krista neuralis (misalnya pada sindrom delesi 22q11.2 / DiGeorge) mengakibatkan Persistent Truncus Arteriosus, Tetralogy of Fallot, atau Interrupted Aortic Arch.'
            ]
          }
        ]
      },
      {
        id: 'embriologi_sirkulasi_fetus',
        title: 'Sirkulasi Fetus & Transisi Hemodinamik Pasca-Lahir',
        subtitle: 'Ductus Venosus, Foramen Ovale, Ductus Arteriosus & Perubahan Sirkulasi Saat Lahir',
        summary: 'Sirkulasi janin dirancang untuk mendistribusikan darah kaya oksigen dari plasenta ke organ vital (otak dan miokardium) dengan memotong (shunting) paru-paru yang belum berfungsi.',
        keyPoints: [
          'Tiga Pirau Fisiologis Fetus:',
          '1. Ductus Venosus: Menyalurkan 50% darah vena umbilikalis kaya oksigen (saturasi O2 ~80%) langsung ke VCI, memotong sinusoid hati.',
          '2. Foramen Ovale: Mengarahkan aliran darah beroksigen dari VCI melintasi septum interatriale langsung ke atrium kiri -> ventrikel kiri -> aorta asendens untuk perfusi serebral dan koroner.',
          '3. Ductus Arteriosus (Botalli): Menghubungkan bifurkasio truncus pulmonalis ke arkus aorta desendens distal dari percabangan a. subclavia sinistra, membelokkan 90% curah ventrikel kanan dari sirkulasi paru yang resistensinya tinggi.',
          'Transisi Saat Lahir: Pemotongan tali pusat menghilangkan sirkulasi plasenta beresistensi rendah, meningkatkan resistensi sistemik (SVR). Ekspansi paru-paru dan oksigenasi menurunkan pulmonary vascular resistance (PVR) secara drastis.',
          'Tekanan atrium kiri melampaui atrium kanan -> menekan katup septum primum ke septum secundum -> penutupan fungsional foramen ovale.',
          'Peningkatan PaO2 darah dan penurunan kadar prostaglandin E2 (PGE2) sirkulasi memicu vasokonstriksi otot polos tunika media ductus arteriosus, menutupnya menjadi Ligamentum Arteriosum dalam 24-48 jam.'
        ],
        clinicalPearls: [
          'Patent Ductus Arteriosus (PDA) sering terjadi pada bayi prematur akibat ketidakmatangan respons vasokonstriksi terhadap oksigen. Diterapi secara medikamentosa dengan inhibitor siklooksigenase (Indometasin atau Ibuprofen intravena) untuk memblok sintesis prostaglandin.',
          'Sebaliknya, pada penyakit jantung bawaan dengan ductal-dependent circulation (seperti Transposition of Great Arteries atau Coarctatio Aortae berat), infus Prostaglandin E1 (Alprostadil) wajib diberikan untuk mempertahankan patensi duktus.'
        ],
        medicalContent: [
          {
            heading: 'Derivat Struktur Vaskular Pasca-Lahir',
            paragraphs: [
              '- Vena Umbilicalis -> Ligamentum Teres Hepatis.',
              '- Ductus Venosus -> Ligamentum Venosum.',
              '- Arteriae Umbilicales -> Ligamenta Umbilicalia Medialia.',
              '- Ductus Arteriosus -> Ligamentum Arteriosum.',
              '- Foramen Ovale -> Fossa Ovalis.'
            ]
          }
        ]
      }
    ]
  },
  {
    id: 'penyakit',
    order: 6,
    title: '6. Penyakit Terkait Sistem Kardiovaskular',
    subtitle: 'Sindrom Koroner Akut, Gagal Jantung, Valvulopati, Aritmia & Krisis Hipertensi',
    skdiCompetence: 'Tingkat Kemampuan 4A & 3B',
    duration: '28 Jam Pembelajaran Kuliah, Bedside Teaching & Diskusi Kasus CBT',
    image: '/src/assets/images/pathology_atherosclerosis_plaque_1791009195854.jpg',
    overview: 'Mempelajari etiologi, patofisiologi, manifestasi klinis, kriteria diagnosis definitif (EKG, biomarker, pencitraan), serta tatalaksana gawat darurat dan jangka panjang penyakit kardiovaskular mayor sesuai Standar Kompetensi Dokter Indonesia (SKDI) dan pedoman klinis PERKI / ESC / AHA.',
    subtopics: [
      {
        id: 'penyakit_ska',
        title: 'Sindrom Koroner Akut (SKA / ACS)',
        subtitle: 'STEMI, NSTEMI, Unstable Angina Pectoris, dan Stratifikasi Risiko Killip',
        summary: 'Sindrom Koroner Akut timbul akibat erosi atau ruptur plak aterosklerotik yang memicu agregasi trombosit dan pembentukan trombus intraluminal akut.',
        keyPoints: [
          'Spektrum SKA:',
          '- ST-Elevation Myocardial Infarction (STEMI): Oklusi trombus total transmural. EKG menunjukkan elevasi segmen ST konveks >= 1 mm pada dua sadapan prekordial/ekstremitas yang bersebelahan (>= 2 mm pada V2-V3 pria), atau Left Bundle Branch Block (LBBB) baru. Biomarker troponin positif.',
          '- NSTEMI: Oklusi trombus subtotal atau iskemia subendokardial. EKG menunjukkan depresi segmen ST, inversi gelombang T simetris dalam, atau gelombang datar. Biomarker troponin positif.',
          '- Unstable Angina Pectoris (UAP): Nyeri dada iskemia saat istirahat (angina crescendo/de novo) dengan EKG normal atau nondiagnostik, namun biomarker troponin NEGATIF.',
          'Tatalaksana Emergensi Awal: Oksigen (hanya jika SaO2 < 90%), Aspilet dosis loading 160-320 mg kunyah, inhibitor reseptor P2Y12 (Ticagrelor 180 mg atau Clopidogrel 300-600 mg), Nitrat sublingual (kontraindikasi jika TD sistolik < 90 mmHg, infark RV, atau pemakaian PDE5 inhibitor 24 jam terakhir), serta Morfin IV jika nyeri refrakter.',
          'Strategi Reperfusi STEMI: Percutaneous Coronary Intervention (PCI) primer merupakan terapi pilihan utama (door-to-device target < 90 menit). Jika PCI tidak dapat dilakukan dalam waktu < 120 menit sejak kontak medis pertama, terapi fibrinolisis (Streptokinase atau Alteplase/tPA) harus diberikan dalam 30 menit (door-to-needle < 30 menit).'
        ],
        clinicalPearls: [
          'Pada infark inferior (ST elevasi pada sadapan II, III, aVF), SELALU rekam EKG sadapan kanan (V3R-V4R) untuk menyingkirkan Infark Ventrikel Kanan. Infark RV sangat tergantung pada preload: pemberian nitrat atau morfin dapat menyebabkan hipotensi sirkulasi kolaps yang fatal; tatalaksana utamanya adalah hidrasi cairan kristaloid intravena!',
          'Kriteria Sgarbossa digunakan untuk mendiagnosis STEMI pada pasien dengan gambaran LBBB atau irama pacu ventrikel.'
        ],
        medicalContent: [
          {
            heading: 'Klasifikasi Killip untuk Prognosis Infark Miokard',
            paragraphs: [
              'Killip I: Tidak ada tanda gagal jantung kongestif (mortalitas ~6%).',
              'Killip II: Ronki basah halus pada <50% lapang paru, S3 gallop, peningkatan JVP (mortalitas ~17%).',
              'Killip III: Edema paru akut berat, ronki basah pada >50% lapang paru (mortalitas ~38%).',
              'Killip IV: Syok kardiogenik dengan TD sistolik < 90 mmHg, oliguria, sianosis, vasokonstriksi perifer dingin (mortalitas >60%).'
            ]
          }
        ]
      },
      {
        id: 'penyakit_gagal_jantung',
        title: 'Gagal Jantung (Heart Failure) & Kardiomiopati',
        subtitle: 'HFrEF vs HFpEF, Kriteria Framingham, Klasifikasi NYHA, dan Guideline-Directed Medical Therapy',
        summary: 'Sindrom klinis kompleks yang ditandai dengan gejala sesak napas (dyspnea on exertion, orthopnea, PND), kelelahan, dan tanda retensi cairan akibat kelainan struktural atau fungsional pengisian maupun ejeksi ventrikel.',
        keyPoints: [
          'Kategori Berdasarkan Ejection Fraction (LVEF):',
          '- Heart Failure with reduced EF (HFrEF): LVEF <= 40% (disfungsi sistolik dominan).',
          '- Heart Failure with mildly reduced EF (HFmrEF): LVEF 41-49%.',
          '- Heart Failure with preserved EF (HFpEF): LVEF >= 50% dengan bukti disfungsi diastolik, peningkatan peptide natriuretik, atau penyakit struktural (LVH/LA enlargement).',
          'Diagnosis: Memenuhi 2 kriteria mayor atau 1 mayor + 2 minor Framingham.',
          '- Kriteria Mayor: PND, orthopnea, distensi vena jugularis, ronki basah basal bilateral, kardiomegali pada rontgen toraks, edema paru akut, S3 gallop, peningkatan CVP > 16 cmH2O, refluks hepatojugular positif.',
          '- Kriteria Minor: Edema ekstremitas bilateral, batuk malam hari, dyspnea d’effort, hepatomegali, efusi pleura, takikardia (>120 bpm), penurunan kapasitas vital 1/3.',
          'Farmakoterapi Empat Pilar (Fantastic Four) HFrEF:',
          '1. ARNI (Sacubitril/Valsartan) atau ACE-inhibitor / ARB.',
          '2. Beta-Blocker berbasis bukti (Bisoprolol, Carvedilol, Metoprolol suksinat) dimulai saat kondisi klinis euvolemik.',
          '3. Mineralocorticoid Receptor Antagonist / MRA (Spironolakton atau Eplerenon).',
          '4. SGLT2 Inhibitor (Dapagliflozin atau Empagliflozin) yang menurunkan rawat inap dan mortalitas kardiovaskular terlepas dari ada tidaknya diabetes melitus.'
        ],
        clinicalPearls: [
          'Beta-blocker TIDAK BOLEH dimulai atau dinaikkan dosisnya pada pasien dalam kondisi Gagal Jantung Akut Dekompensasi (ADHF) dengan overload cairan berat atau hipotensi karena efek inotropik negatif akutnya dapat memperburuk syok kardiogenik.',
          'Diuretik loop (Furosemid) sangat efektif untuk mengontrol gejala kongesti cairan, namun tidak memiliki bukti klinis memperpanjang harapan hidup (mortality benefit); sedangkan empat pilar GDMT terbukti menurunkan mortalitas jangka panjang secara signifikan.'
        ],
        medicalContent: [
          {
            heading: 'Klasifikasi Fungsional NYHA vs Stadium ACC/AHA',
            paragraphs: [
              'NYHA Kelas I: Aktivitas fisik biasa tidak menyebabkan sesak atau lelah berlebih.',
              'NYHA Kelas II: Sedikit keterbatasan fisik. Nyaman saat istirahat, namun aktivitas biasa (naik tangga 1 lantai) memicu sesak.',
              'NYHA Kelas III: Keterbatasan fisik bermakna. Aktivitas ringan (berjalan di kamar, berpakaian) sudah menimbulkan gejala.',
              'NYHA Kelas IV: Tidak mampu melakukan aktivitas apapun tanpa keluhan; gejala sesak napas muncul bahkan saat berbaring istirahat.'
            ]
          }
        ]
      },
      {
        id: 'penyakit_aritmia_katup',
        title: 'Aritmia Kardiak & Penyakit Katup Jantung',
        subtitle: 'Atrial Fibrillation, Takikardia Ventrikel, Blok AV, Stenosis Mitral & Regurgitasi Aorta',
        summary: 'Gangguan pembentukan atau konduksi impuls elektrik jantung serta disfungsi mekanis aparatus katup memicu morbiditas emboli sistemik, sinkop, dan gagal sirkulasi.',
        keyPoints: [
          'Fibrilasi Atrium (AFib): Karakteristik EKG: tidak ada gelombang P teratur (digantikan gelombang fibrilasi halus f berombak), interval R-R yang sama sekali tidak beraturan (irregularly irregular). Komplikasi utama: stroke kardioembolik akibat trombus di auricula sinistra.',
          'Stratifikasi Risiko Emboli AFib: Skor CHA2DS2-VASc (CHF, Hypertension, Age >=75 [2], Diabetes, Stroke/TIA [2], Vascular disease, Age 65-74, Sex female). Skor >= 2 pada pria atau >= 3 pada wanita wajib mendapat terapi Antikoagulan Oral Langsung (DOAC: Rivaroxaban, Apixaban, Dabigatran) atau Warfarin.',
          'Aritmia Ventrikel Mengancam Jiwa: Ventricular Tachycardia (VT) dengan kompleks QRS lebar (>0.12 detik) reguler dan disosiasi AV; serta Ventricular Fibrillation (VF) dengan gelombang elektrik kacau tidak beraturan. VF dan pulseless VT adalah ritme henti jantung "shockable" yang membutuhkan defibrilasi unsynchronized segera.',
          'Penyakit Katup Jantung Utama:',
          '- Stenosis Mitral (MS): Etiologi tersering penyakit jantung reumatik. Auskultasi: Opening snap pasca-S2 diikuti gemuruh middiastolik (mid-diastolic rumbling murmur) dengan aksentuasi presistolik di apeks.',
          '- Insufisiensi/Regurgitasi Mitral (MR): Auskultasi: Murmur pansistolik (holosistolik) nada tinggi meniup di apeks menjalar ke aksila kiri.',
          '- Stenosis Aorta (AS): Trias klasik (SAD: Syncope, Angina, Dyspnea). Auskultasi: Murmur ejeksi sistolik kresendo-dekresendo di SIC II linea sternalis dextra menjalar ke arteri karotis, disertai pulsus parvus et tardus.',
          '- Insufisiensi/Regurgitasi Aorta (AR): Auskultasi: Murmur dini diastolik berdesir nada tinggi di batas sternal kiri, disertai widened pulse pressure dan tanda vaskular perifer (Corrigan’s pulse, Quincke’s sign).'
        ],
        clinicalPearls: [
          'Pada Stenosis Aorta berat, penggunaan vasodilator kuat (nitrat) dikontraindikasikan karena penurunan afterload mendadak tanpa kemampuan ventrikel meningkatkan curah melewati katup yang kaku dapat memicu sinkop berat dan kolaps sirkulasi.',
          'Kardioversi elektrik tersinkronisasi (synchronized cardioversion) digunakan untuk takiaritmia tidak stabil yang memiliki kompleks QRS (seperti VT dengan nadi, AFib dengan respons ventrikel cepat), sedangkan defibrilasi asinkron hanya untuk VF dan Pulseless VT.'
        ],
        medicalContent: [
          {
            heading: 'Derajat Blok Atrioventrikular (AV Block)',
            paragraphs: [
              '1. AV Block Derajat 1: Interval PR konstan memanjang > 0.20 detik (5 kotak kecil) tanpa ada gelombang P yang drop.',
              '2. AV Block Derajat 2 Mobitz I (Wenckebach): Pemanjangan interval PR progresif pada setiap denyut berturut-turut hingga satu gelombang P gagal dihantarkan (QRS drop). Biasanya benigna di nodus AV.',
              '3. AV Block Derajat 2 Mobitz II: Interval PR konstan (normal atau memanjang), diselingi kegagalan konduksi gelombang P yang mendadak tanpa pemanjangan bertahap sebelumnya. Berbahaya, lesi infranodal, berisiko tinggi progresif ke blok total.',
              '4. AV Block Derajat 3 (Total AV Block): Disosiasi atrioventrikular komplit; atrium dan ventrikel berdenyut independen (laju P > laju QRS). Membutuhkan pacu jantung temporer / permanen.'
            ]
          }
        ]
      }
    ]
  },
  {
    id: 'biologi_detail',
    order: 7,
    title: '7. Lengkap Seluruh Materi Biologi Detail Sistem Kardiovaskular',
    subtitle: 'Biologi Molekuler Kanal Ion, Sinyal Endotel NO, Sitoskeleton Sarkomer & Genetika Kardiak',
    skdiCompetence: 'Tingkat Kemampuan 4A',
    duration: '20 Jam Pembelajaran Kuliah, Laboratorium Molekuler & Jurnal Kedokteran',
    image: '/src/assets/images/hero_cardio_faculty_1791009153598.jpg',
    overview: 'Penjelasan komprehensif biologi seluler dan molekuler kardiovaskular tingkat lanjut: struktur sub-unit kanal ion Nav1.5 dan Cav1.2, biologi molekuler sarkomer (titin, troponin C-I-T, nebulin), kaskade persinyalan Nitric Oxide sintase endotel (eNOS-sGC-cGMP), mekanisme vaskulogenesis dan angiogenesis (VEGF/VEGFR2), serta kelainan genetik kardiomiopati monogenik dan kanalopati familial.',
    subtopics: [
      {
        id: 'biologi_kanal_ion',
        title: 'Biologi Molekuler Kanal Ion & Kanalopati Familial',
        subtitle: 'Struktur Domain SCN5A, KCNH2, CACNA1C, Brugada & Long QT Syndrome',
        summary: 'Potensial aksi jantung dikendalikan secara presisi oleh kanal ion membran integral yang memiliki domain sensor voltase (S4) dan pori selektivitas ion (S5-S6).',
        keyPoints: [
          'SCN5A (Kanal Natrium Jantung Nav1.5): Terdiri dari 4 domain homolog (I-IV) yang masing-masing memiliki 6 segmen transmembran (S1-S6). Segmen S4 kaya akan residu arginin bermuatan positif yang bertindak sebagai sensor voltase.',
          '- Mutasi Loss-of-Function SCN5A: Mengurangi arus depolarisasi natrium fase 0 -> memicu Sindrom Brugada (elevasi ST tipe coved saddleback di sadapan V1-V3 dengan risiko kematian mendadak / SCD).',
          '- Mutasi Gain-of-Function SCN5A: Memperlambat inaktivasi kanal Na+, menimbulkan arus natrium lambat persisten (late INa) -> memicu Long QT Syndrome Tipe 3 (LQT3).',
          'KCNH2 (Kanal Kalium hERG / IKr): Menghantarkan kalium keluar untuk repolarisasi fase 3. Mutasi gen ini menyebabkan LQT2 (sering terpicu oleh stimulus auditorik mendadak seperti suara alarm).',
          'CACNA1C (Kanal Kalsium Cav1.2): Menghantarkan arus ICa,L pada fase 2 plateau. Mutasi aktivasi memicu Sindrom Timothy (LQT8 dengan sindaktili dan autisme).',
          'Kanal KATP (Kir6.2 / SUR2A): Kanal kalium yang dihambat oleh ATP intraselular. Terbuka saat iskemia kardiak berat ketika ATP turun, memfasilitasi efluks kalium untuk memperpendek durasi potensial aksi dan menghemat energi.'
        ],
        clinicalPearls: [
          'Pasien Sindrom Brugada memiliki EKG yang sangat peka terhadap demam; suhu tubuh tinggi memfasilitasi inaktivasi termal mutan kanal Nav1.5, sehingga antipiretik agresif wajib diberikan saat pasien demam untuk mencegah takikardia ventrikel polimorfik.',
          'Obat antiaritmia Ranolazine secara selektif menghambat arus late-INa, mengurangi beban kalsium intraseluler melalui penukar NCX dan memperbaiki relaksasi diastolik miokardium.'
        ],
        medicalContent: [
          {
            heading: 'Regulasi Fosforilasi Kanal Ion oleh Protein Kinase',
            paragraphs: [
              'Stimulasi reseptor beta-1 adrenergik oleh epinefrin mengaktivasi protein Gs -> adenilat siklase -> pembentukan cAMP -> aktivasi Protein Kinase A (PKA). PKA memfosforilasi kanal Cav1.2 (meningkatkan influks kalsium / efek inotropik positif), reseptor RyR2 (mempercepat pelepasan kalsium SR), dan fosfolamban (mempercepat uptake kalsium oleh SERCA2a / efek lusitropik positif).'
            ]
          }
        ]
      },
      {
        id: 'biologi_sarkomer_sinyal',
        title: 'Mekanika Sarkomer, Sinyal Endotel NO & Angiogenesis',
        subtitle: 'Protein Titin, Troponin-Tropomiosin Cross-Bridge, eNOS-cGMP, dan VEGF',
        summary: 'Kontraksi kardiak adalah interaksi mekanokimiawi yang digerakkan oleh hidrolisis ATP pada kepala miosin, sedangkan tonus vaskular diatur oleh sinyal parakrin endotelial.',
        keyPoints: [
          'Arsitektur Sarkomer:',
          '- Filamen Tebal: Molekul miosin II yang tersusun heksamer (2 heavy chains dengan domain kepala ATPase dan 4 light chains).',
          '- Filamen Tipis: Polimer aktin-F heliks ganda yang diasosiasikan dengan kompleks tropomiosin dan troponin (TnT mengikat tropomiosin, TnI menghambat pengikatan miosin, TnC mengikat Ca2+).',
          '- Titin: Protein raksasa terbesar dalam tubuh manusia (>3 megadalton) yang merentang dari garis Z ke garis M, bertindak sebagai pegas molekuler yang memberikan elastisitas pasif dan menjaga keselarasan filamen tebal.',
          'Jalur Sinyal Endothelial Nitric Oxide (eNOS):',
          'Shear stress aliran darah mengaktivasi kanal kalsium mekanosensitif -> influks Ca2+ berikatan dengan kalmodulin -> mengaktivasi eNOS (NOS3). eNOS mengubah asam amino L-arginin dan O2 menjadi gas Nitric Oxide (NO) dan L-sitrulin.',
          'Gas NO berdifusi ke sel otot polos vaskular sekitarnya, menstimulasi Soluble Guanylyl Cyclase (sGC) untuk mengubah GTP menjadi cGMP -> mengaktivasi Protein Kinase G (PKG) -> memfosforilasi phospholamban dan menurunkan Ca2+ bebas sitosol -> defosforilasi Myosin Light Chain (MLC) -> vasodilatasi arteriol.',
          'Vaskulogenesis & Angiogenesis: Dipicu oleh hipoksia jaringan melalui aktivasi faktor transkripsi HIF-1alpha (Hypoxia-Inducible Factor 1). HIF-1alpha meningkatkan sekresi Vascular Endothelial Growth Factor A (VEGF-A) yang berikatan dengan reseptor tirosin kinase VEGFR2 pada sel endotel, merangsang pembelahan, pembentukan tip cells, dan pembentukan tunas pembuluh darah baru.'
        ],
        clinicalPearls: [
          'Mutasi gen titin (TTN truncating variants / TTNtv) merupakan penyebab genetik paling sering dari Kardiomiopati Dilatasi (DCM) familial, terhitung pada 20-25% kasus idiopatik.',
          'Obat Sildenafil dan Tadalafil adalah inhibitor selektif Fosfodiesterase-5 (PDE-5), enzim yang memecah cGMP menjadi 5-GMP; dengan mencegah degradasi cGMP, obat ini mempertahankan vasodilatasi pada sirkulasi arteri pulmonalis untuk terapi Hipertensi Pulmonal.'
        ],
        medicalContent: [
          {
            heading: 'Genetika Kardiomiopati Hipertrofik (HCM)',
            paragraphs: [
              'Kardiomiopati Hipertrofik diturunkan secara autosomal dominan dengan penetrasi bervariasi. Lebih dari 50% kasus disebabkan oleh mutasi pada gen penyusun sarkomer: gen MYH7 (rantai berat beta-miosin) dan MYBPC3 (protein pengikat miosin C kardiak). Karakteristik histopatologisnya menunjukkan disarray kardiomiosit (kekacauan orientasi berkas serat miosit) dan fibrosis interstisial luas.'
            ]
          }
        ]
      }
    ]
  }
];

export const ANATOMICAL_PINS = [
  {
    id: 'pin_aorta',
    name: 'Aorta Ascendens & Arcus Aortae',
    latinName: 'Aorta ascendens & arcus aortae',
    position: [0.1, 1.4, 0.2] as [number, number, number],
    category: 'vessel' as const,
    description: 'Arteri elastika terbesar tubuh yang menerima darah beroksigen langsung dari ventrikel kiri dengan tekanan puncak sistolik ~120 mmHg. Mempercabangkan truncus brachiocephalicus, a. carotis communis sinistra, dan a. subclavia sinistra.',
    clinicalSignificance: 'Lokasi predileksi pembentukan aneurisma aorta dan diseksi aorta tipe Stanford A yang memerlukan pembedahan emergensi segera.',
    bloodFlowType: 'oxygenated' as const
  },
  {
    id: 'pin_pulm_trunk',
    name: 'Truncus Pulmonalis',
    latinName: 'Truncus pulmonalis',
    position: [-0.4, 1.1, 0.5] as [number, number, number],
    category: 'vessel' as const,
    description: 'Membawa darah deoksigenasi dari ventriculus dexter menuju ke paru-paru kanan dan kiri melalui arteria pulmonalis dextra dan sinistra.',
    clinicalSignificance: 'Tempat bersarangnya emboli paru masif (saddle embolus) yang dapat menyebabkan gagal ventrikel kanan akut dan henti jantung kolaps.',
    bloodFlowType: 'deoxygenated' as const
  },
  {
    id: 'pin_la',
    name: 'Atrium Sinistrum',
    latinName: 'Atrium sinistrum',
    position: [-0.6, 0.6, -0.6] as [number, number, number],
    category: 'chamber' as const,
    description: 'Rongga berdinding posterior licin yang menerima empat venae pulmonales yang kaya oksigen dari paru-paru. Memiliki auricula sinistra.',
    clinicalSignificance: 'Dilatasi atrium kiri akibat stenosis mitral atau hipertensi kronik sering menjadi substrat anatomis timbulnya Fibrilasi Atrium dan trombus di aurikula sinistra.',
    bloodFlowType: 'oxygenated' as const
  },
  {
    id: 'pin_lv',
    name: 'Ventriculus Sinister',
    latinName: 'Ventriculus sinister',
    position: [-0.5, -0.3, 0.5] as [number, number, number],
    category: 'chamber' as const,
    description: 'Rongga berdinding miokardium paling tebal (8-12 mm) yang memompa darah ke seluruh sirkulasi sistemik melalui katup aorta.',
    clinicalSignificance: 'Tempat terjadinya hipertrofi konsentrik (pada hipertensi/stenosis aorta) atau dilatasi (pada kardiomiopati/infark luas) yang berujung pada gagal jantung.',
    bloodFlowType: 'oxygenated' as const
  },
  {
    id: 'pin_ra',
    name: 'Atrium Dextrum',
    latinName: 'Atrium dextrum',
    position: [0.8, 0.5, 0.3] as [number, number, number],
    category: 'chamber' as const,
    description: 'Rongga yang menerima darah vena sistemik dari Vena Cava Superior, Vena Cava Inferior, dan Sinus Coronarius.',
    clinicalSignificance: 'Tempat Nodus Sinoatrialis (SA Node) dan Nodus Atrioventrikularis (AV Node) berada di dalam trigonum Koch.',
    bloodFlowType: 'deoxygenated' as const
  },
  {
    id: 'pin_rv',
    name: 'Ventriculus Dexter',
    latinName: 'Ventriculus dexter',
    position: [0.3, -0.3, 0.8] as [number, number, number],
    category: 'chamber' as const,
    description: 'Rongga berdinding bulan sabit (crescent) dengan trabeculae carneae tebal yang memompa darah ke sirkulasi pulmonal bertekanan rendah.',
    clinicalSignificance: 'Rentan mengalami kegagalan fungsi sekunder akibat hipertensi pulmonal berat (Cor Pulmonale).',
    bloodFlowType: 'deoxygenated' as const
  },
  {
    id: 'pin_lad',
    name: 'Left Anterior Descending Artery (LAD)',
    latinName: 'Ramus interventricularis anterior',
    position: [-0.1, 0.0, 0.9] as [number, number, number],
    category: 'vessel' as const,
    description: 'Cabang utama arteri koronaria sinistra yang berjalan di sulcus interventricularis anterior menuju apeks cordis.',
    clinicalSignificance: 'Merupakan arteri yang paling sering mengalami oklusi aterotrombotik pada STEMI anterior ekstensif ("widow-maker artery").',
    bloodFlowType: 'oxygenated' as const
  },
  {
    id: 'pin_sa_node',
    name: 'Nodus Sinoatrialis (SA Node)',
    latinName: 'Nodus sinoatrialis',
    position: [0.7, 0.9, -0.1] as [number, number, number],
    category: 'conduction' as const,
    description: 'Pacemaker alami primer jantung dengan laju otomatisitas 60-100 kali/menit, terletak subepikardial pada crista terminalis dekat orifisium VCS.',
    clinicalSignificance: 'Disfungsi nodus SA menyebabkan Sick Sinus Syndrome (bradikardia berat, sinus arrest, atau sindrom bradi-taki).',
    bloodFlowType: 'conduction' as const
  },
  {
    id: 'pin_av_node',
    name: 'Nodus Atrioventrikularis (AV Node)',
    latinName: 'Nodus atrioventricularis',
    position: [0.2, 0.3, -0.1] as [number, number, number],
    category: 'conduction' as const,
    description: 'Terletak di apex trigonum Koch subendokardial di basis septum interatriale. Berfungsi memperlambat hantaran impuls ~0.1 detik.',
    clinicalSignificance: 'Menjamin koordinasi waktu antara pengisian ventrikel dan kontraksi ventrikel; target ablasi pada AVNRT.',
    bloodFlowType: 'conduction' as const
  }
];
