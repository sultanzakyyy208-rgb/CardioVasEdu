import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Heart3DViewer } from './components/Heart3DViewer';
import { ModuleReader } from './components/ModuleReader';
import { WiggersSimulator } from './components/Simulators/WiggersSimulator';
import { EcgSimulator } from './components/Simulators/EcgSimulator';
import { HistologyMicroscope } from './components/Simulators/HistologyMicroscope';
import { PvLoopSimulator } from './components/Simulators/PvLoopSimulator';
import { CBTExamView } from './components/CBTExam/CBTExamView';
import { LecturerDeck } from './components/LecturerMode/LecturerDeck';
import { BeginnerFlowWalkthrough } from './components/BeginnerFlowWalkthrough';
import { CURRICULUM_MODULES } from './data/curriculumData';
import { ModuleId, AnatomicalPin } from './types/cardio';
import { 
  Heart, 
  Activity, 
  BookOpen, 
  Award, 
  Microscope, 
  Sliders, 
  Presentation, 
  ChevronRight, 
  ArrowRight,
  Sparkles,
  ShieldCheck
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'3d' | 'modules' | 'simulators' | 'cbt' | 'lecturer'>('3d');
  const [activeSimulator, setActiveSimulator] = useState<'wiggers' | 'ecg' | 'histology' | 'pvloop'>('wiggers');
  const [selectedModuleId, setSelectedModuleId] = useState<ModuleId>('anatomi');
  const [highlightedPin, setHighlightedPin] = useState<AnatomicalPin | null>(null);

  const handleOpenSimulator = (simType: '3d' | 'wiggers' | 'ecg' | 'histology' | 'pvloop') => {
    if (simType === '3d') {
      setActiveTab('3d');
    } else {
      setActiveSimulator(simType);
      setActiveTab('simulators');
    }
  };

  const handleOpenCBT = (modId: ModuleId) => {
    setSelectedModuleId(modId);
    setActiveTab('cbt');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Strict 3-Zone Top Navigation Bar */}
      <Navbar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onQuickStartCBT={() => setActiveTab('cbt')}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8">
        {/* Tab 1: Interactive 3D Heart Structure View */}
        {activeTab === '3d' && (
          <div className="space-y-8 animate-in fade-in duration-300">
            {/* Hero Header with Unboxed Metadata */}
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-800 pb-5">
              <div>
                <div className="flex items-center gap-2 text-xs text-rose-400 font-semibold tracking-wide uppercase mb-1.5">
                  <span>Laboratorium Virtual Anatomi Kardiovaskular</span>
                  <span aria-hidden="true">·</span>
                  <span>Model Dinamis 3D Interaktif</span>
                  <span aria-hidden="true">·</span>
                  <span>SKDI Tingkat Kemampuan 4A</span>
                </div>
                <h1 className="text-2xl sm:text-4xl font-bold text-white tracking-tight">
                  Struktur Anatomi 3D Jantung & Siklus Kontraksi
                </h1>
                <p className="text-sm text-slate-300 max-w-3xl mt-2 leading-relaxed">
                  Visualisasikan empat ruang jantung, percabangan arteri koroner sinistra dan dextra, aparatus katup, serta jaras konduksi nodus SA ke Purkinje dengan pemisahan lapisan (layer peeling) dan simulasi aliran darah teroksigenasi.
                </p>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                <button
                  onClick={() => setActiveTab('modules')}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg transition-colors border border-slate-700 flex items-center gap-1.5"
                >
                  <BookOpen className="w-4 h-4" />
                  <span>Pelajari 7 Modul Lengkap</span>
                </button>
              </div>
            </div>

            {/* Three.js 3D Heart Canvas Component */}
            <Heart3DViewer onSelectPin={(pin) => setHighlightedPin(pin)} />

            {/* Beginner Foundation: Blood Flow 6 Steps & Interactive Glossary */}
            <BeginnerFlowWalkthrough />

            {/* Curriculum Module Cards Grid below 3D */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-lg font-bold text-white tracking-tight">
                    Kurikulum Terintegrasi 7 Pilar Biomedik-Klinis
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Materi komprehensif dari struktur dasar hingga patologi klinis untuk mahasiswa kedokteran & dosen
                  </p>
                </div>

                <button
                  onClick={() => setActiveTab('modules')}
                  className="text-xs text-rose-400 hover:text-rose-300 font-semibold flex items-center gap-1 transition-colors"
                >
                  <span>Buka Semua Modul</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {CURRICULUM_MODULES.slice(0, 4).map((mod) => (
                  <button
                    key={mod.id}
                    onClick={() => {
                      setSelectedModuleId(mod.id);
                      setActiveTab('modules');
                    }}
                    className="group bg-slate-900 border border-slate-800 rounded-xl p-4 text-left transition-all hover:border-slate-700 hover:bg-slate-800/80 flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between text-[11px] text-slate-400 mb-2">
                        <span className="font-mono text-rose-400 font-bold">Modul 0{mod.order}</span>
                        <span>{mod.skdiCompetence}</span>
                      </div>
                      <h4 className="text-sm font-bold text-white group-hover:text-rose-400 transition-colors leading-snug">
                        {mod.title.split('.')[1]}
                      </h4>
                      <p className="text-xs text-slate-400 mt-2 line-clamp-2 leading-relaxed">
                        {mod.overview}
                      </p>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                      <span>{mod.subtopics.length} Sub-Topik</span>
                      <span className="text-rose-400 group-hover:translate-x-0.5 transition-transform">→</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: 7 Modules Comprehensive Textbook Reader */}
        {activeTab === 'modules' && (
          <div className="animate-in fade-in duration-300">
            <ModuleReader
              initialModuleId={selectedModuleId}
              onOpenSimulator={handleOpenSimulator}
              onOpenCBT={handleOpenCBT}
            />
          </div>
        )}

        {/* Tab 3: Medical Interactive Simulators */}
        {activeTab === 'simulators' && (
          <div className="space-y-6 animate-in fade-in duration-300">
            {/* Simulator Switcher Segmented Control */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div>
                <div className="flex items-center gap-2 text-xs text-rose-400 font-semibold tracking-wide uppercase mb-1">
                  <span>Praktikum Fisiologi & Patologi Digital</span>
                  <span aria-hidden="true">·</span>
                  <span>Simulasi Biofisika Kardiovaskular</span>
                </div>
                <h2 className="text-2xl font-bold text-white tracking-tight">
                  Laboratorium Simulasi Interaktif
                </h2>
              </div>

              {/* Segmented Buttons */}
              <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs">
                <button
                  onClick={() => setActiveSimulator('wiggers')}
                  className={`px-3 py-1.5 rounded-lg font-semibold transition-colors flex items-center gap-1.5 ${
                    activeSimulator === 'wiggers' ? 'bg-rose-600 text-white shadow' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Activity className="w-3.5 h-3.5" />
                  <span>Diagram Wiggers</span>
                </button>

                <button
                  onClick={() => setActiveSimulator('ecg')}
                  className={`px-3 py-1.5 rounded-lg font-semibold transition-colors flex items-center gap-1.5 ${
                    activeSimulator === 'ecg' ? 'bg-rose-600 text-white shadow' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Heart className="w-3.5 h-3.5" />
                  <span>Simulator EKG</span>
                </button>

                <button
                  onClick={() => setActiveSimulator('histology')}
                  className={`px-3 py-1.5 rounded-lg font-semibold transition-colors flex items-center gap-1.5 ${
                    activeSimulator === 'histology' ? 'bg-rose-600 text-white shadow' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Microscope className="w-3.5 h-3.5" />
                  <span>Mikroskop Histologi</span>
                </button>

                <button
                  onClick={() => setActiveSimulator('pvloop')}
                  className={`px-3 py-1.5 rounded-lg font-semibold transition-colors flex items-center gap-1.5 ${
                    activeSimulator === 'pvloop' ? 'bg-rose-600 text-white shadow' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Sliders className="w-3.5 h-3.5" />
                  <span>PV Loop Hemodinamik</span>
                </button>
              </div>
            </div>

            {/* Active Simulator Component Rendering */}
            {activeSimulator === 'wiggers' && <WiggersSimulator />}
            {activeSimulator === 'ecg' && <EcgSimulator />}
            {activeSimulator === 'histology' && <HistologyMicroscope />}
            {activeSimulator === 'pvloop' && <PvLoopSimulator />}
          </div>
        )}

        {/* Tab 4: CBT Exam System (12,000 Questions) */}
        {activeTab === 'cbt' && (
          <div className="animate-in fade-in duration-300">
            <CBTExamView />
          </div>
        )}

        {/* Tab 5: Faculty Lecturer Mode */}
        {activeTab === 'lecturer' && (
          <div className="animate-in fade-in duration-300">
            <LecturerDeck />
          </div>
        )}
      </main>

      {/* Clean Domain-Authentic Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-8 mt-16 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-300">CardioLearnMed</span>
            <span aria-hidden="true">·</span>
            <span>Platform Pembelajaran Dosen & Mahasiswa Fakultas Kedokteran</span>
            <span aria-hidden="true">·</span>
            <span>Standar SKDI Kardiovaskular</span>
          </div>

          <div className="flex items-center gap-4 text-slate-400">
            <span>Bank Soal: 12.000 Kasus Klinis</span>
            <span aria-hidden="true">·</span>
            <span>Format Jawaban & Pembahasan Lengkap</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
