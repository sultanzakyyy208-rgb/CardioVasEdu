export type ModuleId = 
  | 'anatomi' 
  | 'fisiologi' 
  | 'histologi' 
  | 'biokimia' 
  | 'embriologi' 
  | 'penyakit' 
  | 'biologi_detail';

export interface AnatomicalPin {
  id: string;
  name: string;
  latinName: string;
  position: [number, number, number];
  category: 'chamber' | 'valve' | 'vessel' | 'conduction' | 'pericardium';
  description: string;
  clinicalSignificance: string;
  bloodFlowType: 'oxygenated' | 'deoxygenated' | 'mixed' | 'conduction';
}

export interface SubTopic {
  id: string;
  title: string;
  subtitle: string;
  summary: string;
  keyPoints: string[];
  clinicalPearls: string[];
  medicalContent: {
    heading: string;
    paragraphs: string[];
    diagramLabel?: string;
    clinicalVignette?: {
      scenario: string;
      takeaway: string;
    };
  }[];
}

export interface CurriculumModule {
  id: ModuleId;
  order: number;
  title: string;
  subtitle: string;
  skdiCompetence: string;
  duration: string;
  image: string;
  overview: string;
  subtopics: SubTopic[];
}

export interface CBTQuestion {
  id: number;
  moduleId: ModuleId;
  moduleName: string;
  skdiLevel: 'SKDI 1' | 'SKDI 2' | 'SKDI 3A' | 'SKDI 3B' | 'SKDI 4A';
  difficulty: 'Mudah' | 'Sedang' | 'Sulit';
  clinicalScenario: {
    patientAge: number;
    patientGender: 'Laki-laki' | 'Perempuan';
    chiefComplaint: string;
    historyOfPresentIllness: string;
    physicalExam: {
      bp: string;
      hr: string;
      rr: string;
      temp: string;
      cardiacFindings: string;
      otherFindings: string;
    };
    diagnosticTests: string;
  };
  vignetteText: string;
  questionPrompt: string;
  options: {
    label: 'A' | 'B' | 'C' | 'D' | 'E';
    text: string;
  }[];
  correctAnswer: 'A' | 'B' | 'C' | 'D' | 'E';
  explanation: {
    coreConcept: string;
    rationaleCorrect: string;
    rationaleIncorrect: Record<string, string>;
    clinicalTakeaway: string;
  };
}

export interface UserAnswerState {
  selectedOption: 'A' | 'B' | 'C' | 'D' | 'E' | null;
  isFlaggedDoubt: boolean;
  timeSpentSeconds: number;
}
