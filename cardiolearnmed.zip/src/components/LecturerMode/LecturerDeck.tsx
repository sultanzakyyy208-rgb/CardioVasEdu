import React, { useState } from 'react';
import { Presentation, Users, FileText, CheckSquare, Sparkles, ChevronRight, ChevronLeft, Printer, Award } from 'lucide-react';
import { CURRICULUM_MODULES } from '../../data/curriculumData';

interface PBLCase {
  id: string;
  caseTitle: string;
  patientScenario: string;
  tutorialTriggers: string[];
  learningObjectives: string[];
  tutorGuideNotes: string;
}

const PBL_CASES: PBLCase[] = [
  {
    id: 'case_1',
    caseTitle: 'Modul 1 & 6: Nyeri Dada Retrosternal Akut Menjalar ke Rahang (Sindrom Koroner Akut)',
    patientScenario: 'Tn. B, 56 tahun, datang ke IGD diantar keluarga dengan keluhan nyeri dada kiri mendadak sejak 2 jam lalu saat sedang mencangkul. Nyeri seperti tertindih beban berat, menjalar ke bahu kiri dan rahang bawah, disertai keringat dingin mengucur deras dan mual. Riwayat merokok 2 bungkus/hari selama 30 tahun dan hipertensi tak terkontrol. Pada EKG didapatkan ST elevasi 3 mm di sadapan V1-V4.',
    tutorialTriggers: [
      'Identifikasi anatomi vaskularisasi arteri koroner yang bertanggung jawab.',
      'Jelaskan patobiokimia ruptur plak aterotrombotik dan kaskade koagulasi.',
      'Analisis elektrofisiologi timbulnya elevasi segmen ST pada iskemia transmural.',
      'Tentukan langkah tatalaksana emergensi reperfusi (PCI primer vs Fibrinolisis).'
    ],
    learningObjectives: [
      'Mahasiswa mampu mengintegrasikan anatomi vaskularisasi jantung dengan gambaran EKG 12-sadapan.',
      'Mahasiswa memahami kriteria diagnosis STEMI, NSTEMI, dan UAP sesuai PERKI/ESC.',
      'Mahasiswa mampu merumuskan terapi farmakologis awal (MONA-B) dan stratifikasi reperfusi.'
    ],
    tutorGuideNotes: 'Arahkan mahasiswa untuk tidak melupakan pemeriksaan sadapan kanan V3R-V4R bila menemukan infark inferior, serta tekankan bahaya hipotensi pemberian nitrat pada infark RV.'
  },
  {
    id: 'case_2',
    caseTitle: 'Modul 2 & 5: Bayi Sianosis Saat Menangis dan Murmur Jantung Kongenital',
    patientScenario: 'By. A, usia 4 bulan, dibawa ibunya ke Poliklinik Anak karena ujung jari dan bibirnya membiru (sianosis) terutama saat menangis keras atau menyusu. Anak tampak cepat lelah dan berkeringat banyak di dahi saat menyusu. Pada pemeriksaan fisik didapatkan bising ejeksi sistolik kasar derajat 3/6 di sela iga II linea sternalis sinistra dan boot-shaped heart pada foto toraks.',
    tutorialTriggers: [
      'Mekanisme kelainan embryologis sekat konotrunkal jantung janin.',
      'Fisiologi pirau (shunt) kanan-ke-kiri dan kaitannya dengan sianosis.',
      'Mengapa manuver knee-chest position (atau squatting pada anak lebih besar) dapat meredakan spell hipoksia?'
    ],
    learningObjectives: [
      'Mahasiswa mampu menjelaskan 4 komponen anatomis Tetralogy of Fallot.',
      'Mahasiswa memahami prinsip peningkatan resistensi vaskular sistemik (SVR) saat knee-chest position untuk mengurangi pirau kanan-ke-kiri.',
      'Mahasiswa mampu merencanakan rujukan dan tatalaksana definitif bedah korektif.'
    ],
    tutorGuideNotes: 'Tekankan bahwa derajat stenosis infundibulum pulmonal adalah penentu utama keparahan sianosis dan frekuensi hypoxic spell (tet spell).'
  }
];

export const LecturerDeck: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'slides' | 'pbl' | 'syllabus'>('slides');
  const [currentSlideIndex, setCurrentSlideIndex] = useState<number>(0);
  const [selectedCase, setSelectedCase] = useState<PBLCase>(PBL_CASES[0]);

  // Slides data compiled from curriculum modules
  const slides = CURRICULUM_MODULES.flatMap((mod) =>
    mod.subtopics.map((sub) => ({
      moduleTitle: mod.title,
      subTitle: sub.title,
      summary: sub.summary,
      keyPoints: sub.keyPoints,
      pearls: sub.clinicalPearls,
      skdi: mod.skdiCompetence
    }))
  );

  const currentSlide = slides[currentSlideIndex] || slides[0];

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-2xl flex flex-col gap-6">
      {/* Top Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Presentation className="w-5 h-5 text-rose-500" />
            <h3 className="text-lg font-bold text-white tracking-tight">Portal Dosen Fakultas Kedokteran (Lecturer Mode)</h3>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Mode Presentasi Kuliah Besar, Modul Tutorial Problem-Based Learning (PBL), & Silabus Blok Kardiovaskular
          </p>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
          <button
            onClick={() => setActiveTab('slides')}
            className={`px-3 py-1.5 rounded-md font-semibold transition-colors flex items-center gap-1.5 ${
              activeTab === 'slides' ? 'bg-rose-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Presentation className="w-3.5 h-3.5" />
            <span>Slide Proyektor</span>
          </button>
          <button
            onClick={() => setActiveTab('pbl')}
            className={`px-3 py-1.5 rounded-md font-semibold transition-colors flex items-center gap-1.5 ${
              activeTab === 'pbl' ? 'bg-rose-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Kasus Tutorial PBL</span>
          </button>
          <button
            onClick={() => setActiveTab('syllabus')}
            className={`px-3 py-1.5 rounded-md font-semibold transition-colors flex items-center gap-1.5 ${
              activeTab === 'syllabus' ? 'bg-rose-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Silabus & SKDI</span>
          </button>
        </div>
      </div>

      {/* Tab 1: Projector Slide Mode */}
      {activeTab === 'slides' && (
        <div className="flex flex-col gap-4">
          {/* Main Slide Deck Box (16:9 Aspect Presentation Frame) */}
          <div className="relative aspect-[16/9] w-full rounded-2xl border-2 border-slate-700 bg-slate-950 p-6 md:p-10 flex flex-col justify-between shadow-2xl overflow-hidden">
            {/* Top Slide Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-xs font-mono text-rose-400 font-bold uppercase tracking-wider">
                  {currentSlide.moduleTitle}
                </span>
                <h3 className="text-xl md:text-2xl font-bold text-white mt-1">
                  {currentSlide.subTitle}
                </h3>
              </div>
              <span className="px-3 py-1 rounded bg-slate-900 border border-slate-700 text-xs font-bold text-slate-300">
                {currentSlide.skdi}
              </span>
            </div>

            {/* Slide Body Bullets */}
            <div className="my-auto space-y-3 py-4">
              <p className="text-sm md:text-base text-rose-200/90 font-medium italic mb-4">
                {currentSlide.summary}
              </p>
              <div className="space-y-2">
                {currentSlide.keyPoints.slice(0, 4).map((pt, idx) => (
                  <div key={idx} className="flex items-start gap-3 text-xs md:text-sm text-slate-200">
                    <span className="w-5 h-5 rounded-full bg-rose-950 border border-rose-600 text-rose-400 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <span className="leading-relaxed">{pt}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Slide Footer */}
            <div className="flex items-center justify-between border-t border-slate-800 pt-3 text-xs text-slate-500">
              <span>CardioLearnMed · Slide Kuliah Dosen Fakultas Kedokteran</span>
              <span className="font-mono">
                Slide {currentSlideIndex + 1} dari {slides.length}
              </span>
            </div>
          </div>

          {/* Slide Deck Nav Controls */}
          <div className="flex items-center justify-between">
            <button
              onClick={() => setCurrentSlideIndex((prev) => Math.max(0, prev - 1))}
              disabled={currentSlideIndex === 0}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-slate-950 border border-slate-800 text-xs font-bold text-slate-300 hover:text-white disabled:opacity-40"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Slide Sebelumnya</span>
            </button>

            <span className="text-xs text-slate-400 font-mono">
              Gunakan tombol panah untuk navigasi materi perkuliahan
            </span>

            <button
              onClick={() => setCurrentSlideIndex((prev) => Math.min(slides.length - 1, prev + 1))}
              disabled={currentSlideIndex >= slides.length - 1}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-xs font-bold text-white shadow"
            >
              <span>Slide Berikutnya</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Tab 2: PBL Tutorial Cases */}
      {activeTab === 'pbl' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
          {/* Left Cases Selector (4 cols) */}
          <div className="lg:col-span-4 bg-slate-950 border border-slate-800 rounded-xl p-4">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-3">
              Pilihan Skenario PBL
            </span>
            <div className="space-y-2">
              {PBL_CASES.map((cs) => (
                <button
                  key={cs.id}
                  onClick={() => setSelectedCase(cs)}
                  className={`w-full text-left p-3 rounded-lg border transition-all ${
                    selectedCase.id === cs.id
                      ? 'bg-slate-800 border-rose-500 text-white'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <span className="text-xs font-bold leading-snug block">{cs.caseTitle}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Right Case Guide Details (8 cols) */}
          <div className="lg:col-span-8 bg-slate-950 border border-slate-800 rounded-xl p-6 shadow-xl flex flex-col gap-5">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-rose-400">
                Skenario Pemicu Mahasiswa (Trigger)
              </span>
              <h4 className="text-lg font-bold text-white mt-1">{selectedCase.caseTitle}</h4>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed bg-slate-900 p-4 rounded-xl border border-slate-800 mt-3">
                {selectedCase.patientScenario}
              </p>
            </div>

            {/* Tutorial Triggers */}
            <div>
              <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                Pertanyaan Diskusi Pemicu (Tutorial Triggers):
              </h5>
              <div className="space-y-2">
                {selectedCase.tutorialTriggers.map((trig, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-xs text-slate-200">
                    <span className="text-rose-400 font-bold">•</span>
                    <span>{trig}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Learning Objectives */}
            <div className="bg-emerald-950/20 border border-emerald-500/30 rounded-xl p-4">
              <h5 className="text-xs font-bold text-emerald-400 uppercase tracking-wider mb-2">
                Sasaran Pembelajaran / Learning Objectives (LO):
              </h5>
              <div className="space-y-1.5">
                {selectedCase.learningObjectives.map((lo, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-xs text-emerald-200">
                    <CheckSquare className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{lo}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Tutor Notes */}
            <div className="bg-amber-950/20 border border-amber-500/30 rounded-xl p-4">
              <span className="text-xs font-bold text-amber-300 block mb-1">
                Catatan Panduan Tutor / Dosen Fasilitator:
              </span>
              <p className="text-xs text-amber-100/90 leading-relaxed">
                {selectedCase.tutorGuideNotes}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Syllabus & SKDI */}
      {activeTab === 'syllabus' && (
        <div className="bg-slate-950 border border-slate-800 rounded-xl p-5 shadow-xl">
          <h4 className="text-base font-bold text-white mb-4">
            Matriks Kurikulum Blok Kardiovaskular FK Berdasarkan SKDI
          </h4>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-900 border-b border-slate-800 text-slate-400">
                <tr>
                  <th className="p-3">No</th>
                  <th className="p-3">Nama Modul Pembelajaran</th>
                  <th className="p-3">Tingkat SKDI</th>
                  <th className="p-3">Beban Jam</th>
                  <th className="p-3">Cakupan Materi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {CURRICULUM_MODULES.map((m, idx) => (
                  <tr key={m.id} className="hover:bg-slate-900/50 transition-colors">
                    <td className="p-3 font-mono text-slate-500">{idx + 1}</td>
                    <td className="p-3 font-bold text-white">{m.title}</td>
                    <td className="p-3 font-semibold text-rose-400">{m.skdiCompetence}</td>
                    <td className="p-3 text-slate-300">{m.duration}</td>
                    <td className="p-3 text-slate-400 max-w-xs">{m.overview}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
