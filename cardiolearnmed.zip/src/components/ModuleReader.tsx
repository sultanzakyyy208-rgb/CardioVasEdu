import React, { useState } from 'react';
import { CURRICULUM_MODULES } from '../data/curriculumData';
import { BEGINNER_MODULE_CONCEPTS } from '../data/beginnerContent';
import { CurriculumModule, ModuleId } from '../types/cardio';
import { 
  BookOpen, 
  Sparkles, 
  CheckCircle2, 
  ChevronRight, 
  Award, 
  Compass, 
  ArrowRight,
  GraduationCap,
  Lightbulb,
  HelpCircle,
  AlertCircle
} from 'lucide-react';

interface ModuleReaderProps {
  initialModuleId?: ModuleId;
  onOpenSimulator?: (simType: '3d' | 'wiggers' | 'ecg' | 'histology' | 'pvloop') => void;
  onOpenCBT?: (moduleId: ModuleId) => void;
}

export const ModuleReader: React.FC<ModuleReaderProps> = ({
  initialModuleId = 'anatomi',
  onOpenSimulator,
  onOpenCBT
}) => {
  const [learningTier, setLearningTier] = useState<'beginner' | 'clinical'>('beginner');
  const [selectedModuleId, setSelectedModuleId] = useState<ModuleId>(initialModuleId);
  const currentModule = CURRICULUM_MODULES.find((m) => m.id === selectedModuleId) || CURRICULUM_MODULES[0];
  const [activeSubtopicId, setActiveSubtopicId] = useState<string>(currentModule.subtopics[0].id);

  // Beginner Quiz state
  const [quizAnswer, setQuizAnswer] = useState<number | null>(null);
  const [showQuizResult, setShowQuizResult] = useState<boolean>(false);

  const activeSubtopic = currentModule.subtopics.find((s) => s.id === activeSubtopicId) || currentModule.subtopics[0];
  const beginnerConcept = BEGINNER_MODULE_CONCEPTS[selectedModuleId];

  const handleSelectModule = (modId: ModuleId) => {
    setSelectedModuleId(modId);
    const mod = CURRICULUM_MODULES.find(m => m.id === modId);
    if (mod) setActiveSubtopicId(mod.subtopics[0].id);
    setQuizAnswer(null);
    setShowQuizResult(false);
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Top Level Tier Selector Switcher */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
        <div>
          <span className="text-xs font-semibold text-slate-400 block">Pilih Tingkat Pemahaman:</span>
          <span className="text-sm font-bold text-white">
            {learningTier === 'beginner'
              ? 'Mode Pemula & Mahasiswa Baru (Konsep Dasar, Analogi & Kuis Pemahaman)'
              : 'Mode Mahasiswa Kedokteran Lanjut & Dokter (Materi Akademik, Histologi & Klinis)'}
          </span>
        </div>

        {/* Tier Toggle Switcher */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-950 rounded-xl border border-slate-800">
          <button
            onClick={() => setLearningTier('beginner')}
            className={`px-3.5 py-2 rounded-lg text-xs font-semibold transition-all flex items-center gap-2 ${
              learningTier === 'beginner'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Lightbulb className="w-4 h-4 text-emerald-300" />
            <span>Mode Pemula (Dasar & Analogi)</span>
          </button>

          <button
            onClick={() => setLearningTier('clinical')}
            className={`px-3.5 py-2 rounded-lg text-xs font-semibold transition-all flex items-center gap-2 ${
              learningTier === 'clinical'
                ? 'bg-rose-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <GraduationCap className="w-4 h-4 text-rose-300" />
            <span>Mode Kedokteran (Klinis & SKDI)</span>
          </button>
        </div>
      </div>

      {/* 7 Modules Horizontal Selector Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin">
        {CURRICULUM_MODULES.map((mod) => (
          <button
            key={mod.id}
            onClick={() => handleSelectModule(mod.id)}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-2 border ${
              selectedModuleId === mod.id
                ? learningTier === 'beginner'
                  ? 'bg-emerald-600 text-white border-emerald-500 shadow-md'
                  : 'bg-rose-600 text-white border-rose-500 shadow-md'
                : 'bg-slate-900 text-slate-300 border-slate-800 hover:text-white hover:border-slate-700'
            }`}
          >
            <span>{mod.title.split('.')[1]}</span>
          </button>
        ))}
      </div>

      {/* ========================================================= */}
      {/* TIER 1: BEGINNER & FOUNDATION MODE (KONSEP DASAR & ANALOGI) */}
      {/* ========================================================= */}
      {learningTier === 'beginner' && beginnerConcept && (
        <div className="space-y-6 animate-in fade-in duration-200">
          {/* Module Banner for Beginners */}
          <div className="bg-slate-900 border border-emerald-500/30 rounded-2xl p-6 sm:p-8 shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="space-y-3 max-w-2xl">
              <div className="flex items-center gap-2 text-xs font-bold text-emerald-400 uppercase tracking-wider">
                <span>Pondasi Belajar Mudah</span>
                <span aria-hidden="true">·</span>
                <span>{currentModule.title.split('.')[1]}</span>
              </div>

              <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
                {beginnerConcept.title}
              </h2>

              <p className="text-sm text-slate-300 leading-relaxed bg-slate-950 p-4 rounded-xl border border-slate-800">
                <strong className="text-emerald-400 font-semibold">Inti Konsep: </strong>
                {beginnerConcept.coreIdea}
              </p>
            </div>

            <div className="w-full md:w-64 aspect-[4/3] rounded-xl overflow-hidden border border-slate-800 shrink-0 shadow-lg relative bg-slate-950">
              <img
                src={currentModule.image}
                alt={currentModule.title}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />
            </div>
          </div>

          {/* Real-World Analogy Spotlight Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-7 shadow-xl">
            <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider mb-2">
              <Lightbulb className="w-4 h-4" />
              <span>Analogi Dunia Nyata (Biar Langsung Paham)</span>
            </div>

            <h3 className="text-lg sm:text-xl font-bold text-white mb-3">
              {beginnerConcept.realWorldAnalogy.analogyTitle}
            </h3>

            <p className="text-sm text-slate-200 leading-relaxed italic bg-slate-950 p-4 rounded-xl border border-slate-800/80 mb-4">
              "{beginnerConcept.realWorldAnalogy.analogyStory}"
            </p>

            <div className="bg-amber-950/20 border border-amber-500/30 p-4 rounded-xl">
              <span className="text-xs font-bold text-amber-300 block mb-1">
                Korelasi dengan Tubuh Manusia:
              </span>
              <p className="text-xs sm:text-sm text-amber-100/90 leading-relaxed">
                {beginnerConcept.realWorldAnalogy.explanation}
              </p>
            </div>
          </div>

          {/* Step-by-Step Practical Conceptual Walkthrough */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
            <h3 className="text-base font-bold text-white mb-4">
              Langkah Penting yang Perlu Diingat:
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {beginnerConcept.stepByStepGuide.map((step) => (
                <div
                  key={step.stepNumber}
                  className="bg-slate-950 border border-slate-800 rounded-xl p-4 flex flex-col justify-between"
                >
                  <div>
                    <span className="w-7 h-7 rounded-lg bg-emerald-950 border border-emerald-500/50 text-emerald-400 text-xs font-bold flex items-center justify-center font-mono mb-2">
                      {step.stepNumber}
                    </span>
                    <h4 className="text-sm font-bold text-white mb-1.5">{step.title}</h4>
                    <p className="text-xs text-slate-300 leading-relaxed">{step.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Myth vs Fact / Common Misconceptions */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
            <div className="flex items-center gap-2 text-rose-400 text-xs font-bold uppercase tracking-wider mb-4">
              <AlertCircle className="w-4 h-4" />
              <span>Mitos vs Fakta Medis yang Sering Keliru</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {beginnerConcept.commonMisconceptions.map((item, idx) => (
                <div key={idx} className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-2">
                  <div className="text-xs text-rose-400 font-semibold">
                    <span className="font-bold">❌ Mitos Keliru: </span>
                    <span>{item.myth}</span>
                  </div>
                  <div className="text-xs text-emerald-300">
                    <strong className="font-bold">✓ Fakta Medis Sebenarnya: </strong>
                    <span className="text-slate-300">{item.fact}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Concept Self-Check Quiz */}
          <div className="bg-slate-900 border border-emerald-500/40 rounded-2xl p-6 shadow-xl">
            <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-wider mb-2">
              <HelpCircle className="w-4 h-4" />
              <span>Cek Pemahaman Cepat (Self-Check Quiz)</span>
            </div>

            <h4 className="text-sm sm:text-base font-bold text-white mb-4">
              {beginnerConcept.quickQuiz.question}
            </h4>

            <div className="space-y-2 mb-4">
              {beginnerConcept.quickQuiz.options.map((opt, oIdx) => {
                const isSelected = quizAnswer === oIdx;
                const isCorrect = oIdx === beginnerConcept.quickQuiz.correctIndex;
                let optStyle = 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700';

                if (showQuizResult) {
                  if (isCorrect) optStyle = 'bg-emerald-950/60 border-emerald-500 text-emerald-200';
                  else if (isSelected && !isCorrect) optStyle = 'bg-rose-950/60 border-rose-500 text-rose-200';
                } else if (isSelected) {
                  optStyle = 'bg-slate-800 border-emerald-500 text-white';
                }

                return (
                  <button
                    key={oIdx}
                    onClick={() => {
                      setQuizAnswer(oIdx);
                      setShowQuizResult(true);
                    }}
                    className={`w-full text-left p-3 rounded-xl border text-xs sm:text-sm transition-all flex items-center justify-between ${optStyle}`}
                  >
                    <span>{opt}</span>
                    {showQuizResult && isCorrect && <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />}
                  </button>
                );
              })}
            </div>

            {showQuizResult && (
              <div className="bg-slate-950 border border-emerald-500/40 p-4 rounded-xl text-xs leading-relaxed animate-in fade-in duration-200">
                <span className="font-bold text-emerald-400 block mb-1">
                  Penjelasan Kunci:
                </span>
                <p className="text-slate-200">{beginnerConcept.quickQuiz.explanation}</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* TIER 2: ADVANCED MEDICAL & CLINICAL CURRICULUM (SKDI MODE) */}
      {/* ========================================================= */}
      {learningTier === 'clinical' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          {/* Module Hero Banner */}
          <div className="relative rounded-2xl overflow-hidden border border-slate-800 bg-slate-950 p-6 md:p-8 flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl">
            <div className="max-w-2xl z-10">
              <div className="flex items-center gap-2 text-rose-400 text-xs font-bold uppercase tracking-wider mb-2">
                <span>{currentModule.skdiCompetence}</span>
                <span aria-hidden="true">·</span>
                <span>{currentModule.duration}</span>
              </div>

              <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight leading-tight">
                {currentModule.title}
              </h2>

              <p className="text-sm text-slate-300 mt-2 leading-relaxed">
                {currentModule.overview}
              </p>

              {/* Quick Action Buttons */}
              <div className="flex flex-wrap items-center gap-3 mt-5">
                {onOpenSimulator && (
                  <button
                    onClick={() => {
                      if (currentModule.id === 'anatomi') onOpenSimulator('3d');
                      else if (currentModule.id === 'fisiologi') onOpenSimulator('wiggers');
                      else if (currentModule.id === 'histologi') onOpenSimulator('histology');
                      else if (currentModule.id === 'penyakit') onOpenSimulator('ecg');
                      else onOpenSimulator('pvloop');
                    }}
                    className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-lg transition-colors shadow flex items-center gap-1.5"
                  >
                    <Compass className="w-4 h-4" />
                    <span>Buka Simulator Praktikum Terkait</span>
                  </button>
                )}

                {onOpenCBT && (
                  <button
                    onClick={() => onOpenCBT(currentModule.id)}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-lg transition-colors border border-slate-700 flex items-center gap-1.5"
                  >
                    <Award className="w-4 h-4 text-amber-400" />
                    <span>Latihan CBT Modul Ini</span>
                  </button>
                )}
              </div>
            </div>

            <div className="w-full md:w-64 aspect-[4/3] rounded-xl overflow-hidden border border-slate-800 shrink-0 shadow-lg relative bg-slate-900">
              <img
                src={currentModule.image}
                alt={currentModule.title}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />
            </div>
          </div>

          {/* Subtopic Sidebar Navigation (4 cols) + Detailed Medical Reader (8 cols) */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 px-1">
                Sub-Topik Kuliah & Praktikum
              </h3>

              <div className="space-y-2">
                {currentModule.subtopics.map((sub, idx) => (
                  <button
                    key={sub.id}
                    onClick={() => setActiveSubtopicId(sub.id)}
                    className={`w-full text-left p-3 rounded-lg border transition-all flex flex-col gap-1 ${
                      activeSubtopic.id === sub.id
                        ? 'bg-slate-800 border-rose-500 text-white shadow-sm'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono text-rose-400 font-bold">
                        Bab {idx + 1}
                      </span>
                      {activeSubtopic.id === sub.id && (
                        <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                      )}
                    </div>
                    <span className="text-xs font-bold leading-snug">{sub.title}</span>
                    <span className="text-[11px] text-slate-400 line-clamp-1">{sub.subtitle}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl flex flex-col gap-6">
              <div className="border-b border-slate-800 pb-4">
                <h3 className="text-xl font-bold text-white tracking-tight">{activeSubtopic.title}</h3>
                <p className="text-xs text-rose-300 font-serif italic mt-0.5">{activeSubtopic.subtitle}</p>
                <p className="text-xs text-slate-300 leading-relaxed mt-2 bg-slate-950 p-3 rounded-lg border border-slate-800">
                  {activeSubtopic.summary}
                </p>
              </div>

              <div>
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">
                  Poin Pembelajaran Inti (Core Competencies):
                </h4>
                <div className="space-y-2">
                  {activeSubtopic.keyPoints.map((point, idx) => (
                    <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-200">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span className="leading-relaxed">{point}</span>
                    </div>
                  ))}
                </div>
              </div>

              {activeSubtopic.clinicalPearls.length > 0 && (
                <div className="bg-amber-950/20 border border-amber-500/40 rounded-xl p-4">
                  <div className="flex items-center gap-2 text-amber-400 text-xs font-bold mb-2">
                    <Sparkles className="w-4 h-4" />
                    <span>Mutiara Klinis Dokter & Tips Ujian UKMPPD (Clinical Pearls)</span>
                  </div>
                  <ul className="space-y-2 text-xs text-amber-100/90 leading-relaxed">
                    {activeSubtopic.clinicalPearls.map((pearl, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="text-amber-400 font-bold">•</span>
                        <span>{pearl}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="space-y-5 border-t border-slate-800 pt-5">
                {activeSubtopic.medicalContent.map((content, idx) => (
                  <div key={idx} className="space-y-2">
                    <h5 className="text-sm font-bold text-white">{content.heading}</h5>
                    {content.paragraphs.map((p, pIdx) => (
                      <p key={pIdx} className="text-xs sm:text-sm text-slate-300 leading-relaxed font-sans">
                        {p}
                      </p>
                    ))}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
