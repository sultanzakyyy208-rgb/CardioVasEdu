import React, { useState, useEffect, useMemo } from 'react';
import { getCBTQuestion, CBT_STATS } from '../../data/cbtEngine';
import { CBTQuestion, UserAnswerState } from '../../types/cardio';
import { useAuth } from '../../context/AuthContext';
import confetti from 'canvas-confetti';
import { 
  Clock, 
  HelpCircle, 
  CheckCircle2, 
  XCircle, 
  ChevronLeft, 
  ChevronRight, 
  Flag, 
  RotateCcw, 
  Award, 
  Search, 
  SlidersHorizontal,
  Download,
  BookOpen,
  FileCheck,
  CloudCheck
} from 'lucide-react';

export const CBTExamView: React.FC = () => {
  const { currentUser, saveCbtAttempt, cbtHistory } = useAuth();

  // Navigation & Question State
  const [currentQuestionId, setCurrentQuestionId] = useState<number>(1);
  const [jumpInput, setJumpInput] = useState<string>('1');
  const [selectedModuleFilter, setSelectedModuleFilter] = useState<string>('all');
  const [examMode, setExamMode] = useState<'study' | 'official'>('study'); // Study Mode (instant feedback) vs Official Exam Mode

  // Exam Session Settings
  const [examSize, setExamSize] = useState<number>(20); // 20, 50, 100
  const [isExamStarted, setIsExamStarted] = useState<boolean>(false);
  const [isExamSubmitted, setIsExamSubmitted] = useState<boolean>(false);
  const [examQuestionsList, setExamQuestionsList] = useState<number[]>([]);
  const [timeRemainingSeconds, setTimeRemainingSeconds] = useState<number>(20 * 60);

  // User Answers Record: questionId -> answer state
  const [userAnswers, setUserAnswers] = useState<Record<number, UserAnswerState>>({});

  // Initialize or generate exam set
  const startExam = (size: number) => {
    setExamSize(size);
    // Pick deterministic or sequential questions depending on current selection
    const startId = currentQuestionId;
    const questions: number[] = [];
    for (let i = 0; i < size; i++) {
      let qId = startId + i;
      if (qId > 12000) qId = (qId % 12000) + 1;
      questions.push(qId);
    }
    setExamQuestionsList(questions);
    setCurrentQuestionId(questions[0]);
    setTimeRemainingSeconds(size * 60); // 1 minute per question (standard UKMPPD rate)
    setIsExamStarted(true);
    setIsExamSubmitted(false);
    setUserAnswers({});
  };

  // Timer countdown
  useEffect(() => {
    if (!isExamStarted || isExamSubmitted || examMode === 'study') return;
    const interval = setInterval(() => {
      setTimeRemainingSeconds((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          submitExam();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [isExamStarted, isExamSubmitted, examMode]);

  // Current Question Object
  const currentQuestion = useMemo(() => {
    return getCBTQuestion(currentQuestionId);
  }, [currentQuestionId]);

  // Current Answer State
  const currentAnswerState = userAnswers[currentQuestionId] || {
    selectedOption: null,
    isFlaggedDoubt: false,
    timeSpentSeconds: 0
  };

  const handleSelectOption = (option: 'A' | 'B' | 'C' | 'D' | 'E') => {
    if (isExamSubmitted && examMode === 'official') return;
    setUserAnswers((prev) => ({
      ...prev,
      [currentQuestionId]: {
        ...(prev[currentQuestionId] || { timeSpentSeconds: 0 }),
        selectedOption: option,
        isFlaggedDoubt: prev[currentQuestionId]?.isFlaggedDoubt || false
      }
    }));
  };

  const handleToggleDoubt = () => {
    setUserAnswers((prev) => ({
      ...prev,
      [currentQuestionId]: {
        selectedOption: prev[currentQuestionId]?.selectedOption || null,
        isFlaggedDoubt: !(prev[currentQuestionId]?.isFlaggedDoubt || false),
        timeSpentSeconds: prev[currentQuestionId]?.timeSpentSeconds || 0
      }
    }));
  };

  const submitExam = () => {
    setIsExamSubmitted(true);
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 }
    });

    // Auto-save to Firebase if user is authenticated
    if (currentUser) {
      const listToEvaluate = examQuestionsList.length > 0 ? examQuestionsList : [currentQuestionId];
      let correct = 0;
      let answered = 0;
      listToEvaluate.forEach((qId) => {
        const q = getCBTQuestion(qId);
        const ans = userAnswers[qId];
        if (ans?.selectedOption) {
          answered++;
          if (ans.selectedOption === q.correctAnswer) {
            correct++;
          }
        }
      });
      const percent = Math.round((correct / (listToEvaluate.length || 1)) * 100);
      saveCbtAttempt({
        totalQuestions: listToEvaluate.length,
        answered,
        correct,
        wrong: answered - correct,
        scorePercent: percent,
        isPassed: percent >= 70,
        examType: `Tryout CBT ${listToEvaluate.length} Soal`
      }).catch(console.error);
    }
  };

  // Exam Score Calculation
  const scoreResults = useMemo(() => {
    if (!isExamStarted && examMode === 'official') return null;
    const total = examQuestionsList.length > 0 ? examQuestionsList.length : 1;
    let correct = 0;
    let answered = 0;
    let doubt = 0;

    const listToEvaluate = examQuestionsList.length > 0 ? examQuestionsList : [currentQuestionId];

    listToEvaluate.forEach((qId) => {
      const q = getCBTQuestion(qId);
      const ans = userAnswers[qId];
      if (ans?.selectedOption) {
        answered++;
        if (ans.selectedOption === q.correctAnswer) {
          correct++;
        }
      }
      if (ans?.isFlaggedDoubt) {
        doubt++;
      }
    });

    const percent = Math.round((correct / (listToEvaluate.length || 1)) * 100);
    return {
      total: listToEvaluate.length,
      answered,
      correct,
      wrong: answered - correct,
      unanswered: listToEvaluate.length - answered,
      doubt,
      percent,
      isPassed: percent >= 70 // 70 is standard passing grade for SKDI UKMPPD
    };
  }, [userAnswers, examQuestionsList, isExamSubmitted, currentQuestionId, isExamStarted, examMode]);

  // Jump to Question
  const handleJumpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseInt(jumpInput, 10);
    if (!isNaN(val) && val >= 1 && val <= 12000) {
      setCurrentQuestionId(val);
    }
  };

  // Time formatter (HH:MM:SS)
  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    if (h > 0) {
      return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    }
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-2xl flex flex-col gap-6">
      {/* Top Bar: Bank Metadata & Mode Toggle */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-rose-500" />
            <h3 className="text-lg font-bold text-white tracking-tight">
              Bank Soal CBT UKMPPD Kardiovaskular (12.000 Soal)
            </h3>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Format Skenario Klinis Standar Nasional Ujian Kompetensi Mahasiswa Program Profesi Dokter (SKDI 1 - 4A)
          </p>
        </div>

        {/* Mode Selector & Quick Jump */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Mode Switcher */}
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
            <button
              onClick={() => {
                setExamMode('study');
                setIsExamStarted(false);
              }}
              className={`px-3 py-1.5 rounded-md font-semibold transition-colors flex items-center gap-1.5 ${
                examMode === 'study'
                  ? 'bg-rose-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Mode Pembahasan Bebas</span>
            </button>
            <button
              onClick={() => {
                setExamMode('official');
                if (!isExamStarted) startExam(20);
              }}
              className={`px-3 py-1.5 rounded-md font-semibold transition-colors flex items-center gap-1.5 ${
                examMode === 'official'
                  ? 'bg-rose-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              <span>Simulasi Ujian CBT</span>
            </button>
          </div>

          {/* Jump to specific Question Number (1 - 12000) */}
          <form onSubmit={handleJumpSubmit} className="flex items-center gap-1.5 bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800">
            <span className="text-[11px] text-slate-400">Ke No:</span>
            <input
              type="number"
              min="1"
              max="12000"
              value={jumpInput}
              onChange={(e) => setJumpInput(e.target.value)}
              className="w-16 bg-slate-900 border border-slate-700 text-xs text-white px-2 py-0.5 rounded text-center font-mono"
            />
            <button
              type="submit"
              className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded font-medium"
            >
              Buka
            </button>
          </form>
        </div>
      </div>

      {/* Module Range Filter Chips */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
        <span className="text-slate-400 whitespace-nowrap font-medium">Distribusi Modul:</span>
        {CBT_STATS.modules.map((mod) => (
          <button
            key={mod.id}
            onClick={() => {
              // Jump to the first question of that module
              if (mod.id === 'anatomi') setCurrentQuestionId(1);
              if (mod.id === 'fisiologi') setCurrentQuestionId(1701);
              if (mod.id === 'histologi') setCurrentQuestionId(3401);
              if (mod.id === 'biokimia') setCurrentQuestionId(5101);
              if (mod.id === 'embriologi') setCurrentQuestionId(6801);
              if (mod.id === 'penyakit') setCurrentQuestionId(8501);
              if (mod.id === 'biologi_detail') setCurrentQuestionId(10501);
            }}
            className="px-2.5 py-1 rounded-md bg-slate-950 text-slate-300 border border-slate-800 hover:border-rose-500/40 hover:text-white transition-colors whitespace-nowrap"
          >
            {mod.name.split('.')[1]} <span className="font-mono text-[10px] text-slate-500">({mod.range})</span>
          </button>
        ))}
      </div>

      {/* Official Exam Mode Top Header (Timer, Counter, Submit) */}
      {examMode === 'official' && (
        <div className="bg-slate-950 border border-slate-800 rounded-xl p-3.5 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            {/* Timer Clock */}
            <div className="flex items-center gap-2 bg-slate-900 border border-slate-700/80 px-3 py-1.5 rounded-lg">
              <Clock className="w-4 h-4 text-amber-400 animate-pulse" />
              <span className="text-xs text-slate-400">Sisa Waktu:</span>
              <span className="text-sm font-bold font-mono text-white tabular-nums">
                {formatTime(timeRemainingSeconds)}
              </span>
            </div>

            <div className="text-xs text-slate-400">
              Paket Ujian: <strong className="text-white">{examSize} Soal</strong> · Terjawab:{' '}
              <strong className="text-emerald-400">{scoreResults?.answered || 0}</strong>/{examSize}
            </div>
          </div>

          <div className="flex items-center gap-2">
            {!isExamSubmitted ? (
              <button
                onClick={submitExam}
                className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg transition-colors shadow"
              >
                Selesai Ujian & Lihat Skor
              </button>
            ) : (
              <button
                onClick={() => startExam(examSize)}
                className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold rounded-lg transition-colors"
              >
                Mulai Ujian Baru
              </button>
            )}
          </div>
        </div>
      )}

      {/* Main Examination Viewport: Question Card (8 cols) + Number Grid Navigator (4 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* Left: The Clinical Vignette & Answer Options (8 cols) */}
        <div className="lg:col-span-8 flex flex-col gap-4">
          {/* Question Meta Bar */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-7 h-7 rounded-lg bg-rose-950 border border-rose-600 text-rose-300 font-mono font-bold text-xs flex items-center justify-center">
                #{currentQuestion.id.toString().padStart(5, '0')}
              </span>
              <div>
                <span className="text-[11px] font-semibold text-rose-400 block">
                  {currentQuestion.moduleName}
                </span>
                <span className="text-[10px] text-slate-400">
                  Tingkat Kemampuan: <strong className="text-white">{currentQuestion.skdiLevel}</strong> · Tingkat Kesulitan:{' '}
                  <strong className="text-white">{currentQuestion.difficulty}</strong>
                </span>
              </div>
            </div>

            {/* Ragu-ragu (Doubt) Button */}
            <button
              onClick={handleToggleDoubt}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors border ${
                currentAnswerState.isFlaggedDoubt
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
              }`}
            >
              <Flag className={`w-3.5 h-3.5 ${currentAnswerState.isFlaggedDoubt ? 'fill-amber-400 text-amber-400' : ''}`} />
              <span>{currentAnswerState.isFlaggedDoubt ? 'Ditandai Ragu' : 'Tandai Ragu'}</span>
            </button>
          </div>

          {/* Clinical Vignette Text Box */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-5 shadow-inner">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
              Skenario Klinis Pasien (Vignette):
            </h4>
            <p className="text-sm text-slate-200 leading-relaxed font-sans font-normal selection:bg-rose-600">
              {currentQuestion.vignetteText}
            </p>

            <div className="mt-4 pt-3 border-t border-slate-800">
              <h5 className="text-sm font-bold text-white leading-snug">
                {currentQuestion.questionPrompt}
              </h5>
            </div>
          </div>

          {/* Multiple Choice Options (A, B, C, D, E) */}
          <div className="space-y-2.5">
            {currentQuestion.options.map((option) => {
              const isSelected = currentAnswerState.selectedOption === option.label;
              const isCorrect = option.label === currentQuestion.correctAnswer;
              const showResult = (examMode === 'study' && currentAnswerState.selectedOption !== null) || isExamSubmitted;

              let buttonStyle = 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-900/60';
              if (isSelected && !showResult) {
                buttonStyle = 'bg-rose-950/40 border-rose-500 text-white shadow-sm ring-1 ring-rose-500/40';
              } else if (showResult) {
                if (isCorrect) {
                  buttonStyle = 'bg-emerald-950/50 border-emerald-500 text-emerald-200 ring-1 ring-emerald-500/50';
                } else if (isSelected && !isCorrect) {
                  buttonStyle = 'bg-rose-950/50 border-rose-500 text-rose-200 ring-1 ring-rose-500/50';
                }
              }

              return (
                <button
                  key={option.label}
                  onClick={() => handleSelectOption(option.label)}
                  className={`w-full text-left p-3.5 rounded-xl border transition-all flex items-start gap-3 ${buttonStyle}`}
                >
                  <span
                    className={`w-6 h-6 rounded-md flex items-center justify-center font-bold text-xs shrink-0 mt-0.5 transition-colors ${
                      isSelected
                        ? 'bg-rose-600 text-white'
                        : showResult && isCorrect
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-900 border border-slate-700 text-slate-400'
                    }`}
                  >
                    {option.label}
                  </span>
                  <span className="text-xs sm:text-sm leading-relaxed">{option.text}</span>
                  {showResult && isCorrect && (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 ml-auto shrink-0 mt-0.5" />
                  )}
                  {showResult && isSelected && !isCorrect && (
                    <XCircle className="w-5 h-5 text-rose-400 ml-auto shrink-0 mt-0.5" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Navigation Buttons: Sebelumnya, Selanjutnya */}
          <div className="flex items-center justify-between pt-2">
            <button
              onClick={() => setCurrentQuestionId((prev) => Math.max(1, prev - 1))}
              disabled={currentQuestionId <= 1}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-900 disabled:opacity-40 text-xs font-semibold transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Soal Sebelumnya</span>
            </button>

            <button
              onClick={() => setCurrentQuestionId((prev) => Math.min(12000, prev + 1))}
              disabled={currentQuestionId >= 12000}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold transition-colors shadow"
            >
              <span>Soal Berikutnya</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Comprehensive Medical Explanation (Pembahasan Medis) */}
          {(examMode === 'study' && currentAnswerState.selectedOption !== null) || isExamSubmitted ? (
            <div className="bg-slate-950 border border-emerald-500/40 rounded-xl p-5 shadow-2xl animate-in fade-in duration-200">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  <h4 className="text-sm font-bold text-white">
                    Kunci Jawaban Resmi:{' '}
                    <span className="text-emerald-400 font-mono text-base">
                      Pilihan {currentQuestion.correctAnswer}
                    </span>
                  </h4>
                </div>
                <span className="text-[11px] font-mono text-slate-400">
                  Ref ID: #SOAL-{currentQuestion.id}
                </span>
              </div>

              {/* Core Medical Concept */}
              <div className="space-y-3 text-xs leading-relaxed">
                <div>
                  <span className="font-bold text-slate-300 block mb-0.5">Konsep Inti Biomedik / Klinis:</span>
                  <p className="text-slate-300 bg-slate-900/80 p-2.5 rounded-lg border border-slate-800">
                    {currentQuestion.explanation.coreConcept}
                  </p>
                </div>

                <div>
                  <span className="font-bold text-emerald-400 block mb-0.5">Rasionalisasi Opsi Benar:</span>
                  <p className="text-emerald-100/90 bg-emerald-950/20 p-2.5 rounded-lg border border-emerald-500/30">
                    {currentQuestion.explanation.rationaleCorrect}
                  </p>
                </div>

                {/* Incorrect Options Analysis */}
                <div>
                  <span className="font-bold text-slate-400 block mb-1">Analisis Eliminasi Opsi Keliru:</span>
                  <div className="space-y-1.5 pl-2 border-l-2 border-slate-800">
                    {Object.entries(currentQuestion.explanation.rationaleIncorrect).map(([label, reason]) => (
                      <div key={label} className="text-slate-400">
                        <strong className="text-rose-400 font-mono">Opsi {label}: </strong>
                        <span>{reason}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Clinical Pearl Takeaway */}
                <div className="bg-amber-950/30 border border-amber-500/30 p-3 rounded-lg">
                  <span className="font-bold text-amber-300 block mb-1">Mutiara Klinis Dokter (Clinical Pearl):</span>
                  <p className="text-amber-100/90">
                    {currentQuestion.explanation.clinicalTakeaway}
                  </p>
                </div>
              </div>
            </div>
          ) : (
            examMode === 'study' && (
              <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-4 text-center text-xs text-slate-400">
                Pilih salah satu jawaban di atas untuk membuka kunci jawaban dan pembahasan medis lengkap.
              </div>
            )
          )}
        </div>

        {/* Right: Question Navigation Matrix & Score Summary (4 cols) */}
        <div className="lg:col-span-4 flex flex-col gap-4">
          {/* Exam Score Summary Card (When submitted or active) */}
          {scoreResults && (
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  Hasil Evaluasi Capaian
                </span>
                <span className={`text-xs font-bold px-2 py-0.5 rounded ${scoreResults.isPassed ? 'bg-emerald-950 text-emerald-400 border border-emerald-600/40' : 'bg-rose-950 text-rose-400 border border-rose-600/40'}`}>
                  {scoreResults.isPassed ? 'KOMPETEN (LULUS)' : 'BELUM KOMPETEN'}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-center text-xs">
                <div className="bg-slate-900 p-2 rounded border border-slate-800">
                  <span className="text-slate-400 text-[10px] block">Skor Akhir</span>
                  <span className="text-lg font-bold font-mono text-white tabular-nums">
                    {scoreResults.percent}%
                  </span>
                </div>
                <div className="bg-slate-900 p-2 rounded border border-slate-800">
                  <span className="text-slate-400 text-[10px] block">Benar / Salah</span>
                  <span className="text-sm font-bold font-mono text-emerald-400 tabular-nums">
                    {scoreResults.correct} <span className="text-slate-500">/</span> <span className="text-rose-400">{scoreResults.wrong}</span>
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Question Grid Matrix */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
              <span className="text-xs font-bold text-white uppercase tracking-wider">
                Lembar Jawaban Soal
              </span>
              <span className="text-[10px] text-slate-400 font-mono">
                {userAnswers[currentQuestionId]?.selectedOption ? '1 Terjawab' : 'Belum Terjawab'}
              </span>
            </div>

            {/* Quick 20-50 Number Matrix */}
            <div className="grid grid-cols-5 gap-1.5 max-h-72 overflow-y-auto pr-1 scrollbar-thin">
              {(examQuestionsList.length > 0 ? examQuestionsList : Array.from({ length: 30 }, (_, i) => currentQuestionId - (currentQuestionId % 30) + i + 1)).map((qNum) => {
                const ans = userAnswers[qNum];
                const isActive = qNum === currentQuestionId;
                const isAnswered = !!ans?.selectedOption;
                const isDoubt = !!ans?.isFlaggedDoubt;

                let numStyle = 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white';
                if (isActive) {
                  numStyle = 'bg-rose-600 border-rose-500 text-white font-bold ring-2 ring-rose-500/40';
                } else if (isDoubt) {
                  numStyle = 'bg-amber-600/30 border-amber-500 text-amber-300 font-bold';
                } else if (isAnswered) {
                  numStyle = 'bg-emerald-950/60 border-emerald-500/60 text-emerald-300 font-bold';
                }

                return (
                  <button
                    key={qNum}
                    onClick={() => setCurrentQuestionId(qNum)}
                    className={`py-2 rounded text-xs font-mono border transition-colors flex flex-col items-center justify-center ${numStyle}`}
                  >
                    <span>{qNum}</span>
                    {ans?.selectedOption && (
                      <span className="text-[9px] leading-none opacity-80 mt-0.5">{ans.selectedOption}</span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Legend */}
            <div className="grid grid-cols-3 gap-1 pt-3 mt-3 border-t border-slate-800 text-[10px] text-slate-400">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded bg-emerald-600" />
                <span>Terjawab</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded bg-amber-500" />
                <span>Ragu-ragu</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded bg-slate-800" />
                <span>Kosong</span>
              </div>
            </div>
          </div>

          {/* Exam Set Starter Options (Official Mode) */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-4">
            <span className="text-xs font-bold text-white block mb-2">Paket Tryout Baru:</span>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => startExam(20)}
                className="py-1.5 px-2 rounded-lg bg-slate-900 border border-slate-800 text-xs font-medium text-slate-300 hover:text-white hover:border-slate-700 transition-colors"
              >
                20 Soal
              </button>
              <button
                onClick={() => startExam(50)}
                className="py-1.5 px-2 rounded-lg bg-slate-900 border border-slate-800 text-xs font-medium text-slate-300 hover:text-white hover:border-slate-700 transition-colors"
              >
                50 Soal
              </button>
              <button
                onClick={() => startExam(100)}
                className="py-1.5 px-2 rounded-lg bg-slate-900 border border-slate-800 text-xs font-medium text-slate-300 hover:text-white hover:border-slate-700 transition-colors"
              >
                100 Soal
              </button>
            </div>
          </div>

          {/* Cloud Exam History (Firebase) */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
              <span className="text-xs font-bold text-white uppercase tracking-wider">
                Riwayat Ujian Cloud (Firebase)
              </span>
              {currentUser && (
                <span className="text-[10px] text-emerald-400 font-mono">Tersinkron</span>
              )}
            </div>

            {currentUser ? (
              cbtHistory.length > 0 ? (
                <div className="space-y-2 max-h-56 overflow-y-auto pr-1 scrollbar-thin">
                  {cbtHistory.slice(0, 5).map((att) => (
                    <div
                      key={att.id}
                      className="bg-slate-900 p-2.5 rounded-lg border border-slate-800 flex items-center justify-between text-xs"
                    >
                      <div>
                        <span className="font-semibold text-white block">{att.examType}</span>
                        <span className="text-[10px] text-slate-400 font-mono">
                          {new Date(att.completedAt).toLocaleDateString('id-ID', {
                            day: 'numeric',
                            month: 'short',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </span>
                      </div>
                      <div className="text-right">
                        <span className={`font-mono font-bold ${att.isPassed ? 'text-emerald-400' : 'text-rose-400'}`}>
                          {att.scorePercent}%
                        </span>
                        <span className="text-[10px] text-slate-400 block font-mono">
                          {att.correct}/{att.totalQuestions}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-slate-400 text-center py-3">
                  Belum ada riwayat ujian yang tersimpan. Mulai tryout untuk merekam skor Anda.
                </p>
              )
            ) : (
              <p className="text-xs text-slate-400 text-center py-2">
                Masuk dengan Google di pojok kanan atas untuk menyimpan dan melacak riwayat skor CBT Anda secara permanen.
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
