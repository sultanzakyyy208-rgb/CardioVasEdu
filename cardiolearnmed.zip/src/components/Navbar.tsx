import React from 'react';
import { HeartPulse, User, LogIn, LogOut } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface NavbarProps {
  activeTab: '3d' | 'modules' | 'simulators' | 'cbt' | 'lecturer';
  onSelectTab: (tab: '3d' | 'modules' | 'simulators' | 'cbt' | 'lecturer') => void;
  onQuickStartCBT: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, onSelectTab, onQuickStartCBT }) => {
  const { currentUser, userProfile, signInWithGoogle, logout, updateRole } = useAuth();

  return (
    <header className="sticky top-0 z-50 w-full bg-slate-950/90 backdrop-blur-md border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Zone 1: Single text element brand wordmark */}
        <button
          onClick={() => onSelectTab('3d')}
          className="text-lg font-bold tracking-tight text-white flex items-center gap-2 hover:opacity-90 transition-opacity"
        >
          <HeartPulse className="w-5 h-5 text-rose-600" />
          <span>CardioLearnMed</span>
        </button>

        {/* Zone 2: 4-6 clean text navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-300">
          <button
            onClick={() => onSelectTab('3d')}
            className={`transition-colors whitespace-nowrap hover:text-white ${
              activeTab === '3d' ? 'text-rose-500 font-semibold underline underline-offset-8 decoration-2' : ''
            }`}
          >
            Anatomi 3D
          </button>

          <button
            onClick={() => onSelectTab('modules')}
            className={`transition-colors whitespace-nowrap hover:text-white ${
              activeTab === 'modules' ? 'text-rose-500 font-semibold underline underline-offset-8 decoration-2' : ''
            }`}
          >
            7 Modul Kuliah
          </button>

          <button
            onClick={() => onSelectTab('simulators')}
            className={`transition-colors whitespace-nowrap hover:text-white ${
              activeTab === 'simulators' ? 'text-rose-500 font-semibold underline underline-offset-8 decoration-2' : ''
            }`}
          >
            Simulator Praktikum
          </button>

          <button
            onClick={() => onSelectTab('cbt')}
            className={`transition-colors whitespace-nowrap hover:text-white ${
              activeTab === 'cbt' ? 'text-rose-500 font-semibold underline underline-offset-8 decoration-2' : ''
            }`}
          >
            Bank Soal CBT
          </button>

          <button
            onClick={() => onSelectTab('lecturer')}
            className={`transition-colors whitespace-nowrap hover:text-white ${
              activeTab === 'lecturer' ? 'text-rose-500 font-semibold underline underline-offset-8 decoration-2' : ''
            }`}
          >
            Portal Dosen
          </button>
        </nav>

        {/* Zone 3: 1-2 primary actions & Auth */}
        <div className="flex items-center gap-3">
          <button
            onClick={onQuickStartCBT}
            className="px-3.5 py-1.5 text-xs font-semibold text-white bg-rose-600 rounded-lg hover:bg-rose-500 transition-colors whitespace-nowrap shadow-sm shadow-rose-600/30"
          >
            CBT 12.000 Soal
          </button>

          {currentUser ? (
            <div className="flex items-center gap-2 pl-2 border-l border-slate-800">
              {currentUser.photoURL ? (
                <img
                  src={currentUser.photoURL}
                  alt={currentUser.displayName || 'User'}
                  className="w-7 h-7 rounded-full border border-slate-700 object-cover"
                />
              ) : (
                <div className="w-7 h-7 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-xs text-white">
                  <User className="w-3.5 h-3.5 text-slate-300" />
                </div>
              )}

              <button
                onClick={() => updateRole(userProfile?.role === 'lecturer' ? 'student' : 'lecturer')}
                className="hidden sm:inline-block text-[11px] text-slate-400 hover:text-white bg-slate-900 border border-slate-800 px-2 py-1 rounded"
                title="Ganti Peran Pengguna"
              >
                {userProfile?.role === 'lecturer' ? 'Dosen' : 'Mahasiswa'}
              </button>

              <button
                onClick={logout}
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-900 rounded-lg transition-colors"
                title="Keluar / Sign Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={signInWithGoogle}
              className="px-3 py-1.5 text-xs font-semibold text-slate-200 bg-slate-900 border border-slate-800 rounded-lg hover:text-white hover:bg-slate-800 transition-colors whitespace-nowrap flex items-center gap-1.5"
            >
              <LogIn className="w-3.5 h-3.5 text-emerald-400" />
              <span>Masuk Google</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};

