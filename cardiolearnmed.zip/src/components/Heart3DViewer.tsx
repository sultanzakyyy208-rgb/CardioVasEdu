import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { ANATOMICAL_PINS } from '../data/curriculumData';
import { AnatomicalPin } from '../types/cardio';
import { Play, Pause, RotateCcw, Eye, Info, Sparkles, Layers, Activity, Volume2, EyeOff } from 'lucide-react';

interface Heart3DViewerProps {
  onSelectPin?: (pin: AnatomicalPin) => void;
  selectedPinId?: string | null;
}

export const Heart3DViewer: React.FC<Heart3DViewerProps> = ({ onSelectPin, selectedPinId }) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [bpm, setBpm] = useState<number>(72);
  const [activeLayer, setActiveLayer] = useState<'all' | 'chambers' | 'coronary' | 'conduction' | 'fat_sulcus' | 'flow'>('all');
  const [activePin, setActivePin] = useState<AnatomicalPin | null>(null);
  const [cameraPreset, setCameraPreset] = useState<'anterior' | 'posterior' | 'chambers' | 'superior' | 'apex'>('anterior');
  const [showFatPads, setShowFatPads] = useState<boolean>(true);

  const threeRefs = useRef<{
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    renderer: THREE.WebGLRenderer;
    heartGroup: THREE.Group;
    lvMesh: THREE.Mesh;
    rvMesh: THREE.Mesh;
    atriaGroup: THREE.Group;
    vesselsGroup: THREE.Group;
    coronaryGroup: THREE.Group;
    conductionGroup: THREE.Group;
    particlesGroup: THREE.Group;
    fatGroup: THREE.Group;
    interiorChambersGroup: THREE.Group;
    pinSprites: THREE.Sprite[];
    clock: THREE.Clock;
  } | null>(null);

  useEffect(() => {
    if (!mountRef.current) return;
    const container = mountRef.current;
    const width = container.clientWidth;
    const height = container.clientHeight;

    // 1. Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x060b17);
    scene.fog = new THREE.FogExp2(0x060b17, 0.08);

    // 2. Camera
    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 100);
    camera.position.set(0.2, 0.4, 6.2);

    // 3. Renderer with realistic lighting & shadows
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // 4. Studio Medical Illumination
    const ambientLight = new THREE.AmbientLight(0xfff5f0, 0.9);
    scene.add(ambientLight);

    // Warm key light from top right anterior
    const keyLight = new THREE.DirectionalLight(0xffede0, 1.8);
    keyLight.position.set(4, 5, 5);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.width = 1024;
    keyLight.shadow.mapSize.height = 1024;
    scene.add(keyLight);

    // Cool fill light from lateral left
    const fillLight = new THREE.DirectionalLight(0x7fb2ff, 1.1);
    fillLight.position.set(-5, 2, 2);
    scene.add(fillLight);

    // Rim light from inferior posterior to separate apex and contour
    const rimLight = new THREE.DirectionalLight(0xff3366, 1.4);
    rimLight.position.set(0, -4, -4);
    scene.add(rimLight);

    // Subtle soft light from bottom to reveal apical detail
    const bottomLight = new THREE.PointLight(0xffeedd, 0.8, 10);
    bottomLight.position.set(0, -3, 2);
    scene.add(bottomLight);

    // 5. Master Heart Group (Tilted physiologically: apex pointed down, left, and anterior)
    const heartGroup = new THREE.Group();
    // Anatomical tilt (approx 40 deg to left, 30 deg forward)
    heartGroup.rotation.z = -0.15;
    heartGroup.rotation.x = 0.1;
    scene.add(heartGroup);

    // Realistic Anatomical Materials
    // A. Myocardium (Deep crimson/garnet muscular surface with organic gloss)
    const myocardiumMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color(0x8a1325),
      roughness: 0.35,
      metalness: 0.05,
      clearcoat: 0.25,
      clearcoatRoughness: 0.2,
      sheen: 0.3,
      sheenColor: new THREE.Color(0xbd2130)
    });

    // B. Epicardial Adipose Tissue (Fat pads along coronary sulcus and anterior groove)
    const fatMat = new THREE.MeshStandardMaterial({
      color: 0xdfbf77,
      roughness: 0.65,
      metalness: 0.05
    });

    // C. Ascending Aorta & Arch (Crimson-Scarlet with elastic sheen)
    const aortaMat = new THREE.MeshPhysicalMaterial({
      color: 0xb91c1c,
      roughness: 0.25,
      metalness: 0.12,
      clearcoat: 0.35
    });

    // D. Pulmonary Trunk & Arteries (Rich venous blue-cobalt)
    const pulmMat = new THREE.MeshPhysicalMaterial({
      color: 0x1d4ed8,
      roughness: 0.28,
      metalness: 0.1,
      clearcoat: 0.25
    });

    // E. Vena Cava (Deep navy venous blue)
    const venaCavaMat = new THREE.MeshStandardMaterial({
      color: 0x1e3a8a,
      roughness: 0.35,
      metalness: 0.08
    });

    // F. Coronary Arteries (Vivid arterial scarlet red)
    const coronaryArteryMat = new THREE.MeshStandardMaterial({
      color: 0xff2222,
      roughness: 0.2,
      metalness: 0.35
    });

    // G. Conduction System (Glowing Golden Amber)
    const conductionMat = new THREE.MeshStandardMaterial({
      color: 0xfacc15,
      emissive: 0xeab308,
      emissiveIntensity: 0.9,
      roughness: 0.2
    });

    // ==========================================
    // 6. ANATOMICALLY ACCURATE VENTRICLES MORPHOLOGY
    // ==========================================

    // --- LEFT VENTRICLE (LV): Forms the true conical Apex Cordis ---
    // Bullet/conical organic geometry with curved muscular contour
    const lvPoints: THREE.Vector2[] = [];
    // Profile curve for lathe/loft: (x = radius, y = height)
    lvPoints.push(new THREE.Vector2(0.02, -1.5)); // pointed apex tip
    lvPoints.push(new THREE.Vector2(0.35, -1.3));
    lvPoints.push(new THREE.Vector2(0.75, -0.9));
    lvPoints.push(new THREE.Vector2(1.05, -0.4));
    lvPoints.push(new THREE.Vector2(1.15, 0.1));
    lvPoints.push(new THREE.Vector2(1.0, 0.6));
    lvPoints.push(new THREE.Vector2(0.7, 0.85));
    lvPoints.push(new THREE.Vector2(0.3, 0.9));
    lvPoints.push(new THREE.Vector2(0.05, 0.9));

    const lvGeom = new THREE.LatheGeometry(lvPoints, 32);
    // Asymmetric organic scaling: elongated left-posterior, flatter septal wall
    lvGeom.scale(0.95, 1.0, 0.9);
    // Deform vertices to create the real interventricular septal flattening
    const lvPos = lvGeom.attributes.position;
    for (let i = 0; i < lvPos.count; i++) {
      let x = lvPos.getX(i);
      let y = lvPos.getY(i);
      let z = lvPos.getZ(i);
      // Flatten septal medial side (x > 0)
      if (x > 0) {
        x *= 0.75;
      }
      // Natural forward apex curve
      if (y < -0.8) {
        z += ((-0.8 - y) * 0.25);
        x -= ((-0.8 - y) * 0.18);
      }
      lvPos.setXYZ(i, x, y, z);
    }
    lvGeom.computeVertexNormals();
    const lvMesh = new THREE.Mesh(lvGeom, myocardiumMat);
    lvMesh.position.set(-0.35, -0.15, -0.05);
    lvMesh.castShadow = true;
    lvMesh.receiveShadow = true;
    heartGroup.add(lvMesh);

    // --- RIGHT VENTRICLE (RV): Crescent-shaped anterior wrap & Infundibulum ---
    // Wraps around the anterior surface of the septum and tapers up into the conus arteriosus
    const rvGeom = new THREE.SphereGeometry(1.05, 32, 24);
    // Reshape sphere into the crescent anterior cavity of the RV
    rvGeom.scale(0.85, 1.15, 0.7);
    const rvPos = rvGeom.attributes.position;
    for (let i = 0; i < rvPos.count; i++) {
      let x = rvPos.getX(i);
      let y = rvPos.getY(i);
      let z = rvPos.getZ(i);

      // Concave posterior matching LV bulge
      if (z < 0) {
        z *= 0.25;
      }
      // Conus arteriosus funnel tapering superiorly towards pulmonary trunk
      if (y > 0.4) {
        x = x * 0.65 - 0.15;
        z = z * 0.7 + 0.25;
      }
      // Inferior blunt border (does NOT reach the apex)
      if (y < -0.6) {
        y *= 0.8;
      }
      rvPos.setXYZ(i, x, y, z);
    }
    rvGeom.computeVertexNormals();
    const rvMesh = new THREE.Mesh(rvGeom, myocardiumMat);
    rvMesh.position.set(0.42, -0.05, 0.35);
    rvMesh.castShadow = true;
    rvMesh.receiveShadow = true;
    heartGroup.add(rvMesh);

    // ==========================================
    // 7. REALISTIC ATRIA & AURICLES (DOG-EAR FLAPS)
    // ==========================================
    const atriaGroup = new THREE.Group();

    // A. RIGHT ATRIUM (Smooth sinus venarum + triangular pectinate Right Auricle)
    const raMain = new THREE.Mesh(new THREE.SphereGeometry(0.72, 24, 20), myocardiumMat);
    raMain.scale.set(0.9, 1.05, 0.85);
    raMain.position.set(0.85, 0.75, -0.05);
    atriaGroup.add(raMain);

    // Auricula Dextra (Right Auricle): Pectinate ear-like flap overlapping aortic root
    const raAuricleCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0.65, 0.75, 0.3),
      new THREE.Vector3(0.4, 0.9, 0.55),
      new THREE.Vector3(0.12, 0.85, 0.6)
    ]);
    const raAuricleGeom = new THREE.TubeGeometry(raAuricleCurve, 16, 0.22, 12, false);
    const raAuricleMesh = new THREE.Mesh(raAuricleGeom, myocardiumMat);
    atriaGroup.add(raAuricleMesh);

    // B. LEFT ATRIUM (Posterior dome receiving 4 pulmonary veins + Left Auricle)
    const laMain = new THREE.Mesh(new THREE.SphereGeometry(0.7, 24, 20), myocardiumMat);
    laMain.scale.set(1.05, 0.95, 0.85);
    laMain.position.set(-0.45, 0.8, -0.55);
    atriaGroup.add(laMain);

    // Auricula Sinistra (Left Auricle): Finger-like curved appendage hugging pulmonary trunk
    const laAuricleCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-0.6, 0.8, -0.2),
      new THREE.Vector3(-0.8, 0.7, 0.1),
      new THREE.Vector3(-0.65, 0.55, 0.35)
    ]);
    const laAuricleGeom = new THREE.TubeGeometry(laAuricleCurve, 16, 0.16, 12, false);
    const laAuricleMesh = new THREE.Mesh(laAuricleGeom, myocardiumMat);
    atriaGroup.add(laAuricleMesh);

    heartGroup.add(atriaGroup);

    // ==========================================
    // 8. GREAT VESSELS (AORTA ARCH & PULMONARY TRUNK)
    // ==========================================
    const vesselsGroup = new THREE.Group();

    // A. ASCENDING AORTA & ARCUS AORTAE (Rooted behind pulmonary trunk, arching back and left)
    const aortaCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-0.05, 0.5, 0.05), // Aortic bulb / Sinuses of Valsalva
      new THREE.Vector3(0.05, 1.1, 0.15),  // Ascending aorta
      new THREE.Vector3(0.0, 1.65, 0.05),  // Peak of arch
      new THREE.Vector3(-0.35, 1.65, -0.3), // Arching left and backward
      new THREE.Vector3(-0.6, 1.25, -0.55), // Descending aorta
      new THREE.Vector3(-0.6, 0.2, -0.65)   // Thoracic aorta
    ]);
    const aortaGeom = new THREE.TubeGeometry(aortaCurve, 40, 0.27, 20, false);
    const aortaMesh = new THREE.Mesh(aortaGeom, aortaMat);
    aortaMesh.castShadow = true;
    vesselsGroup.add(aortaMesh);

    // Three Supra-Aortic Branches arising from the convexity of the aortic arch:
    // 1. Truncus Brachiocephalicus (innominate)
    const brachioMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.085, 0.09, 0.5, 14), aortaMat);
    brachioMesh.position.set(0.12, 1.85, 0.08);
    brachioMesh.rotation.z = -0.25;
    brachioMesh.rotation.x = -0.1;
    vesselsGroup.add(brachioMesh);

    // 2. A. Carotis Communis Sinistra
    const carotisMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.08, 0.45, 14), aortaMat);
    carotisMesh.position.set(-0.08, 1.88, -0.05);
    carotisMesh.rotation.z = -0.05;
    vesselsGroup.add(carotisMesh);

    // 3. A. Subclavia Sinistra
    const subclaviaMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.075, 0.42, 14), aortaMat);
    subclaviaMesh.position.set(-0.28, 1.82, -0.2);
    subclaviaMesh.rotation.z = 0.18;
    vesselsGroup.add(subclaviaMesh);

    // B. TRUNCUS PULMONALIS (Originates anterior to aorta, crosses diagonally to the left)
    const pulmCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0.2, 0.4, 0.55),   // Conus arteriosus emergence
      new THREE.Vector3(0.0, 0.95, 0.48),  // Crossing in front of aorta
      new THREE.Vector3(-0.25, 1.25, 0.18) // Bifurcation point under aortic arch
    ]);
    const pulmGeom = new THREE.TubeGeometry(pulmCurve, 28, 0.26, 18, false);
    const pulmTrunkMesh = new THREE.Mesh(pulmGeom, pulmMat);
    pulmTrunkMesh.castShadow = true;
    vesselsGroup.add(pulmTrunkMesh);

    // Bifurcation: Left & Right Pulmonary Arteries under the aortic arch
    // A. Pulmonalis Sinistra (goes to left lung)
    const leftPulmArt = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.15, 0.75, 14), pulmMat);
    leftPulmArt.position.set(-0.6, 1.25, 0.05);
    leftPulmArt.rotation.z = Math.PI / 2.3;
    leftPulmArt.rotation.y = 0.3;
    vesselsGroup.add(leftPulmArt);

    // A. Pulmonalis Dextra (passes underneath the aortic arch to right lung)
    const rightPulmArt = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.16, 0.85, 14), pulmMat);
    rightPulmArt.position.set(0.15, 1.2, -0.25);
    rightPulmArt.rotation.z = -Math.PI / 2.5;
    rightPulmArt.rotation.y = -0.2;
    vesselsGroup.add(rightPulmArt);

    // Ligamentum Arteriosum (fibrous band between pulmonary trunk bifurcation and aortic arch)
    const ligCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-0.25, 1.28, 0.12),
      new THREE.Vector3(-0.28, 1.45, 0.0)
    ]);
    const ligMesh = new THREE.Mesh(new THREE.TubeGeometry(ligCurve, 8, 0.035, 8, false), fatMat);
    vesselsGroup.add(ligMesh);

    // C. VENA CAVA SUPERIOR & INFERIOR
    // Vena Cava Superior (enters roof of right atrium)
    const svcMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.23, 0.25, 1.05, 16), venaCavaMat);
    svcMesh.position.set(0.95, 1.35, -0.15);
    vesselsGroup.add(svcMesh);

    // Vena Cava Inferior (enters floor of right atrium)
    const ivcMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.22, 0.8, 16), venaCavaMat);
    ivcMesh.position.set(0.85, -0.85, -0.35);
    vesselsGroup.add(ivcMesh);

    // D. FOUR PULMONARY VEINS (2 left, 2 right entering posterior wall of LA)
    const pvGeom = new THREE.CylinderGeometry(0.1, 0.11, 0.5, 12);
    // Right superior & inferior PV
    const rpv1 = new THREE.Mesh(pvGeom, pulmMat);
    rpv1.position.set(0.05, 0.9, -0.75);
    rpv1.rotation.z = -Math.PI / 3;
    vesselsGroup.add(rpv1);

    const rpv2 = new THREE.Mesh(pvGeom, pulmMat);
    rpv2.position.set(0.05, 0.65, -0.78);
    rpv2.rotation.z = -Math.PI / 3;
    vesselsGroup.add(rpv2);

    // Left superior & inferior PV
    const lpv1 = new THREE.Mesh(pvGeom, pulmMat);
    lpv1.position.set(-0.85, 0.9, -0.65);
    lpv1.rotation.z = Math.PI / 3;
    vesselsGroup.add(lpv1);

    const lpv2 = new THREE.Mesh(pvGeom, pulmMat);
    lpv2.position.set(-0.85, 0.65, -0.68);
    lpv2.rotation.z = Math.PI / 3;
    vesselsGroup.add(lpv2);

    heartGroup.add(vesselsGroup);

    // ==========================================
    // 9. CORONARY SULCUS & EPICARDIAL ADIPOSE FAT PADS
    // ==========================================
    const fatGroup = new THREE.Group();

    // Anterior interventricular fat pad (cushioning the LAD artery)
    const antFatCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-0.02, 0.45, 0.72),
      new THREE.Vector3(-0.06, 0.05, 0.78),
      new THREE.Vector3(-0.12, -0.4, 0.68),
      new THREE.Vector3(-0.25, -0.9, 0.45),
      new THREE.Vector3(-0.4, -1.35, 0.15)
    ]);
    const antFatMesh = new THREE.Mesh(new THREE.TubeGeometry(antFatCurve, 28, 0.08, 10, false), fatMat);
    fatGroup.add(antFatMesh);

    // Atrioventricular groove (Coronary sulcus) fat band encircling heart
    const avFatCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0.7, 0.4, 0.25),
      new THREE.Vector3(0.5, 0.45, 0.65),
      new THREE.Vector3(0.0, 0.5, 0.72),
      new THREE.Vector3(-0.55, 0.45, 0.5),
      new THREE.Vector3(-0.8, 0.35, 0.0),
      new THREE.Vector3(-0.65, 0.2, -0.5),
      new THREE.Vector3(0.2, 0.15, -0.65),
      new THREE.Vector3(0.75, 0.25, -0.2)
    ]);
    const avFatMesh = new THREE.Mesh(new THREE.TubeGeometry(avFatCurve, 36, 0.085, 10, true), fatMat);
    fatGroup.add(avFatMesh);

    heartGroup.add(fatGroup);

    // ==========================================
    // 10. CORONARY ARTERY VASCULATURE (LAD, LCX, RCA & BRANCHES)
    // ==========================================
    const coronaryGroup = new THREE.Group();

    // A. Left Anterior Descending (LAD / Ramus interventricularis anterior)
    const ladCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-0.05, 0.48, 0.74),
      new THREE.Vector3(-0.08, 0.15, 0.8),
      new THREE.Vector3(-0.15, -0.35, 0.7),
      new THREE.Vector3(-0.26, -0.85, 0.48),
      new THREE.Vector3(-0.42, -1.35, 0.18)
    ]);
    const ladMesh = new THREE.Mesh(new THREE.TubeGeometry(ladCurve, 32, 0.045, 10, false), coronaryArteryMat);
    coronaryGroup.add(ladMesh);

    // Diagonal branches of LAD (D1, D2)
    const d1Curve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-0.08, 0.15, 0.8),
      new THREE.Vector3(-0.35, 0.0, 0.75),
      new THREE.Vector3(-0.65, -0.2, 0.6)
    ]);
    coronaryGroup.add(new THREE.Mesh(new THREE.TubeGeometry(d1Curve, 16, 0.03, 8, false), coronaryArteryMat));

    // B. Left Circumflex Artery (LCx) in the left coronary sulcus
    const lcxCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-0.1, 0.48, 0.7),
      new THREE.Vector3(-0.5, 0.42, 0.52),
      new THREE.Vector3(-0.82, 0.32, 0.05),
      new THREE.Vector3(-0.75, 0.15, -0.45)
    ]);
    const lcxMesh = new THREE.Mesh(new THREE.TubeGeometry(lcxCurve, 28, 0.042, 10, false), coronaryArteryMat);
    coronaryGroup.add(lcxMesh);

    // Obtuse Marginal Branch (OM)
    const omCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-0.8, 0.3, 0.1),
      new THREE.Vector3(-0.9, -0.15, 0.05),
      new THREE.Vector3(-0.8, -0.55, -0.05)
    ]);
    coronaryGroup.add(new THREE.Mesh(new THREE.TubeGeometry(omCurve, 18, 0.03, 8, false), coronaryArteryMat));

    // C. Right Coronary Artery (RCA) in the right AV groove
    const rcaCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0.15, 0.48, 0.68),
      new THREE.Vector3(0.55, 0.38, 0.5),
      new THREE.Vector3(0.78, 0.1, 0.3),
      new THREE.Vector3(0.72, -0.35, 0.15),
      new THREE.Vector3(0.5, -0.65, -0.15),
      new THREE.Vector3(0.1, -0.85, -0.45) // Posterior descending artery (PDA)
    ]);
    const rcaMesh = new THREE.Mesh(new THREE.TubeGeometry(rcaCurve, 36, 0.044, 10, false), coronaryArteryMat);
    coronaryGroup.add(rcaMesh);

    // Acute Marginal Branch of RCA
    const amCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0.78, 0.05, 0.3),
      new THREE.Vector3(0.65, -0.35, 0.45),
      new THREE.Vector3(0.4, -0.65, 0.5)
    ]);
    coronaryGroup.add(new THREE.Mesh(new THREE.TubeGeometry(amCurve, 16, 0.03, 8, false), coronaryArteryMat));

    heartGroup.add(coronaryGroup);

    // ==========================================
    // 11. CARDIAC CONDUCTION PATHWAY
    // ==========================================
    const conductionGroup = new THREE.Group();

    // SA Node (subepicardial near junction of SVC and crista terminalis)
    const saNode = new THREE.Mesh(new THREE.SphereGeometry(0.09, 16, 16), conductionMat);
    saNode.position.set(0.9, 1.1, -0.1);
    conductionGroup.add(saNode);

    // AV Node (apex of triangle of Koch at interatrial septum base)
    const avNode = new THREE.Mesh(new THREE.SphereGeometry(0.085, 16, 16), conductionMat);
    avNode.position.set(0.18, 0.32, 0.05);
    conductionGroup.add(avNode);

    // Internodal Tracts (Anterior Bachmann, Middle Wenckebach, Posterior Thorel)
    const tractCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0.9, 1.1, -0.1),
      new THREE.Vector3(0.55, 0.7, 0.0),
      new THREE.Vector3(0.18, 0.32, 0.05)
    ]);
    conductionGroup.add(new THREE.Mesh(new THREE.TubeGeometry(tractCurve, 18, 0.02, 8, false), conductionMat));

    // Bundle of His (Penetrates central fibrous skeleton)
    const hisCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0.18, 0.32, 0.05),
      new THREE.Vector3(0.05, 0.1, 0.08),
      new THREE.Vector3(-0.02, -0.2, 0.1)
    ]);
    conductionGroup.add(new THREE.Mesh(new THREE.TubeGeometry(hisCurve, 16, 0.025, 8, false), conductionMat));

    // Right Bundle Branch (runs down the septum into the moderator band)
    const rbbCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-0.02, -0.2, 0.1),
      new THREE.Vector3(0.2, -0.5, 0.25),
      new THREE.Vector3(0.35, -0.85, 0.28)
    ]);
    conductionGroup.add(new THREE.Mesh(new THREE.TubeGeometry(rbbCurve, 20, 0.02, 8, false), conductionMat));

    // Left Bundle Branch (fans out over the subendocardium of the left ventricle)
    const lbbCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-0.02, -0.2, 0.1),
      new THREE.Vector3(-0.25, -0.55, 0.05),
      new THREE.Vector3(-0.4, -0.95, -0.05),
      new THREE.Vector3(-0.42, -1.35, 0.1) // reaching apex Purkinje
    ]);
    conductionGroup.add(new THREE.Mesh(new THREE.TubeGeometry(lbbCurve, 24, 0.022, 8, false), conductionMat));

    heartGroup.add(conductionGroup);

    // ==========================================
    // 12. INTERNAL CHAMBERS CUTAWAY STRUCTURES (Visible in Chambers Mode)
    // ==========================================
    const interiorChambersGroup = new THREE.Group();
    interiorChambersGroup.visible = false;

    // Papillary muscles & chordae tendineae inside Left Ventricle
    const papMat = new THREE.MeshStandardMaterial({ color: 0x991b1b, roughness: 0.4 });
    const chordaeMat = new THREE.MeshBasicMaterial({ color: 0xfef08a });

    const antPapMuscle = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.18, 0.5, 12), papMat);
    antPapMuscle.position.set(-0.55, -0.6, 0.15);
    interiorChambersGroup.add(antPapMuscle);

    const postPapMuscle = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.18, 0.45, 12), papMat);
    postPapMuscle.position.set(-0.35, -0.55, -0.3);
    interiorChambersGroup.add(postPapMuscle);

    // Chordae tendineae strings
    for (let c = 0; c < 5; c++) {
      const lineGeom = new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(-0.55, -0.35, 0.15),
        new THREE.Vector3(-0.4 + (c - 2) * 0.06, 0.1, 0.05 + (c % 2) * 0.05)
      ]);
      const chord = new THREE.Line(lineGeom, chordaeMat);
      interiorChambersGroup.add(chord);
    }

    heartGroup.add(interiorChambersGroup);

    // ==========================================
    // 13. DYNAMIC BLOOD FLOW PARTICLES
    // ==========================================
    const particlesGroup = new THREE.Group();
    const particleCount = 80;

    // Blue Venous Flow: SVC -> RA -> RV -> Pulmonary Trunk
    const blueParticlesGeom = new THREE.BufferGeometry();
    const bluePos = new Float32Array(particleCount * 3);
    for (let i = 0; i < particleCount; i++) {
      bluePos[i * 3] = 0.8 + (Math.random() - 0.5) * 0.25;
      bluePos[i * 3 + 1] = 1.2 - Math.random() * 1.8;
      bluePos[i * 3 + 2] = (Math.random() - 0.5) * 0.35;
    }
    blueParticlesGeom.setAttribute('position', new THREE.BufferAttribute(bluePos, 3));
    const bluePoints = new THREE.Points(
      blueParticlesGeom,
      new THREE.PointsMaterial({ color: 0x38bdf8, size: 0.08, transparent: true, opacity: 0.9 })
    );
    particlesGroup.add(bluePoints);

    // Red Arterial Flow: PV -> LA -> LV -> Aorta
    const redParticlesGeom = new THREE.BufferGeometry();
    const redPos = new Float32Array(particleCount * 3);
    for (let i = 0; i < particleCount; i++) {
      redPos[i * 3] = -0.35 + (Math.random() - 0.5) * 0.35;
      redPos[i * 3 + 1] = 0.6 - Math.random() * 1.8;
      redPos[i * 3 + 2] = (Math.random() - 0.5) * 0.35;
    }
    redParticlesGeom.setAttribute('position', new THREE.BufferAttribute(redPos, 3));
    const redPoints = new THREE.Points(
      redParticlesGeom,
      new THREE.PointsMaterial({ color: 0xf43f5e, size: 0.08, transparent: true, opacity: 0.9 })
    );
    particlesGroup.add(redPoints);

    heartGroup.add(particlesGroup);

    // ==========================================
    // 14. ANATOMICAL PINS SPRITES
    // ==========================================
    const pinSprites: THREE.Sprite[] = [];
    const pinCanvas = document.createElement('canvas');
    pinCanvas.width = 64;
    pinCanvas.height = 64;
    const pinCtx = pinCanvas.getContext('2d')!;
    pinCtx.fillStyle = '#ef4444';
    pinCtx.beginPath();
    pinCtx.arc(32, 32, 22, 0, Math.PI * 2);
    pinCtx.fill();
    pinCtx.lineWidth = 5;
    pinCtx.strokeStyle = '#ffffff';
    pinCtx.stroke();
    const pinTex = new THREE.CanvasTexture(pinCanvas);
    const pinMat = new THREE.SpriteMaterial({ map: pinTex, depthTest: false, transparent: true });

    ANATOMICAL_PINS.forEach((pin) => {
      const sprite = new THREE.Sprite(pinMat.clone());
      sprite.position.set(...pin.position);
      sprite.scale.set(0.18, 0.18, 1);
      sprite.userData = { pinData: pin };
      heartGroup.add(sprite);
      pinSprites.push(sprite);
    });

    const clock = new THREE.Clock();

    threeRefs.current = {
      scene,
      camera,
      renderer,
      heartGroup,
      lvMesh,
      rvMesh,
      atriaGroup,
      vesselsGroup,
      coronaryGroup,
      conductionGroup,
      particlesGroup,
      fatGroup,
      interiorChambersGroup,
      pinSprites,
      clock
    };

    // Orbit Drag Controls
    let isDragging = false;
    let prevMouse = { x: 0, y: 0 };

    const onMouseDown = (e: MouseEvent) => {
      isDragging = true;
      prevMouse = { x: e.clientX, y: e.clientY };
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDragging || !threeRefs.current) return;
      const dx = e.clientX - prevMouse.x;
      const dy = e.clientY - prevMouse.y;

      heartGroup.rotation.y += dx * 0.008;
      heartGroup.rotation.x += dy * 0.008;
      prevMouse = { x: e.clientX, y: e.clientY };
    };

    const onMouseUp = () => {
      isDragging = false;
    };

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      camera.position.z = Math.max(3.2, Math.min(8.5, camera.position.z + e.deltaY * 0.004));
    };

    // Raycast Pin Clicks
    const raycaster = new THREE.Raycaster();
    const mouseCoord = new THREE.Vector2();

    const onClick = (e: MouseEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      mouseCoord.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouseCoord.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(mouseCoord, camera);
      const hits = raycaster.intersectObjects(pinSprites, false);
      if (hits.length > 0) {
        const pinObj = hits[0].object.userData.pinData as AnatomicalPin;
        setActivePin(pinObj);
        if (onSelectPin) onSelectPin(pinObj);
      }
    };

    const dom = renderer.domElement;
    dom.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    dom.addEventListener('wheel', onWheel, { passive: false });
    dom.addEventListener('click', onClick);

    const onResize = () => {
      if (!mountRef.current || !threeRefs.current) return;
      const w = mountRef.current.clientWidth;
      const h = mountRef.current.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);

    // Animation Loop
    let animId: number;
    const renderLoop = () => {
      animId = requestAnimationFrame(renderLoop);
      const t = clock.getElapsedTime();

      if (isPlaying) {
        const freq = (bpm / 60) * Math.PI * 2;
        // Two-phase cardiac pump: Atrial contraction followed by quick ventricular systole with twisting apex!
        const systolePeak = Math.pow(Math.max(0, Math.sin(t * freq)), 2.8);
        
        // Ventricular wringing/squeezing:
        lvMesh.scale.set(
          0.95 * (1 - systolePeak * 0.08),
          1.0 * (1 - systolePeak * 0.06),
          0.9 * (1 - systolePeak * 0.08)
        );
        rvMesh.scale.set(
          0.85 * (1 - systolePeak * 0.07),
          1.15 * (1 - systolePeak * 0.05),
          0.7 * (1 - systolePeak * 0.07)
        );

        // Subtle organic rotation when not dragging
        if (!isDragging) {
          heartGroup.rotation.y += 0.0018;
        }

        // Conduction impulse glowing pulsation
        conductionMat.emissiveIntensity = 0.5 + Math.sin(t * freq * 2) * 0.5;

        // Animate Blood Flow Particles
        const bArr = bluePos;
        for (let i = 0; i < particleCount; i++) {
          bArr[i * 3 + 1] -= 0.016;
          if (bArr[i * 3 + 1] < -0.8) bArr[i * 3 + 1] = 1.3;
        }
        blueParticlesGeom.attributes.position.needsUpdate = true;

        const rArr = redPos;
        for (let i = 0; i < particleCount; i++) {
          rArr[i * 3 + 1] += 0.02;
          if (rArr[i * 3 + 1] > 1.6) rArr[i * 3 + 1] = -1.1;
        }
        redParticlesGeom.attributes.position.needsUpdate = true;
      }

      renderer.render(scene, camera);
    };
    renderLoop();

    return () => {
      cancelAnimationFrame(animId);
      dom.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      dom.removeEventListener('wheel', onWheel);
      dom.removeEventListener('click', onClick);
      window.removeEventListener('resize', onResize);
      renderer.dispose();
    };
  }, [bpm, isPlaying]);

  // Layer Visibility Switching
  useEffect(() => {
    if (!threeRefs.current) return;
    const { lvMesh, rvMesh, vesselsGroup, coronaryGroup, conductionGroup, fatGroup, interiorChambersGroup, particlesGroup } = threeRefs.current;

    const lvMat = lvMesh.material as THREE.MeshPhysicalMaterial;
    const rvMat = rvMesh.material as THREE.MeshPhysicalMaterial;

    if (activeLayer === 'all') {
      lvMat.wireframe = false;
      rvMat.wireframe = false;
      lvMat.opacity = 1.0;
      rvMat.opacity = 1.0;
      vesselsGroup.visible = true;
      coronaryGroup.visible = true;
      conductionGroup.visible = true;
      fatGroup.visible = showFatPads;
      interiorChambersGroup.visible = false;
      particlesGroup.visible = true;
    } else if (activeLayer === 'chambers') {
      // Cutaway/translucent view into interior
      lvMat.wireframe = false;
      rvMat.wireframe = false;
      lvMat.transparent = true;
      rvMat.transparent = true;
      lvMat.opacity = 0.28;
      rvMat.opacity = 0.28;
      vesselsGroup.visible = true;
      coronaryGroup.visible = false;
      conductionGroup.visible = true;
      fatGroup.visible = false;
      interiorChambersGroup.visible = true;
      particlesGroup.visible = true;
    } else if (activeLayer === 'coronary') {
      lvMat.wireframe = false;
      rvMat.wireframe = false;
      lvMat.transparent = false;
      rvMat.transparent = false;
      lvMat.opacity = 1.0;
      rvMat.opacity = 1.0;
      vesselsGroup.visible = false;
      coronaryGroup.visible = true;
      conductionGroup.visible = false;
      fatGroup.visible = true;
      interiorChambersGroup.visible = false;
      particlesGroup.visible = false;
    } else if (activeLayer === 'conduction') {
      lvMat.wireframe = true;
      rvMat.wireframe = true;
      vesselsGroup.visible = false;
      coronaryGroup.visible = false;
      conductionGroup.visible = true;
      fatGroup.visible = false;
      interiorChambersGroup.visible = false;
      particlesGroup.visible = false;
    } else if (activeLayer === 'fat_sulcus') {
      lvMat.wireframe = false;
      rvMat.wireframe = false;
      vesselsGroup.visible = true;
      coronaryGroup.visible = true;
      conductionGroup.visible = false;
      fatGroup.visible = true;
      interiorChambersGroup.visible = false;
      particlesGroup.visible = false;
    } else if (activeLayer === 'flow') {
      lvMat.wireframe = true;
      rvMat.wireframe = true;
      vesselsGroup.visible = true;
      coronaryGroup.visible = false;
      conductionGroup.visible = false;
      fatGroup.visible = false;
      interiorChambersGroup.visible = false;
      particlesGroup.visible = true;
    }
  }, [activeLayer, showFatPads]);

  // Camera Presets
  const setPreset = (preset: 'anterior' | 'posterior' | 'chambers' | 'superior' | 'apex') => {
    setCameraPreset(preset);
    if (!threeRefs.current) return;
    const { heartGroup, camera } = threeRefs.current;

    if (preset === 'anterior') {
      heartGroup.rotation.set(0.1, 0, -0.15);
      camera.position.set(0.2, 0.4, 6.2);
    } else if (preset === 'posterior') {
      heartGroup.rotation.set(0.1, Math.PI, -0.15);
      camera.position.set(0.2, 0.4, 6.2);
    } else if (preset === 'chambers') {
      heartGroup.rotation.set(0.2, 0.45, -0.1);
      camera.position.set(0, 0.1, 5.2);
      setActiveLayer('chambers');
    } else if (preset === 'superior') {
      heartGroup.rotation.set(1.4, 0, 0);
      camera.position.set(0, 2.8, 5.2);
    } else if (preset === 'apex') {
      heartGroup.rotation.set(-1.25, 0, 0);
      camera.position.set(-0.3, -2.8, 5.0);
    }
  };

  useEffect(() => {
    if (selectedPinId) {
      const pin = ANATOMICAL_PINS.find(p => p.id === selectedPinId);
      if (pin) setActivePin(pin);
    }
  }, [selectedPinId]);

  return (
    <div className="relative w-full h-[640px] rounded-2xl overflow-hidden border border-slate-800 bg-slate-950 shadow-2xl flex flex-col">
      {/* 3D WebGL Canvas */}
      <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Top Floating Controls Bar */}
      <div className="absolute top-4 left-4 right-4 flex items-center justify-between pointer-events-none gap-2">
        {/* Left: View Presets */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-900/90 backdrop-blur-md rounded-xl border border-slate-700/60 pointer-events-auto shadow-lg overflow-x-auto max-w-full">
          <span className="text-xs font-semibold text-slate-400 px-2 whitespace-nowrap">Sudut Pandang:</span>
          {(['anterior', 'posterior', 'chambers', 'superior', 'apex'] as const).map((view) => (
            <button
              key={view}
              onClick={() => setPreset(view)}
              className={`px-2.5 py-1 text-xs font-medium rounded-lg capitalize transition-colors whitespace-nowrap ${
                cameraPreset === view
                  ? 'bg-rose-600 text-white shadow'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              {view === 'anterior' ? 'Anterior (Fasad Depan)' : view === 'posterior' ? 'Posterior (Basis)' : view === 'chambers' ? 'Potongan Ruang' : view === 'superior' ? 'Superior (Aorta)' : 'Apeks Kordis'}
            </button>
          ))}
        </div>

        {/* Right: Layer Selector */}
        <div className="hidden sm:flex items-center gap-1.5 p-1 bg-slate-900/90 backdrop-blur-md rounded-xl border border-slate-700/60 pointer-events-auto shadow-lg">
          <Layers className="w-3.5 h-3.5 text-rose-400 ml-1.5" />
          <span className="text-xs font-semibold text-slate-400 px-1">Lapisan:</span>
          {[
            { id: 'all', label: 'Anatomi Lengkap' },
            { id: 'chambers', label: 'Transparan Ruang' },
            { id: 'coronary', label: 'Vaskular Koroner' },
            { id: 'conduction', label: 'Sistem Konduksi' },
            { id: 'flow', label: 'Aliran Darah' }
          ].map((layer) => (
            <button
              key={layer.id}
              onClick={() => setActiveLayer(layer.id as any)}
              className={`px-2.5 py-1 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                activeLayer === layer.id
                  ? 'bg-slate-800 text-rose-400 font-semibold border border-rose-500/30'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              {layer.label}
            </button>
          ))}
        </div>
      </div>

      {/* Bottom Floating Dashboard HUD */}
      <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between pointer-events-none gap-3">
        {/* Left: Cardiac Cycle & BPM Controller */}
        <div className="flex items-center gap-3 p-2 bg-slate-900/90 backdrop-blur-md rounded-xl border border-slate-700/60 pointer-events-auto shadow-xl">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="w-8 h-8 rounded-lg bg-rose-600 hover:bg-rose-500 flex items-center justify-center text-white transition-colors"
            title={isPlaying ? 'Jeda Pompa Jantung' : 'Putar Animasi Denyut'}
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
          </button>

          <div className="flex items-center gap-2 border-l border-slate-700/60 pl-3">
            <Activity className="w-4 h-4 text-emerald-400 animate-pulse" />
            <div className="flex flex-col">
              <span className="text-[10px] text-slate-400 font-medium leading-none">Laju Pompa</span>
              <span className="text-xs font-bold text-white font-mono tabular-nums leading-tight">{bpm} BPM</span>
            </div>
            <input
              type="range"
              min="40"
              max="160"
              value={bpm}
              onChange={(e) => setBpm(Number(e.target.value))}
              className="w-20 sm:w-28 accent-rose-500 cursor-pointer ml-1"
            />
          </div>

          <button
            onClick={() => {
              if (threeRefs.current) {
                threeRefs.current.heartGroup.rotation.set(0.1, 0, -0.15);
                threeRefs.current.camera.position.set(0.2, 0.4, 6.2);
              }
              setCameraPreset('anterior');
            }}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors border border-slate-800"
            title="Reset Posisi Sudut Pandang"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

        {/* Center: Educational Tip */}
        <div className="hidden xl:flex items-center gap-2 px-3 py-1.5 bg-slate-900/80 backdrop-blur-md rounded-lg border border-slate-800 text-xs text-slate-400 pointer-events-auto">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>Morfologi Organik Asimetris: Apeks ventrikel kiri menunjuk ke bawah-kiri · Geser mouse untuk rotasi 360°</span>
        </div>

        {/* Right: Anatomical Features Indicator */}
        <div className="flex items-center gap-3 px-3 py-2 bg-slate-900/90 backdrop-blur-md rounded-xl border border-slate-700/60 text-xs pointer-events-auto">
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-rose-600 shadow-sm shadow-rose-600/50" />
            <span className="text-slate-300">Aorta & LV</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-blue-600 shadow-sm shadow-blue-600/50" />
            <span className="text-slate-300">Pulmonal & RV</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-amber-400 shadow-sm shadow-amber-400/50" />
            <span className="text-slate-300">Bantalan Lemak & Sulkus</span>
          </div>
        </div>
      </div>

      {/* Selected Anatomical Pin Modal Card Overlay */}
      {activePin && (
        <div className="absolute top-16 left-4 max-w-sm w-full bg-slate-900/95 backdrop-blur-lg border border-slate-700/80 rounded-xl p-4 shadow-2xl z-20 pointer-events-auto animate-in fade-in slide-in-from-left-4 duration-200">
          <div className="flex items-start justify-between gap-2 border-b border-slate-800 pb-2 mb-2">
            <div>
              <h4 className="text-sm font-bold text-white leading-tight">{activePin.name}</h4>
              <p className="text-xs font-serif italic text-rose-300 mt-0.5">{activePin.latinName}</p>
            </div>
            <button
              onClick={() => setActivePin(null)}
              className="text-slate-400 hover:text-white p-1 rounded-md hover:bg-slate-800 text-xs"
            >
              ✕
            </button>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed mb-3">
            {activePin.description}
          </p>

          <div className="bg-slate-950/80 border border-amber-500/30 rounded-lg p-2.5">
            <div className="flex items-center gap-1.5 text-amber-400 text-xs font-semibold mb-1">
              <Info className="w-3.5 h-3.5" />
              <span>Signifikansi Klinis & Patologis</span>
            </div>
            <p className="text-xs text-amber-100/90 leading-snug">
              {activePin.clinicalSignificance}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
