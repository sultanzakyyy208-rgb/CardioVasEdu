import React, { useState } from 'react';
import { BLOOD_FLOW_STEPS, BEGINNER_GLOSSARY } from '../data/beginnerContent';
import { ArrowRight, CheckCircle2, Heart, HelpCircle, BookOpen, ChevronRight, ChevronLeft } from 'lucide-react';

export const BeginnerFlowWalkthrough: React.FC = () => {
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [showGlossary, setShowGlossary] = useState<boolean>(false);
  const [searchTerm, setSearchTerm] = useState<string>('');

  const currentStep = BLOOD_FLOW_STEPS[currentStepIndex];

  const filteredGlossary = BEGINNER_GLOSSARY.filter((g) =>
    g.term.toLowerCase().includes(searchTerm.toLowerCase()) ||
    g.simpleMeaning.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-2xl flex flex-col gap-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-wider mb-1">
            <span>Pondasi Belajar Pemula</span>
            <span aria-hidden="true">·</span>
            <span>Jantung dalam 4 Menit</span>
          </div>
          <h3 className="text-xl font-bold text-white tracking-tight">
            Bagaimana Darah Mengalir Melalui Jantung?
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            Panduan langkah-demi-langkah sirkulasi darah tanpa istilah rumit, dari seluruh tubuh ke paru-paru dan kembali lagi
          </p>
        </div>

        <button
          onClick={() => setShowGlossary(!showGlossary)}
          className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-colors flex items-center gap-2 border ${
            showGlossary
              ? 'bg-emerald-600 text-white border-emerald-500 shadow'
              : 'bg-slate-950 text-slate-300 border-slate-800 hover:text-white hover:border-slate-700'
          }`}
        >
          <BookOpen className="w-4 h-4 text-emerald-400" />
          <span>{showGlossary ? 'Tutup Kamus Istilah' : 'Kamus Istilah Mudah'}</span>
        </button>
      </div>

      {/* Step-by-Step Flowchart Stepper */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-thin">
        {BLOOD_FLOW_STEPS.map((s, idx) => (
          <button
            key={s.step}
            onClick={() => setCurrentStepIndex(idx)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 border ${
              currentStepIndex === idx
                ? 'bg-emerald-600 text-white border-emerald-500 shadow-md'
                : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white hover:bg-slate-800'
            }`}
          >
            <span className="font-mono text-[11px]">Langkah {s.step}</span>
          </button>
        ))}
      </div>

      {/* Current Step Active Card */}
      <div className="bg-slate-950 border border-emerald-500/30 rounded-xl p-6 shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-3 flex-1">
          <div className="flex items-center gap-2">
            <span className="w-7 h-7 rounded-lg bg-emerald-950 border border-emerald-500/60 text-emerald-400 font-bold text-xs flex items-center justify-center font-mono">
              {currentStep.step}
            </span>
            <span className="text-xs font-mono text-emerald-400 font-semibold">
              {currentStep.chamber}
            </span>
          </div>

          <h4 className="text-lg sm:text-xl font-bold text-white tracking-tight leading-snug">
            {currentStep.title}
          </h4>

          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed bg-slate-900/60 p-4 rounded-xl border border-slate-800">
            {currentStep.description}
          </p>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-400">Status Oksigen:</span>
            <span
              className={`font-semibold px-2.5 py-0.5 rounded-md ${
                currentStep.oxygenState.includes('Biru')
                  ? 'bg-blue-950 text-blue-300 border border-blue-800/60'
                  : 'bg-rose-950 text-rose-300 border border-rose-800/60'
              }`}
            >
              ● {currentStep.oxygenState}
            </span>
          </div>
        </div>

        {/* Visual Progress Dial */}
        <div className="flex flex-col items-center justify-center p-6 bg-slate-900 border border-slate-800 rounded-2xl shrink-0 w-full md:w-56 text-center">
          <Heart
            className={`w-12 h-12 mb-2 transition-transform duration-300 ${
              currentStep.oxygenState.includes('Biru') ? 'text-blue-500' : 'text-rose-500 animate-pulse'
            }`}
          />
          <span className="text-xs font-bold text-white font-mono">
            {currentStepIndex + 1} dari 6 Langkah
          </span>
          <span className="text-[10px] text-slate-400 mt-1">
            {currentStepIndex < 3 ? 'Sirkulasi Paru (Kanan)' : 'Sirkulasi Tubuh (Kiri)'}
          </span>

          <div className="flex items-center gap-2 mt-4 w-full justify-between">
            <button
              onClick={() => setCurrentStepIndex((prev) => Math.max(0, prev - 1))}
              disabled={currentStepIndex === 0}
              className="p-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-400 hover:text-white disabled:opacity-40"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => setCurrentStepIndex((prev) => Math.min(BLOOD_FLOW_STEPS.length - 1, prev + 1))}
              disabled={currentStepIndex === BLOOD_FLOW_STEPS.length - 1}
              className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs transition-colors flex items-center gap-1 shadow"
            >
              <span>Lanjut</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Glossary Drawer (Expandable) */}
      {showGlossary && (
        <div className="bg-slate-950 border border-slate-800 rounded-xl p-5 shadow-2xl animate-in fade-in duration-200">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3 mb-4">
            <div>
              <h4 className="text-sm font-bold text-white">Kamus Istilah Kardiovaskular Dasar</h4>
              <p className="text-xs text-slate-400 mt-0.5">Penjelasan istilah medis dalam bahasa awam yang mudah dipahami mahasiswa baru</p>
            </div>
            <input
              type="text"
              placeholder="Cari istilah (cth: Sistol, Troponin, Murmur)..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-slate-900 border border-slate-700 text-xs text-white px-3 py-1.5 rounded-lg w-full sm:w-64"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-80 overflow-y-auto pr-1 scrollbar-thin">
            {filteredGlossary.map((item) => (
              <div key={item.term} className="bg-slate-900/80 p-3 rounded-lg border border-slate-800">
                <span className="text-xs font-bold text-emerald-400 block">{item.term}</span>
                <p className="text-xs text-slate-200 mt-1 leading-relaxed">{item.simpleMeaning}</p>
                <div className="mt-2 pt-2 border-t border-slate-800/80 text-[11px] text-slate-400 italic">
                  <strong>Contoh Klinis: </strong>{item.clinicalContext}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
