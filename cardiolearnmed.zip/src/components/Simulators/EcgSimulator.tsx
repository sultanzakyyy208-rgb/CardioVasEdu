import React, { useState, useEffect, useRef } from 'react';
import { Activity, AlertTriangle, ShieldCheck, Heart, Zap, FileText } from 'lucide-react';

interface EcgRhythm {
  id: string;
  name: string;
  category: 'Fisiologis' | 'Iskemia / Infark' | 'Disritmia Fatal' | 'Gangguan Konduksi';
  rateBpm: number;
  rhythmRegularity: 'Reguler' | 'Ireguler' | 'Irregularly Irregular' | 'Reguler (Disosiasi AV)';
  pWave: string;
  prInterval: string;
  qrsDuration: string;
  stSegment: string;
  pathophysiology: string;
  clinicalCriteria: string[];
  immediateManagement: string[];
  wavePathGenerator: (t: number) => number; // returns Y coordinate offset
}

const ECG_RHYTHMS: EcgRhythm[] = [
  {
    id: 'nsr',
    name: 'Irama Sinus Normal (Normal Sinus Rhythm)',
    category: 'Fisiologis',
    rateBpm: 75,
    rhythmRegularity: 'Reguler',
    pWave: 'Positif di lead II, negatif di aVR, mendahului setiap QRS',
    prInterval: '0.16 detik (Normal 0.12 - 0.20 s)',
    qrsDuration: '0.08 detik (Normal < 0.12 s)',
    stSegment: 'Isoelektrik datar pada garis dasar',
    pathophysiology: 'Impuls berasal dari Nodus Sinoatrialis (SA Node) dan dihantarkan secara normal melalui nodus AV, berkas His, dan serat Purkinje menuju miokardium ventrikel.',
    clinicalCriteria: [
      'Laju denyut jantung: 60 - 100 kali/menit',
      'Irama reguler dengan interval R-R konstan',
      'Gelombang P seragam mendahului setiap kompleks QRS',
      'Interval PR konstan (3 - 5 kotak kecil)'
    ],
    immediateManagement: [
      'Temuan normal fisiologis; tidak memerlukan intervensi farmakologis atau elektrik.',
      'Pertahankan gaya hidup sehat dan pemantauan berkala.'
    ],
    wavePathGenerator: (t) => {
      // Periodic ECG wave cycle every 1.0 unit
      const cycle = t % 1.0;
      if (cycle < 0.1) return 0;
      if (cycle < 0.2) return -Math.sin((cycle - 0.1) * 10 * Math.PI) * 12; // P wave
      if (cycle < 0.28) return 0; // PR segment
      if (cycle < 0.30) return 6; // Q wave dip
      if (cycle < 0.35) return -70; // R wave peak
      if (cycle < 0.38) return 15; // S wave dip
      if (cycle < 0.50) return 0; // ST segment isoelectric
      if (cycle < 0.65) return -Math.sin((cycle - 0.50) * 6.66 * Math.PI) * 20; // T wave
      return 0;
    }
  },
  {
    id: 'stemi_anterior',
    name: 'STEMI Anterior Ekstensif (Sadapan V1 - V4)',
    category: 'Iskemia / Infark',
    rateBpm: 88,
    rhythmRegularity: 'Reguler',
    pWave: 'Normal mendahului kompleks QRS',
    prInterval: '0.15 detik',
    qrsDuration: '0.09 detik',
    stSegment: 'Elevasi ST konveks (Tombstone pattern) >= 3.5 mm di atas garis isoelektrik',
    pathophysiology: 'Oklusi total akut cabang Ramus Interventricularis Anterior (Left Anterior Descending / LAD) oleh trombus aterosarkomatik, memicu iskemia transmural luas dinding anterior dan apeks ventrikel kiri.',
    clinicalCriteria: [
      'Elevasi ST konveks >= 2 mm pada V2-V3 pria (>=1.5 mm wanita) dan >= 1 mm di sadapan bersebelahan',
      'Resiprokal ST depresi pada sadapan inferior (II, III, aVF)',
      'Evolusi gelombang Q patologis dalam 6-24 jam jika tidak direperfusi',
      'Peningkatan bermakna hs-Troponin I/T kardiak'
    ],
    immediateManagement: [
      'Oksigen hanya jika SpO2 < 90%',
      'Loading Aspilet 160-320 mg kunyah + Ticagrelor 180 mg atau Clopidogrel 600 mg',
      'Nitrat sublingual 5 mg (waspadai hipotensi TD < 90 mmHg)',
      'Primary PCI (door-to-device < 90 menit) atau Fibrinolisis (< 30 menit jika PCI > 120 menit)'
    ],
    wavePathGenerator: (t) => {
      const cycle = t % 1.0;
      if (cycle < 0.1) return 0;
      if (cycle < 0.2) return -Math.sin((cycle - 0.1) * 10 * Math.PI) * 12; // P
      if (cycle < 0.28) return 0;
      if (cycle < 0.30) return 10; // Q wave patologis
      if (cycle < 0.35) return -60; // R wave
      if (cycle < 0.38) return -5; // S wave shallow
      // Huge ST elevation tombstone blending with T wave
      if (cycle < 0.65) return -38 - Math.sin((cycle - 0.38) * 3.7 * Math.PI) * 25;
      return 0;
    }
  },
  {
    id: 'stemi_inferior',
    name: 'STEMI Inferior (Sadapan II, III, aVF)',
    category: 'Iskemia / Infark',
    rateBpm: 60,
    rhythmRegularity: 'Reguler',
    pWave: 'Normal di lead II mendahului QRS',
    prInterval: '0.18 detik',
    qrsDuration: '0.08 detik',
    stSegment: 'Elevasi ST konveks di sadapan II, III, aVF dengan ST depresi di I dan aVL',
    pathophysiology: 'Oklusi akut pada Arteria Coronaria Dextra (RCA) proksimal/distal yang mensuplai dinding diafragmatika ventrikel kiri dan nodus AV.',
    clinicalCriteria: [
      'Elevasi ST >= 1 mm pada sadapan II, III, dan aVF',
      'Resiprokal depresi ST di lead I dan aVL',
      'Kerap disertai bradikardia sinus atau AV block akibat iskemia nodus AV',
      'Wajib rekam EKG sadapan kanan V3R-V4R untuk deteksi infark ventrikel kanan'
    ],
    immediateManagement: [
      'DAPT Loading: Aspirin + Ticagrelor / Clopidogrel',
      'KONTRAINDIKASI RELATIF: Nitrat dan Morfin jika dicurigai infark ventrikel kanan (menyebabkan hipotensi kolaps)',
      'Tatalaksana utama bila hipotensi: Hidrasi cairan kristaloid intravena (NaCl 0.9%)',
      'Aktivasi tim kateterisasi jantung untuk Primary PCI segera'
    ],
    wavePathGenerator: (t) => {
      const cycle = t % 1.0;
      if (cycle < 0.12) return 0;
      if (cycle < 0.22) return -Math.sin((cycle - 0.12) * 10 * Math.PI) * 10; // P
      if (cycle < 0.30) return 0;
      if (cycle < 0.33) return 8; // Q
      if (cycle < 0.37) return -55; // R
      if (cycle < 0.40) return 0;
      // ST elevation
      if (cycle < 0.68) return -28 - Math.sin((cycle - 0.40) * 3.5 * Math.PI) * 18;
      return 0;
    }
  },
  {
    id: 'af_rvr',
    name: 'Fibrilasi Atrium Respons Cepat (AF with RVR)',
    category: 'Disritmia Fatal',
    rateBpm: 135,
    rhythmRegularity: 'Irregularly Irregular',
    pWave: 'Tidak ada gelombang P teratur (digantikan gelombang f fibrilasi berombak)',
    prInterval: 'Tidak dapat diukur',
    qrsDuration: '0.08 detik (sempit < 0.12 s)',
    stSegment: 'Dapat disertai depresi ST sekunder akibat takikardia',
    pathophysiology: 'Kekacauan impuls elektrik mikro-reentry di dalam atrium (sering bermula dari muara vena pulmonalis di atrium kiri), menembakkan 400-600 impuls/menit. Nodus AV menyaring sebagian impuls sehingga respons ventrikel tidak teratur.',
    clinicalCriteria: [
      'Ketiadaan gelombang P sejati; digantikan undulasi garis dasar ireguler (fibrillatory f waves)',
      'Interval R-R yang sama sekali tidak beraturan (irregularly irregular)',
      'Laju respons ventrikel > 100 kali/menit mendefinisikan respons cepat (RVR)',
      'Risiko tinggi pembentukan trombus di aurikula sinistra (LAA)'
    ],
    immediateManagement: [
      'Evaluasi stabilitas hemodinamik (Hipotensi, Syok, Nyeri dada iskemia, Gagal jantung akut)',
      'Jika TIDAK STABIL: Kardioversi elektrik tersinkronisasi (Synchronized Cardioversion 120-200 Joule)',
      'Jika STABIL: Pengendali laju (Rate Control) dengan Beta-bloker IV (Bisoprolol/Metoprolol) atau Diltiazem IV',
      'Hitung skor CHA2DS2-VASc untuk indikasi Antikoagulan Oral Langsung (DOAC) jangka panjang'
    ],
    wavePathGenerator: (t) => {
      // Rapid pseudo-irregular cycle with noisy baseline
      const noise = (Math.sin(t * 40) + Math.cos(t * 75)) * 4;
      const subT = (t * 1.8) % 1.0;
      if (subT > 0.25 && subT < 0.32) {
        return -65 + noise; // sharp R wave
      }
      return noise;
    }
  },
  {
    id: 'vt_monomorphic',
    name: 'Ventricular Tachycardia (VT Monomorfik)',
    category: 'Disritmia Fatal',
    rateBpm: 165,
    rhythmRegularity: 'Reguler',
    pWave: 'Disosiasi AV (gelombang P terpisah tidak terkait dengan QRS)',
    prInterval: 'Tidak teridentifikasi',
    qrsDuration: '0.16 detik (Lebar bermakna >= 0.12 s)',
    stSegment: 'Arah gelombang T berlawanan dengan defleksi utama QRS (diskordan)',
    pathophysiology: 'Sirkuit re-entry abnormal di sekitar jaringan parut miokard (scar-related) akibat infark lama atau kelainan kardiomiopati, mencetuskan depolarisasi ektopik ventrikel cepat.',
    clinicalCriteria: [
      'Kompleks QRS lebar (>0.12 s / 3 kotak kecil) monomorfik beruntun >= 3 denyut',
      'Laju ventrikel 140 - 220 kali/menit',
      'Adanya disosiasi atrioventrikular, fusion beats, atau capture beats',
      'Kriteria Brugada positif untuk takikardia ventrikel'
    ],
    immediateManagement: [
      'Cek NADI: Jika TANPA NADI -> Protokol Henti Jantung (Defibrilasi Asinkron 200 J + RJP + Epinefrin/Amiodaron)',
      'Jika NADI ADA dan TIDAK STABIL -> Kardioversi Tersinkronisasi 100 Joule',
      'Jika NADI ADA dan STABIL -> Infus Amiodaron 150 mg IV dalam 10 menit dilanjutkan titrasi maintenance'
    ],
    wavePathGenerator: (t) => {
      const cycle = (t * 2.2) % 1.0;
      // Wide sinusoidal VT wave
      return -Math.sin(cycle * Math.PI * 2) * 55;
    }
  },
  {
    id: 'chb_degree3',
    name: 'Total AV Block / Blok AV Derajat 3',
    category: 'Gangguan Konduksi',
    rateBpm: 38,
    rhythmRegularity: 'Reguler (Disosiasi AV)',
    pWave: 'Gelombang P berdenyut teratur (~75 bpm) independen dari QRS',
    prInterval: 'Bervariasi secara total (tidak ada hubungan konstan)',
    qrsDuration: '0.14 detik (Ventricular Escape Rhythm lambat ~35-40 bpm)',
    stSegment: 'Sekunder terhadap konduksi idioventrikular',
    pathophysiology: 'Kegagalan total transmisi impuls elektrik dari atrium ke ventrikel di tingkat nodus AV atau infranodal (berkas His/cabang berkas). Pacemaker subsidiari di ventrikel mengambil alih laju (escape rhythm).',
    clinicalCriteria: [
      'Disosiasi komplit antara gelombang P dan kompleks QRS (laju P > laju QRS)',
      'Interval P-P teratur dan interval R-R teratur, namun tidak ada asosiasi PR',
      'Laju ventrikel bradikardia berat (30 - 45 bpm)',
      'Pasien berisiko tinggi mengalami sinkop Stokes-Adams atau henti asistol'
    ],
    immediateManagement: [
      'Injeksi Sulfas Atropin 1 mg IV (dapat diulang tiap 3-5 menit, maksimal 3 mg)',
      'Bila atropin tidak responsif: Pacu Jantung Transkutan (Transcutaneous Pacing / TCP) segera',
      'Infus kronotropik: Dopamin (5-20 mcg/kgBB/menit) atau Epinefrin (2-10 mcg/menit)',
      'Konsultasi Sp.JP untuk pemasangan Pacu Jantung Permanen (Permanent Pacemaker / PPM)'
    ],
    wavePathGenerator: (t) => {
      // P wave repeats every 0.3s, QRS repeats every 0.8s (complete dissociation)
      const pCycle = (t * 1.4) % 1.0;
      let y = 0;
      if (pCycle > 0.1 && pCycle < 0.25) {
        y -= Math.sin((pCycle - 0.1) * 6.66 * Math.PI) * 12; // P wave
      }
      const qrsCycle = (t * 0.55) % 1.0;
      if (qrsCycle > 0.35 && qrsCycle < 0.45) {
        y -= Math.sin((qrsCycle - 0.35) * 10 * Math.PI) * 60; // wide QRS
      }
      return y;
    }
  }
];

export const EcgSimulator: React.FC = () => {
  const [selectedRhythm, setSelectedRhythm] = useState<EcgRhythm>(ECG_RHYTHMS[0]);
  const [paperSpeed, setPaperSpeed] = useState<number>(25); // mm/s
  const [gain, setGain] = useState<number>(10); // mm/mV
  const [sweepX, setSweepX] = useState<number>(0);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const requestRef = useRef<number | undefined>(undefined);
  const timeRef = useRef<number>(0);

  // Live real-time oscilloscope canvas animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let xPos = 0;
    const width = canvas.width;
    const height = canvas.height;
    const baseline = height / 2;

    // Draw ECG pink/red grid once or clear with fade
    const drawGrid = () => {
      ctx.fillStyle = '#0a0f1d';
      ctx.fillRect(0, 0, width, height);

      // 1 mm small squares (light red/pink)
      ctx.lineWidth = 0.5;
      ctx.strokeStyle = '#1e293b';
      for (let x = 0; x < width; x += 10) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += 10) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // 5 mm large squares (darker accent grid)
      ctx.lineWidth = 1;
      ctx.strokeStyle = '#334155';
      for (let x = 0; x < width; x += 50) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += 50) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }
    };

    drawGrid();

    let lastTime = performance.now();
    let currentTraceX = 0;
    let prevY = baseline;

    const render = (now: number) => {
      const delta = (now - lastTime) / 1000;
      lastTime = now;
      timeRef.current += delta;

      // Speed in pixels per frame
      const speed = (paperSpeed / 25) * 3;
      const nextX = currentTraceX + speed;

      // Erase ahead sweep cursor bar
      ctx.fillStyle = '#0a0f1d';
      ctx.fillRect(currentTraceX, 0, 15, height);

      // Redraw grid lines in erased section
      ctx.lineWidth = 0.5;
      ctx.strokeStyle = '#1e293b';
      for (let gx = Math.floor(currentTraceX / 10) * 10; gx <= currentTraceX + 15; gx += 10) {
        ctx.beginPath();
        ctx.moveTo(gx, 0);
        ctx.lineTo(gx, height);
        ctx.stroke();
      }

      // Compute Y offset
      const yOffset = selectedRhythm.wavePathGenerator(timeRef.current);
      const currentY = baseline + yOffset * (gain / 10);

      // Draw glowing ECG trace line
      ctx.beginPath();
      ctx.moveTo(currentTraceX, prevY);
      ctx.lineTo(nextX, currentY);
      ctx.strokeStyle = '#10b981'; // medical monitor green
      ctx.lineWidth = 2.2;
      ctx.shadowColor = '#10b981';
      ctx.shadowBlur = 6;
      ctx.stroke();
      ctx.shadowBlur = 0;

      prevY = currentY;
      currentTraceX = nextX;
      setSweepX(currentTraceX);

      // Wrap around screen edge
      if (currentTraceX >= width) {
        currentTraceX = 0;
        prevY = baseline;
      }

      requestRef.current = requestAnimationFrame(render);
    };

    requestRef.current = requestAnimationFrame(render);

    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [selectedRhythm, paperSpeed, gain]);

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-2xl flex flex-col gap-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-emerald-400" />
            <h3 className="text-lg font-bold text-white tracking-tight">Simulator EKG 12-Sadapan & Interpretasi Irama</h3>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Visualisasi Osiloskop Real-Time: Analisis Gelombang P-QRS-T, Kriteria Diagnosis & Tatalaksana Kegawatdaruratan
          </p>
        </div>

        {/* Paper Calibration & Gain */}
        <div className="flex items-center gap-2 bg-slate-950 p-1.5 rounded-lg border border-slate-800 text-xs">
          <span className="text-slate-400 pl-2">Kecepatan:</span>
          <button
            onClick={() => setPaperSpeed(25)}
            className={`px-2 py-1 rounded font-mono ${paperSpeed === 25 ? 'bg-slate-800 text-emerald-400 font-bold' : 'text-slate-400'}`}
          >
            25 mm/s
          </button>
          <button
            onClick={() => setPaperSpeed(50)}
            className={`px-2 py-1 rounded font-mono ${paperSpeed === 50 ? 'bg-slate-800 text-emerald-400 font-bold' : 'text-slate-400'}`}
          >
            50 mm/s
          </button>
          <span className="text-slate-600">|</span>
          <span className="text-slate-400">Voltase:</span>
          <button
            onClick={() => setGain(10)}
            className={`px-2 py-1 rounded font-mono ${gain === 10 ? 'bg-slate-800 text-emerald-400 font-bold' : 'text-slate-400'}`}
          >
            10 mm/mV
          </button>
          <button
            onClick={() => setGain(20)}
            className={`px-2 py-1 rounded font-mono ${gain === 20 ? 'bg-slate-800 text-emerald-400 font-bold' : 'text-slate-400'}`}
          >
            20 mm/mV
          </button>
        </div>
      </div>

      {/* Rhythm Selection Chips */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2">
        {ECG_RHYTHMS.map((rhythm) => (
          <button
            key={rhythm.id}
            onClick={() => setSelectedRhythm(rhythm)}
            className={`p-2.5 rounded-lg text-left transition-all border flex flex-col justify-between ${
              selectedRhythm.id === rhythm.id
                ? 'bg-slate-800 border-emerald-500 shadow-md shadow-emerald-500/10'
                : 'bg-slate-950 border-slate-800 hover:border-slate-700'
            }`}
          >
            <span className="text-[10px] uppercase font-semibold tracking-wider text-slate-400">
              {rhythm.category}
            </span>
            <span className="text-xs font-bold text-white mt-1 leading-tight line-clamp-2">
              {rhythm.name.split('(')[0]}
            </span>
            <span className="text-[11px] font-mono text-emerald-400 mt-2">
              {rhythm.rateBpm} BPM · {rhythm.rhythmRegularity}
            </span>
          </button>
        ))}
      </div>

      {/* Real-time Oscilloscope ECG Canvas */}
      <div className="relative rounded-xl overflow-hidden border border-slate-800 bg-slate-950 shadow-inner">
        {/* ECG Lead Indicator Top-Left */}
        <div className="absolute top-3 left-3 flex items-center gap-2 bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-md border border-slate-700/80 z-10">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span className="text-xs font-bold text-white">Lead II / V2</span>
          <span className="text-xs font-mono text-emerald-400 font-semibold tabular-nums ml-2">
            HR: {selectedRhythm.rateBpm} bpm
          </span>
          <span className="text-xs text-slate-400">· 25mm/s 10mm/mV</span>
        </div>

        {/* Live Sweep Indicator */}
        <div
          className="absolute top-0 bottom-0 w-1 bg-emerald-400/40 pointer-events-none z-10"
          style={{ left: `${(sweepX / 800) * 100}%` }}
        />

        <canvas
          ref={canvasRef}
          width={800}
          height={240}
          className="w-full h-60 block"
        />
      </div>

      {/* Detailed Diagnostic & Clinical Pearl Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Left: EKG Measurement Criteria */}
        <div className="bg-slate-950 border border-slate-800 rounded-xl p-4">
          <div className="flex items-center gap-2 text-sky-400 text-xs font-bold mb-3 border-b border-slate-800 pb-2">
            <FileText className="w-4 h-4" />
            <span>Karakteristik Parameter Gelombang EKG</span>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs mb-4">
            <div className="bg-slate-900 p-2 rounded border border-slate-800">
              <span className="text-slate-400">Gelombang P:</span>
              <p className="text-white font-medium mt-0.5">{selectedRhythm.pWave}</p>
            </div>
            <div className="bg-slate-900 p-2 rounded border border-slate-800">
              <span className="text-slate-400">Interval PR:</span>
              <p className="text-white font-medium mt-0.5">{selectedRhythm.prInterval}</p>
            </div>
            <div className="bg-slate-900 p-2 rounded border border-slate-800">
              <span className="text-slate-400">Durasi Kompleks QRS:</span>
              <p className="text-white font-medium mt-0.5">{selectedRhythm.qrsDuration}</p>
            </div>
            <div className="bg-slate-900 p-2 rounded border border-slate-800">
              <span className="text-slate-400">Morfologi Segmen ST:</span>
              <p className="text-white font-medium mt-0.5">{selectedRhythm.stSegment}</p>
            </div>
          </div>

          <div className="text-xs">
            <span className="text-slate-400 font-semibold block mb-1.5">Kriteria Diagnostik Standar SKDI:</span>
            <ul className="space-y-1">
              {selectedRhythm.clinicalCriteria.map((criterion, idx) => (
                <li key={idx} className="flex items-start gap-1.5 text-slate-300">
                  <span className="text-emerald-400 font-bold">✓</span>
                  <span>{criterion}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Right: Pathophysiology & Emergency Management */}
        <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-rose-400 text-xs font-bold mb-3 border-b border-slate-800 pb-2">
              <AlertTriangle className="w-4 h-4" />
              <span>Patofisiologi & Protokol Kegawatdaruratan (Emergency Protocol)</span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed mb-4">
              <strong className="text-slate-100">Dasar Elektrofisiologis: </strong>
              {selectedRhythm.pathophysiology}
            </p>
          </div>

          <div className="bg-slate-900/90 border border-rose-500/30 rounded-lg p-3">
            <span className="text-xs font-bold text-rose-300 block mb-2">
              Langkah Tatalaksana Awal Sesuai Panduan ACLS / PERKI:
            </span>
            <ul className="space-y-1.5 text-xs text-slate-200">
              {selectedRhythm.immediateManagement.map((step, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <span className="w-4 h-4 rounded-full bg-rose-950 border border-rose-600 text-rose-400 flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <span>{step}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
