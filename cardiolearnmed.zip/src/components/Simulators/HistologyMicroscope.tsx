import React, { useState } from 'react';
import { Microscope, ZoomIn, ZoomOut, Eye, Info, Sparkles, Filter } from 'lucide-react';

interface HistologyPin {
  id: string;
  name: string;
  coords: { x: number; y: number }; // percentage 0 - 100
  description: string;
  clinicalExamPoint: string;
}

const HISTOLOGY_PINS: HistologyPin[] = [
  {
    id: 'hpin_intercalated_disc',
    name: 'Diskus Interkalaris (Intercalated Disc)',
    coords: { x: 48, y: 52 },
    description: 'Garis transversal gelap berundak yang menghubungkan ujung kardiomiosit yang berdekatan. Terdiri dari fascia adherens, desmosom (macula adherens), dan gap junctions.',
    clinicalExamPoint: 'Tempat lokalisasi protein Connexin-43. Kerusakan taut ini akibat iskemia memicu hilangnya sinsitium elektrik dan mencetuskan aritmia re-entry.'
  },
  {
    id: 'hpin_nucleus',
    name: 'Nukleus Sentral Kardiomiosit',
    coords: { x: 32, y: 40 },
    description: 'Nukleus oval pucat terletak di sentral serat (berbeda dengan otot rangka yang memiliki banyak nukleus di perifer). Biasanya berjumlah 1, jarang 2 per sel.',
    clinicalExamPoint: 'Di dekat kutub nukleus sering ditemukan akumulasi granula pigmen lipofuscin ("wear-and-tear pigment") berwarna coklat-emas seiring pertambahan usia.'
  },
  {
    id: 'hpin_branching',
    name: 'Percabangan Serat Kardiomiosit',
    coords: { x: 65, y: 35 },
    description: 'Ciri morfologis khas di mana serat otot jantung bercabang dan beranastomosis membentuk anyaman tiga dimensi yang kokoh untuk menahan tekanan intrakardiak.',
    clinicalExamPoint: 'Miopati hipertrofik (HCM) menunjukkan gambaran "myocyte disarray" di mana percabangan sel kehilangan orientasi paralel rapinya.'
  },
  {
    id: 'hpin_capillary',
    name: 'Mikrosirkulasi Kapiler Endomisium',
    coords: { x: 55, y: 72 },
    description: 'Ruang interstisial jaringan ikat longgar (endomisium) yang sangat kaya akan pembuluh darah kapiler kontinu (rasio 1:1 antara kapiler dan kardiomiosit).',
    clinicalExamPoint: 'Kepadatan kapiler yang sangat tinggi menjamin pasokan oksigen yang kontinu untuk mempertahankan fosforilasi oksidatif mitokondria miosit.'
  }
];

export const HistologyMicroscope: React.FC = () => {
  const [zoomLevel, setZoomLevel] = useState<number>(1); // 1x, 2x, 3.5x
  const [activeStain, setActiveStain] = useState<'he' | 'trichrome' | 'verhoeff'>('he');
  const [selectedPin, setSelectedPin] = useState<HistologyPin | null>(HISTOLOGY_PINS[0]);
  const [panPos, setPanPos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-2xl flex flex-col gap-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Microscope className="w-5 h-5 text-indigo-400" />
            <h3 className="text-lg font-bold text-white tracking-tight">Mikroskop Virtual Histologi Kardiovaskular</h3>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Eksplorasi Mikroarsitektur Kardiomiosit: Diskus Interkalaris, Nukleus Sentral, Percabangan & Kapiler Endomisium
          </p>
        </div>

        {/* Lensa Objektif & Stains */}
        <div className="flex items-center gap-3">
          {/* Lenses */}
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
            <span className="text-slate-400 px-2 font-medium">Lensa:</span>
            {[
              { level: 1, label: '10x' },
              { level: 1.8, label: '40x' },
              { level: 3.2, label: '100x Oil' }
            ].map((lens) => (
              <button
                key={lens.label}
                onClick={() => setZoomLevel(lens.level)}
                className={`px-2.5 py-1 rounded font-mono transition-colors ${
                  zoomLevel === lens.level
                    ? 'bg-indigo-600 text-white font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {lens.label}
              </button>
            ))}
          </div>

          {/* Staining Filter */}
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
            <Filter className="w-3.5 h-3.5 text-slate-400 ml-1.5" />
            <span className="text-slate-400 px-1 font-medium">Pewarnaan:</span>
            {[
              { id: 'he', label: 'H&E' },
              { id: 'trichrome', label: 'Masson' },
              { id: 'verhoeff', label: 'Verhoeff' }
            ].map((stain) => (
              <button
                key={stain.id}
                onClick={() => setActiveStain(stain.id as any)}
                className={`px-2.5 py-1 rounded transition-colors ${
                  activeStain === stain.id
                    ? 'bg-slate-800 text-indigo-400 font-bold border border-indigo-500/30'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {stain.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Microscope Viewport & Side Information */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* Microscope Circular Ocular Lens Viewport (7 Cols) */}
        <div className="lg:col-span-7 flex flex-col items-center">
          <div className="relative w-full max-w-lg aspect-square rounded-full border-8 border-slate-950 bg-slate-950 shadow-2xl overflow-hidden ring-4 ring-slate-800/80">
            {/* The Histology Slide Image with Zoom & Filter */}
            <div
              className="w-full h-full transition-transform duration-300 ease-out origin-center cursor-crosshair relative"
              style={{
                transform: `scale(${zoomLevel}) translate(${panPos.x}px, ${panPos.y}px)`,
                filter:
                  activeStain === 'he'
                    ? 'contrast(1.05) saturate(1.1)'
                    : activeStain === 'trichrome'
                    ? 'hue-rotate(180deg) saturate(1.4) contrast(1.15)'
                    : 'grayscale(0.8) contrast(1.4)'
              }}
            >
              <img
                src="/src/assets/images/histology_myocardium_microscope_1791009169554.jpg"
                alt="Histologi Kardiomiosit"
                className="w-full h-full object-cover select-none"
                referrerPolicy="no-referrer"
              />

              {/* Interactive Anatomical Annotation Pins on Slide */}
              {HISTOLOGY_PINS.map((pin) => (
                <button
                  key={pin.id}
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedPin(pin);
                  }}
                  style={{ left: `${pin.coords.x}%`, top: `${pin.coords.y}%` }}
                  className={`absolute -translate-x-1/2 -translate-y-1/2 w-6 h-6 rounded-full flex items-center justify-center transition-all ${
                    selectedPin?.id === pin.id
                      ? 'bg-indigo-600 ring-4 ring-indigo-400/50 scale-125 z-20'
                      : 'bg-rose-600/90 ring-2 ring-white/80 hover:scale-110 z-10'
                  }`}
                  title={pin.name}
                >
                  <span className="w-2 h-2 rounded-full bg-white" />
                </button>
              ))}
            </div>

            {/* Ocular Lens Glass Vignette & Reticle Overlay */}
            <div className="absolute inset-0 pointer-events-none rounded-full shadow-[inset_0_0_80px_rgba(0,0,0,0.85)] border border-slate-700/40" />

            {/* Scale Bar HUD */}
            <div className="absolute bottom-6 left-1/2 -translate-x-1/2 bg-slate-950/80 backdrop-blur-md px-3 py-1 rounded-md border border-slate-700 text-[11px] font-mono text-slate-300 flex items-center gap-2 pointer-events-none">
              <span className="w-12 h-0.5 bg-white inline-block" />
              <span>{zoomLevel === 1 ? '50 μm' : zoomLevel === 1.8 ? '20 μm' : '10 μm'}</span>
            </div>
          </div>

          <div className="flex items-center gap-2 mt-3 text-xs text-slate-400">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span>Klik pin lingkaran di preparat untuk mempelajari struktur histologis mikroskopis</span>
          </div>
        </div>

        {/* Selected Structure Details Panel (5 Cols) */}
        <div className="lg:col-span-5 flex flex-col gap-4">
          {selectedPin ? (
            <div className="bg-slate-950 border border-indigo-500/40 rounded-xl p-5 shadow-xl">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-400">
                    Struktur Teridentifikasi
                  </span>
                  <h4 className="text-base font-bold text-white mt-0.5">{selectedPin.name}</h4>
                </div>
                <div className="w-8 h-8 rounded-lg bg-indigo-950 border border-indigo-500/50 flex items-center justify-center text-indigo-400 font-bold text-xs">
                  {selectedPin.coords.x > 50 ? 'R' : 'L'}
                </div>
              </div>

              <div className="space-y-4 text-xs">
                <div>
                  <h5 className="font-semibold text-slate-300 mb-1">Karakteristik Histologis:</h5>
                  <p className="text-slate-400 leading-relaxed bg-slate-900/60 p-3 rounded-lg border border-slate-800/80">
                    {selectedPin.description}
                  </p>
                </div>

                <div className="bg-indigo-950/40 border border-indigo-500/30 rounded-lg p-3">
                  <div className="flex items-center gap-1.5 text-indigo-300 font-semibold mb-1">
                    <Info className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Korelasi Patologi & Ujian Praktikum:</span>
                  </div>
                  <p className="text-indigo-100/90 leading-relaxed">
                    {selectedPin.clinicalExamPoint}
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-6 text-center text-slate-400 text-xs">
              Pilih salah satu pin pada preparat histologi untuk melihat detail deskripsi mikroskopis.
            </div>
          )}

          {/* Quick Structure Jump List */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-4">
            <span className="text-xs font-semibold text-slate-300 block mb-2">Daftar Struktur Kunci:</span>
            <div className="space-y-1.5">
              {HISTOLOGY_PINS.map((pin) => (
                <button
                  key={pin.id}
                  onClick={() => setSelectedPin(pin)}
                  className={`w-full text-left px-3 py-2 rounded-lg text-xs transition-colors flex items-center justify-between border ${
                    selectedPin?.id === pin.id
                      ? 'bg-slate-800 text-indigo-400 border-indigo-500/40 font-semibold'
                      : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                  }`}
                >
                  <span>{pin.name}</span>
                  <span className="text-[10px] font-mono text-slate-500">Lihat</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
