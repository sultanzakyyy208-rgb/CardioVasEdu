import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Volume2, Info, ChevronRight, Activity } from 'lucide-react';

interface PhaseInfo {
  id: number;
  name: string;
  timeRange: [number, number]; // in seconds (0.0 to 0.8)
  atrialPressure: number;
  lvPressure: number;
  aortaPressure: number;
  lvVolume: number;
  mitralValve: 'Terbuka' | 'Tertutup';
  aortaValve: 'Terbuka' | 'Tertutup';
  heartSound: string;
  ecgEvent: string;
  description: string;
  clinicalSignificance: string;
}

const WIGGERS_PHASES: PhaseInfo[] = [
  {
    id: 1,
    name: '1. Sistol Atrium (Atrial Systole)',
    timeRange: [0.0, 0.1],
    atrialPressure: 10,
    lvPressure: 10,
    aortaPressure: 80,
    lvVolume: 125,
    mitralValve: 'Terbuka',
    aortaValve: 'Tertutup',
    heartSound: 'S4 gallop terdengar jika miokardium kaku',
    ecgEvent: 'Gelombang P (depolarisasi atrium)',
    description: 'Atrium berkontraksi memberikan kontribusi 15-20% pengisian ventrikel akhir (atrial kick) menghasilkan volume akhir diastolik (EDV ~125 mL).',
    clinicalSignificance: 'Pada fibrilasi atrium (AFib), hilangnya sistol atrium menurunkan cardiac output hingga 25%.'
  },
  {
    id: 2,
    name: '2. Kontraksi Isovolumetrik',
    timeRange: [0.1, 0.16],
    atrialPressure: 8,
    lvPressure: 82,
    aortaPressure: 80,
    lvVolume: 125,
    mitralValve: 'Tertutup',
    aortaValve: 'Tertutup',
    heartSound: 'Bunyi Jantung S1 (LUB) - penutupan katup mitral & trikuspid',
    ecgEvent: 'Kompleks QRS (depolarisasi ventrikel)',
    description: 'Ventrikel mulai berkontraksi, tekanan melesat dari 10 mmHg ke 80 mmHg. Karena semua katup tertutup, volume darah tidak berubah (isovolumetrik).',
    clinicalSignificance: 'Fase dengan konsumsi O2 miosit per satuan waktu paling tinggi; sangat rentan mengalami iskemia.'
  },
  {
    id: 3,
    name: '3. Ejeksi Cepat Ventrikel',
    timeRange: [0.16, 0.28],
    atrialPressure: 6,
    lvPressure: 120,
    aortaPressure: 120,
    lvVolume: 75,
    mitralValve: 'Tertutup',
    aortaValve: 'Terbuka',
    heartSound: 'Tidak ada bunyi normal (murmur ejeksi sistolik bila stenosis aorta)',
    ecgEvent: 'Segmen ST (plateau fase 2 potensial aksi)',
    description: 'Tekanan ventrikel melampaui tekanan aorta (80 mmHg) sehingga katup aorta membuka. Sekitar 70% Stroke Volume disemburkan ke aorta.',
    clinicalSignificance: 'Puncak tekanan sistolik dicapai di fase ini (normal ~120 mmHg).'
  },
  {
    id: 4,
    name: '4. Ejeksi Lambat Ventrikel',
    timeRange: [0.28, 0.38],
    atrialPressure: 8,
    lvPressure: 100,
    aortaPressure: 100,
    lvVolume: 55,
    mitralValve: 'Tertutup',
    aortaValve: 'Terbuka',
    heartSound: 'Aliran melambat menuju akhir sistol',
    ecgEvent: 'Gelombang T (repolarisasi ventrikel)',
    description: 'Daya dorong miokardium mulai menurun seiring repolarisasi ventrikel, laju pengosongan darah ke aorta melambat.',
    clinicalSignificance: 'T-inversi atau depresi ST menunjukkan iskemia fase repolarisasi.'
  },
  {
    id: 5,
    name: '5. Relaksasi Isovolumetrik',
    timeRange: [0.38, 0.44],
    atrialPressure: 10,
    lvPressure: 20,
    aortaPressure: 105,
    lvVolume: 55,
    mitralValve: 'Tertutup',
    aortaValve: 'Tertutup',
    heartSound: 'Bunyi Jantung S2 (DUB) - penutupan katup semilunar aorta & pulmonal',
    ecgEvent: 'Akhir gelombang T',
    description: 'Tekanan LV anjlok drastis di bawah tekanan aorta sehingga katup aorta menutup, memicu insisura dikrotik. Semua katup tertutup pada End-Systolic Volume (ESV ~55 mL).',
    clinicalSignificance: 'Splitting S2 fisiologis terjadi saat inspirasi karena keterlambatan penutupan katup pulmonal (P2).'
  },
  {
    id: 6,
    name: '6. Pengisian Cepat Ventrikel',
    timeRange: [0.44, 0.60],
    atrialPressure: 5,
    lvPressure: 5,
    aortaPressure: 90,
    lvVolume: 105,
    mitralValve: 'Terbuka',
    aortaValve: 'Tertutup',
    heartSound: 'Bunyi Jantung S3 (fisiologis pada atlet/anak, patologis pada gagal jantung volume overload)',
    ecgEvent: 'Garis isoelektrik diastolik',
    description: 'Tekanan LV turun di bawah atrium, katup mitral membuka lebar dan darah mengalir deras dari atrium mengisi ventrikel secara pasif.',
    clinicalSignificance: 'S3 gallop menandakan regangan tiba-tiba dinding ventrikel yang dilatasi.'
  },
  {
    id: 7,
    name: '7. Diastasis (Pengisian Lambat)',
    timeRange: [0.60, 0.80],
    atrialPressure: 7,
    lvPressure: 7,
    aortaPressure: 82,
    lvVolume: 115,
    mitralValve: 'Terbuka',
    aortaValve: 'Tertutup',
    heartSound: 'Sunyi / hening diastolik',
    ecgEvent: 'Sebelum gelombang P berikutnya',
    description: 'Pengisian ventrikel melambat seiring penyeimbangan tekanan antara atrium dan ventrikel sebelum kontraksi atrium berikutnya.',
    clinicalSignificance: 'Pada takikardia, fase diastasis inilah yang paling banyak terpangkas, memperpendek waktu perfusi koroner.'
  }
];

export const WiggersSimulator: React.FC = () => {
  const [currentTime, setCurrentTime] = useState<number>(0.2); // 0.0 to 0.8 seconds
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  // Playback timer
  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(() => {
      setCurrentTime((prev) => {
        const next = prev + 0.01;
        return next >= 0.8 ? 0 : Number(next.toFixed(2));
      });
    }, 50);
    return () => clearInterval(interval);
  }, [isPlaying]);

  // Determine current active phase
  const currentPhase = WIGGERS_PHASES.find(
    (p) => currentTime >= p.timeRange[0] && currentTime < p.timeRange[1]
  ) || WIGGERS_PHASES[0];

  // Scrub position in percentage (0 to 100%)
  const scrubPercent = (currentTime / 0.8) * 100;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-2xl flex flex-col gap-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-rose-500" />
            <h3 className="text-lg font-bold text-white tracking-tight">Simulasi Interaktif Diagram Wiggers</h3>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Korelasi Sinkron: Tekanan Aorta, Tekanan Ventrikel Kiri, Tekanan Atrium, Volume Ventrikel, Bunyi Jantung, dan EKG
          </p>
        </div>

        {/* Playback Controls */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold rounded-lg transition-colors shadow"
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            <span>{isPlaying ? 'Jeda' : 'Putar Siklus'}</span>
          </button>
          <button
            onClick={() => setCurrentTime(0.0)}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors border border-slate-800"
            title="Ulang ke Awal Siklus"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
          <div className="text-xs font-mono text-slate-300 bg-slate-950 px-2.5 py-1 rounded border border-slate-800">
            t = <span className="text-rose-400 font-bold tabular-nums">{currentTime.toFixed(2)}</span> s
          </div>
        </div>
      </div>

      {/* Main Interactive Diagram SVG Canvas */}
      <div className="relative bg-slate-950 border border-slate-800 rounded-xl p-4 overflow-hidden">
        {/* Scrub line indicator */}
        <div
          className="absolute top-0 bottom-0 w-0.5 bg-rose-500 z-10 pointer-events-none transition-all duration-75"
          style={{ left: `calc(4rem + ${scrubPercent * 0.88}%)` }}
        >
          <div className="w-2.5 h-2.5 -ml-1 rounded-full bg-rose-500 ring-4 ring-rose-500/20" />
        </div>

        <svg viewBox="0 0 800 360" className="w-full h-72">
          {/* Grid lines */}
          <line x1="60" y1="20" x2="760" y2="20" stroke="#1e293b" strokeDasharray="3 3" />
          <line x1="60" y1="70" x2="760" y2="70" stroke="#1e293b" strokeDasharray="3 3" />
          <line x1="60" y1="120" x2="760" y2="120" stroke="#1e293b" strokeDasharray="3 3" />
          <line x1="60" y1="170" x2="760" y2="170" stroke="#1e293b" strokeDasharray="3 3" />
          <line x1="60" y1="220" x2="760" y2="220" stroke="#1e293b" strokeDasharray="3 3" />
          <line x1="60" y1="290" x2="760" y2="290" stroke="#1e293b" strokeDasharray="3 3" />

          {/* Left Y Axis Labels */}
          <text x="10" y="24" fill="#94a3b8" fontSize="10" fontFamily="monospace">120 mmHg</text>
          <text x="15" y="74" fill="#94a3b8" fontSize="10" fontFamily="monospace">80 mmHg</text>
          <text x="25" y="124" fill="#94a3b8" fontSize="10" fontFamily="monospace">40 mmHg</text>
          <text x="30" y="174" fill="#94a3b8" fontSize="10" fontFamily="monospace">0 mmHg</text>
          <text x="10" y="224" fill="#38bdf8" fontSize="10" fontFamily="monospace">125 mL</text>
          <text x="15" y="255" fill="#38bdf8" fontSize="10" fontFamily="monospace">55 mL</text>
          <text x="25" y="295" fill="#10b981" fontSize="10" fontFamily="monospace">EKG</text>
          <text x="25" y="340" fill="#fbbf24" fontSize="10" fontFamily="monospace">Bunyi</text>

          {/* 1. Left Ventricular Pressure Curve (Red/Crimson) */}
          <path
            d="M 60 165 C 100 165, 140 160, 160 160 C 180 150, 200 40, 240 25 C 280 20, 320 30, 360 60 C 400 90, 420 165, 450 168 C 500 170, 700 165, 760 165"
            fill="none"
            stroke="#ef4444"
            strokeWidth="3"
          />

          {/* 2. Aortic Pressure Curve (Coral / Pink) */}
          <path
            d="M 60 72 C 100 75, 160 78, 200 80 C 230 40, 260 25, 300 30 C 340 40, 380 55, 420 75 L 435 68 L 450 78 C 520 85, 680 75, 760 72"
            fill="none"
            stroke="#f43f5e"
            strokeWidth="2"
            strokeDasharray="4 2"
          />

          {/* 3. Left Atrial Pressure Curve (Purple) */}
          <path
            d="M 60 160 C 80 152, 100 155, 120 162 C 160 158, 220 155, 280 157 C 340 159, 420 150, 460 152 C 540 162, 700 160, 760 160"
            fill="none"
            stroke="#a855f7"
            strokeWidth="1.5"
          />

          {/* 4. Left Ventricular Volume Curve (Blue) */}
          <path
            d="M 60 220 C 100 218, 140 216, 160 215 L 200 215 C 240 230, 300 250, 380 255 L 440 255 C 480 235, 540 222, 620 220 C 700 220, 740 220, 760 220"
            fill="none"
            stroke="#38bdf8"
            strokeWidth="2.5"
          />

          {/* 5. Synchronized ECG Waveform (Emerald) */}
          <path
            d="M 60 290 C 80 290, 88 280, 100 280 C 110 280, 115 290, 140 290 L 150 293 L 160 265 L 170 305 L 180 290 C 230 290, 280 290, 310 290 C 330 278, 360 278, 380 290 L 760 290"
            fill="none"
            stroke="#10b981"
            strokeWidth="2"
          />

          {/* 6. Phonocardiogram Sound Vibrations (Yellow) */}
          {/* S1 */}
          <path d="M 155 335 L 160 325 L 165 345 L 170 330 L 175 340 L 180 335" stroke="#fbbf24" strokeWidth="2" fill="none" />
          <text x="160" y="355" fill="#fbbf24" fontSize="11" fontWeight="bold">S1</text>
          {/* S2 */}
          <path d="M 425 335 L 430 328 L 435 342 L 440 332 L 445 338 L 450 335" stroke="#fbbf24" strokeWidth="2" fill="none" />
          <text x="430" y="355" fill="#fbbf24" fontSize="11" fontWeight="bold">S2</text>

          {/* Vertical phase dividers */}
          <line x1="160" y1="10" x2="160" y2="350" stroke="#334155" strokeWidth="1" strokeDasharray="2 2" />
          <line x1="200" y1="10" x2="200" y2="350" stroke="#334155" strokeWidth="1" strokeDasharray="2 2" />
          <line x1="380" y1="10" x2="380" y2="350" stroke="#334155" strokeWidth="1" strokeDasharray="2 2" />
          <line x1="440" y1="10" x2="440" y2="350" stroke="#334155" strokeWidth="1" strokeDasharray="2 2" />
          <line x1="600" y1="10" x2="600" y2="350" stroke="#334155" strokeWidth="1" strokeDasharray="2 2" />
        </svg>

        {/* Interactive Scrub Slider below diagram */}
        <div className="mt-3 px-2">
          <input
            type="range"
            min="0"
            max="0.8"
            step="0.01"
            value={currentTime}
            onChange={(e) => setCurrentTime(Number(e.target.value))}
            className="w-full accent-rose-500 cursor-pointer h-2 bg-slate-800 rounded-lg"
          />
          <div className="flex justify-between text-[11px] text-slate-500 font-mono mt-1">
            <span>0.0s (Sistol Atrium)</span>
            <span>0.2s (Ejeksi Cepat)</span>
            <span>0.4s (Relaksasi Isovolumetrik)</span>
            <span>0.6s (Pengisian Cepat)</span>
            <span>0.8s (Akhir Diastol)</span>
          </div>
        </div>
      </div>

      {/* Legend & Current Numerical Readings */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
          <span className="text-[11px] text-red-400 font-medium">Tekanan Ventrikel Kiri</span>
          <p className="text-base font-bold text-white font-mono mt-0.5 tabular-nums">{currentPhase.lvPressure} mmHg</p>
        </div>
        <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
          <span className="text-[11px] text-rose-300 font-medium">Tekanan Aorta</span>
          <p className="text-base font-bold text-white font-mono mt-0.5 tabular-nums">{currentPhase.aortaPressure} mmHg</p>
        </div>
        <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
          <span className="text-[11px] text-purple-400 font-medium">Tekanan Atrium Kiri</span>
          <p className="text-base font-bold text-white font-mono mt-0.5 tabular-nums">{currentPhase.atrialPressure} mmHg</p>
        </div>
        <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
          <span className="text-[11px] text-sky-400 font-medium">Volume LV (mL)</span>
          <p className="text-base font-bold text-white font-mono mt-0.5 tabular-nums">{currentPhase.lvVolume} mL</p>
        </div>
        <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
          <span className="text-[11px] text-slate-400 font-medium">Katup Mitral</span>
          <p className={`text-xs font-bold mt-1 ${currentPhase.mitralValve === 'Terbuka' ? 'text-emerald-400' : 'text-slate-400'}`}>
            ● {currentPhase.mitralValve}
          </p>
        </div>
        <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
          <span className="text-[11px] text-slate-400 font-medium">Katup Aorta</span>
          <p className={`text-xs font-bold mt-1 ${currentPhase.aortaValve === 'Terbuka' ? 'text-emerald-400' : 'text-slate-400'}`}>
            ● {currentPhase.aortaValve}
          </p>
        </div>
      </div>

      {/* Active Phase Clinical Rationale Card */}
      <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row gap-4 justify-between items-start">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1.5">
            <span className="px-2 py-0.5 bg-rose-950 text-rose-300 border border-rose-800/60 rounded text-xs font-bold">
              Fase Aktif
            </span>
            <h4 className="text-base font-bold text-white">{currentPhase.name}</h4>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed mb-3">
            {currentPhase.description}
          </p>

          <div className="flex flex-wrap gap-2 text-xs">
            <span className="bg-slate-900 border border-slate-800 px-2 py-1 rounded text-slate-300">
              EKG: <strong className="text-emerald-400">{currentPhase.ecgEvent}</strong>
            </span>
            <span className="bg-slate-900 border border-slate-800 px-2 py-1 rounded text-slate-300">
              Auskultasi: <strong className="text-amber-400">{currentPhase.heartSound}</strong>
            </span>
          </div>
        </div>

        <div className="w-full md:w-72 bg-slate-900/80 border border-amber-500/30 rounded-lg p-3 shrink-0">
          <div className="flex items-center gap-1.5 text-amber-400 text-xs font-bold mb-1">
            <Info className="w-3.5 h-3.5" />
            <span>Mutiara Klinis Ujian UKMPPD</span>
          </div>
          <p className="text-xs text-amber-100/90 leading-relaxed">
            {currentPhase.clinicalSignificance}
          </p>
        </div>
      </div>

      {/* Quick Phase Jump Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-thin">
        {WIGGERS_PHASES.map((p) => (
          <button
            key={p.id}
            onClick={() => setCurrentTime(p.timeRange[0] + 0.02)}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap transition-colors border ${
              currentPhase.id === p.id
                ? 'bg-rose-600 text-white border-rose-500 shadow-sm'
                : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white hover:bg-slate-800'
            }`}
          >
            {p.name.split('(')[0]}
          </button>
        ))}
      </div>
    </div>
  );
};
