import React, { useState } from 'react';
import { Sliders, Activity, Info, RotateCcw, AlertCircle, Heart } from 'lucide-react';

interface PresetCase {
  id: string;
  name: string;
  preload: number; // EDV in mL (80 - 180)
  afterload: number; // Ea in mmHg (60 - 160)
  inotropy: number; // Emax in mmHg/mL (1.0 - 4.0)
  description: string;
}

const PRESETS: PresetCase[] = [
  {
    id: 'normal',
    name: 'Normal Fisiologis',
    preload: 125,
    afterload: 100,
    inotropy: 2.2,
    description: 'Hemodinamika normal istirahat: EDV 125 mL, ESV 50 mL, Stroke Volume 75 mL, Ejection Fraction 60%.'
  },
  {
    id: 'hfref',
    name: 'Gagal Jantung Sistolik (HFrEF)',
    preload: 175,
    afterload: 110,
    inotropy: 1.0,
    description: 'Penurunan drastis kontraktilitas (Emax landai) memicu pergeseran loop ke kanan, ESV meningkat tajam, dan Ejection Fraction turun ke <35%.'
  },
  {
    id: 'hypertension',
    name: 'Hipertensi / Stenosis Aorta',
    preload: 130,
    afterload: 155,
    inotropy: 2.3,
    description: 'Afterload tinggi memaksa ventrikel membangun tekanan puncak hingga 160+ mmHg untuk membuka katup aorta, memperpendek Stroke Volume.'
  },
  {
    id: 'exercise',
    name: 'Latihan Fisik Berat (Sprint)',
    preload: 145,
    afterload: 85,
    inotropy: 3.6,
    description: 'Stimulasi simpatis masif melipatgandakan inotropi (Emax curam) dan venous return, menghasilkan Stroke Volume sangat besar (~100 mL).'
  }
];

export const PvLoopSimulator: React.FC = () => {
  const [preload, setPreload] = useState<number>(125); // EDV
  const [afterload, setAfterload] = useState<number>(100); // peak pressure
  const [inotropy, setInotropy] = useState<number>(2.2); // Emax

  // Calculations:
  // ESV is derived from Emax and Peak Pressure: ESV = PeakPressure / Emax (approx + intercept)
  const esv = Math.max(25, Math.min(preload - 15, Math.round(afterload / inotropy)));
  const strokeVolume = Math.max(10, preload - esv);
  const ejectionFraction = Math.round((strokeVolume / preload) * 100);
  const strokeWork = Math.round((strokeVolume * afterload * 0.0133)); // in Joules/beat approx

  // Convert (volume, pressure) to SVG coordinates:
  // SVG box: 500 wide (0 to 200 mL), 300 high (0 to 200 mmHg)
  const volToX = (v: number) => 60 + (v / 200) * 400;
  const pressToY = (p: number) => 260 - (p / 200) * 230;

  // Key loop points
  // 1: End-Diastole (EDV, EDP ~ 10)
  const p1 = { x: volToX(preload), y: pressToY(10) };
  // 2: Aortic Valve Opens (EDV, Afterload * 0.75)
  const p2 = { x: volToX(preload), y: pressToY(afterload * 0.72) };
  // 3: End-Systole (ESV, Afterload)
  const p3 = { x: volToX(esv), y: pressToY(afterload) };
  // 4: Mitral Valve Opens (ESV, EDP ~ 8)
  const p4 = { x: volToX(esv), y: pressToY(8) };

  // ESPVR line slope (from origin (volToX(10), pressToY(0)) through p3)
  const espvrEndX = volToX(200);
  const espvrEndY = pressToY(inotropy * (200 - 10));

  const applyPreset = (preset: PresetCase) => {
    setPreload(preset.preload);
    setAfterload(preset.afterload);
    setInotropy(preset.inotropy);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-2xl flex flex-col gap-6">
      {/* Top Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-amber-400" />
            <h3 className="text-lg font-bold text-white tracking-tight">Simulasi Interaktif Kurva Tekanan-Volume (PV Loop)</h3>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Analisis Frank-Starling, Hukum Laplace, Preload, Afterload, dan Kontraktilitas Miokardium (ESPVR/EDPVR)
          </p>
        </div>

        {/* Reset button */}
        <button
          onClick={() => applyPreset(PRESETS[0])}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium rounded-lg transition-colors border border-slate-700"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset Normal</span>
        </button>
      </div>

      {/* Preset Buttons */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        <span className="text-xs font-semibold text-slate-400 whitespace-nowrap">Kasus Patologis:</span>
        {PRESETS.map((pr) => (
          <button
            key={pr.id}
            onClick={() => applyPreset(pr)}
            className="px-3 py-1.5 text-xs font-medium rounded-lg bg-slate-950 text-slate-300 border border-slate-800 hover:border-amber-500/50 hover:text-white transition-colors whitespace-nowrap"
          >
            {pr.name}
          </button>
        ))}
      </div>

      {/* Main Grid: Left Diagram (7 cols) + Right Sliders & Metrics (5 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* SVG PV-Loop Canvas (7 cols) */}
        <div className="lg:col-span-7 bg-slate-950 border border-slate-800 rounded-xl p-4 flex flex-col">
          <svg viewBox="0 0 500 300" className="w-full h-72">
            {/* Grid Lines */}
            <line x1="60" y1="30" x2="470" y2="30" stroke="#1e293b" strokeDasharray="3 3" />
            <line x1="60" y1="87" x2="470" y2="87" stroke="#1e293b" strokeDasharray="3 3" />
            <line x1="60" y1="145" x2="470" y2="145" stroke="#1e293b" strokeDasharray="3 3" />
            <line x1="60" y1="202" x2="470" y2="202" stroke="#1e293b" strokeDasharray="3 3" />
            <line x1="60" y1="260" x2="470" y2="260" stroke="#334155" strokeWidth="1.5" />
            <line x1="60" y1="30" x2="60" y2="260" stroke="#334155" strokeWidth="1.5" />

            {/* Axis Ticks & Labels */}
            <text x="25" y="34" fill="#94a3b8" fontSize="10" fontFamily="monospace">200</text>
            <text x="25" y="91" fill="#94a3b8" fontSize="10" fontFamily="monospace">150</text>
            <text x="25" y="149" fill="#94a3b8" fontSize="10" fontFamily="monospace">100</text>
            <text x="32" y="206" fill="#94a3b8" fontSize="10" fontFamily="monospace">50</text>
            <text x="38" y="264" fill="#94a3b8" fontSize="10" fontFamily="monospace">0</text>
            <text x="5" y="145" fill="#e2e8f0" fontSize="10" fontWeight="bold" transform="rotate(-90 20 145)">Tekanan LV (mmHg)</text>

            <text x="60" y="278" fill="#94a3b8" fontSize="10" fontFamily="monospace">0</text>
            <text x="150" y="278" fill="#94a3b8" fontSize="10" fontFamily="monospace">50</text>
            <text x="250" y="278" fill="#94a3b8" fontSize="10" fontFamily="monospace">100</text>
            <text x="350" y="278" fill="#94a3b8" fontSize="10" fontFamily="monospace">150</text>
            <text x="450" y="278" fill="#94a3b8" fontSize="10" fontFamily="monospace">200</text>
            <text x="230" y="295" fill="#e2e8f0" fontSize="10" fontWeight="bold">Volume Ventrikel Kiri (mL)</text>

            {/* ESPVR Line (Slope Emax - Contractility) */}
            <line
              x1={volToX(10)}
              y1={pressToY(0)}
              x2={Math.min(480, espvrEndX)}
              y2={Math.max(20, espvrEndY)}
              stroke="#fbbf24"
              strokeWidth="1.8"
              strokeDasharray="4 3"
            />
            <text x="120" y="45" fill="#fbbf24" fontSize="10" fontWeight="bold">ESPVR (Emax: {inotropy})</text>

            {/* EDPVR Compliance Curve (Bottom Diastolic filling curve) */}
            <path
              d={`M ${volToX(10)} ${pressToY(0)} Q ${volToX(100)} ${pressToY(4)}, ${volToX(190)} ${pressToY(25)}`}
              fill="none"
              stroke="#38bdf8"
              strokeWidth="1.5"
              strokeDasharray="4 3"
            />
            <text x="370" y="240" fill="#38bdf8" fontSize="10">EDPVR</text>

            {/* The PV Loop Polygon */}
            <polygon
              points={`${p1.x},${p1.y} ${p2.x},${p2.y} ${p3.x},${p3.y} ${p4.x},${p4.y}`}
              fill="rgba(244, 63, 94, 0.18)"
              stroke="#f43f5e"
              strokeWidth="2.8"
            />

            {/* Valve Event Markers */}
            {/* Katup Mitral Tutup (Point 1) */}
            <circle cx={p1.x} cy={p1.y} r="4.5" fill="#ef4444" />
            <text x={p1.x + 8} y={p1.y + 4} fill="#fca5a5" fontSize="9" fontWeight="bold">Mitral Tutup (S1)</text>

            {/* Katup Aorta Buka (Point 2) */}
            <circle cx={p2.x} cy={p2.y} r="4.5" fill="#38bdf8" />
            <text x={p2.x + 8} y={p2.y - 2} fill="#bae6fd" fontSize="9" fontWeight="bold">Aorta Buka</text>

            {/* Katup Aorta Tutup (Point 3) */}
            <circle cx={p3.x} cy={p3.y} r="4.5" fill="#fbbf24" />
            <text x={p3.x - 65} y={p3.y - 8} fill="#fde68a" fontSize="9" fontWeight="bold">Aorta Tutup (S2)</text>

            {/* Katup Mitral Buka (Point 4) */}
            <circle cx={p4.x} cy={p4.y} r="4.5" fill="#10b981" />
            <text x={p4.x - 70} y={p4.y + 12} fill="#a7f3d0" fontSize="9" fontWeight="bold">Mitral Buka</text>
          </svg>

          {/* Stroke Work Area note */}
          <div className="mt-2 text-center text-xs text-slate-400">
            Luas area di dalam kurva merah merepresentasikan <strong className="text-white">Stroke Work (Kerja Mekanik Pompa Ventrikel)</strong>.
          </div>
        </div>

        {/* Right: Sliders & Real-Time Hemodynamic Numbers (5 cols) */}
        <div className="lg:col-span-5 flex flex-col gap-4">
          {/* Sliders Container */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 flex flex-col gap-4">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider border-b border-slate-800 pb-2">
              Parameter Kontrol Hemodinamik
            </h4>

            {/* Preload Slider (EDV) */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300 font-medium">Preload (End-Diastolic Volume):</span>
                <span className="font-mono text-sky-400 font-bold tabular-nums">{preload} mL</span>
              </div>
              <input
                type="range"
                min="90"
                max="180"
                value={preload}
                onChange={(e) => setPreload(Number(e.target.value))}
                className="w-full accent-sky-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
              />
              <span className="text-[10px] text-slate-500">Meningkatkan regangan sarkomer ventrikel (Frank-Starling)</span>
            </div>

            {/* Afterload Slider (Peak Pressure) */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300 font-medium">Afterload (Tekanan Sistolik LV):</span>
                <span className="font-mono text-rose-400 font-bold tabular-nums">{afterload} mmHg</span>
              </div>
              <input
                type="range"
                min="70"
                max="160"
                value={afterload}
                onChange={(e) => setAfterload(Number(e.target.value))}
                className="w-full accent-rose-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
              />
              <span className="text-[10px] text-slate-500">Beban resistensi vaskular sistemik (SVR) terhadap ejeksi</span>
            </div>

            {/* Inotropy Slider (Emax) */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300 font-medium">Kontraktilitas (Inotropi / Emax):</span>
                <span className="font-mono text-amber-400 font-bold tabular-nums">{inotropy.toFixed(1)} mmHg/mL</span>
              </div>
              <input
                type="range"
                min="1.0"
                max="3.8"
                step="0.1"
                value={inotropy}
                onChange={(e) => setInotropy(Number(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
              />
              <span className="text-[10px] text-slate-500">Daya pikat Ca2+-troponin miokardium independen dari panjang serat</span>
            </div>
          </div>

          {/* Real-time Hemodynamic Computed Readouts */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-slate-950 border border-slate-800 p-3 rounded-lg">
              <span className="text-[11px] text-slate-400 block">Stroke Volume (SV)</span>
              <p className="text-lg font-bold text-white font-mono mt-0.5 tabular-nums">{strokeVolume} mL</p>
              <span className="text-[10px] text-slate-500">Normal: 60 - 80 mL</span>
            </div>

            <div className="bg-slate-950 border border-slate-800 p-3 rounded-lg">
              <span className="text-[11px] text-slate-400 block">Ejection Fraction (LVEF)</span>
              <p className={`text-lg font-bold font-mono mt-0.5 tabular-nums ${ejectionFraction < 40 ? 'text-rose-400' : 'text-emerald-400'}`}>
                {ejectionFraction}%
              </p>
              <span className="text-[10px] text-slate-500">Normal: 55% - 70%</span>
            </div>

            <div className="bg-slate-950 border border-slate-800 p-3 rounded-lg">
              <span className="text-[11px] text-slate-400 block">End-Systolic Volume (ESV)</span>
              <p className="text-lg font-bold text-slate-200 font-mono mt-0.5 tabular-nums">{esv} mL</p>
              <span className="text-[10px] text-slate-500">Normal: 40 - 55 mL</span>
            </div>

            <div className="bg-slate-950 border border-slate-800 p-3 rounded-lg">
              <span className="text-[11px] text-slate-400 block">Stroke Work Approx</span>
              <p className="text-lg font-bold text-amber-400 font-mono mt-0.5 tabular-nums">{strokeWork} J</p>
              <span className="text-[10px] text-slate-500">Konsumsi Energi Mekanik</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
