import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { 
  User as FirebaseUser,
  onAuthStateChanged,
  signInWithPopup,
  signOut
} from 'firebase/auth';
import { 
  doc, 
  setDoc, 
  getDoc, 
  collection, 
  onSnapshot, 
  deleteDoc,
  serverTimestamp
} from 'firebase/firestore';
import { auth, db, googleProvider, handleFirestoreError, OperationType } from '../firebase';

export interface UserProfile {
  uid: string;
  email: string;
  displayName?: string;
  photoURL?: string;
  role: 'student' | 'lecturer';
  university?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface CbtAttemptRecord {
  id: string;
  userId: string;
  totalQuestions: number;
  answered: number;
  correct: number;
  wrong: number;
  scorePercent: number;
  isPassed: boolean;
  examType: string;
  completedAt: string;
}

export interface SavedNoteRecord {
  id: string;
  userId: string;
  moduleId: string;
  title: string;
  noteContent: string;
  createdAt: string;
  updatedAt: string;
}

interface AuthContextType {
  currentUser: FirebaseUser | null;
  userProfile: UserProfile | null;
  isLoading: boolean;
  signInWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  updateRole: (role: 'student' | 'lecturer') => Promise<void>;
  saveCbtAttempt: (attemptData: {
    totalQuestions: number;
    answered: number;
    correct: number;
    wrong: number;
    scorePercent: number;
    isPassed: boolean;
    examType: string;
  }) => Promise<void>;
  cbtHistory: CbtAttemptRecord[];
  savedNotes: SavedNoteRecord[];
  addSavedNote: (moduleId: string, title: string, noteContent: string) => Promise<void>;
  deleteSavedNote: (noteId: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [cbtHistory, setCbtHistory] = useState<CbtAttemptRecord[]>([]);
  const [savedNotes, setSavedNotes] = useState<SavedNoteRecord[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Monitor Auth State
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        // Fetch or create user profile
        const userDocRef = doc(db, 'users', user.uid);
        try {
          const userSnap = await getDoc(userDocRef);
          if (userSnap.exists()) {
            setUserProfile(userSnap.data() as UserProfile);
          } else {
            const newProfile: UserProfile = {
              uid: user.uid,
              email: user.email || '',
              displayName: user.displayName || 'Mahasiswa Kedokteran',
              photoURL: user.photoURL || '',
              role: 'student',
              university: 'Fakultas Kedokteran',
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString()
            };
            await setDoc(userDocRef, newProfile);
            setUserProfile(newProfile);
          }
        } catch (error) {
          handleFirestoreError(error, OperationType.GET, `users/${user.uid}`);
        }
      } else {
        setUserProfile(null);
        setCbtHistory([]);
        setSavedNotes([]);
      }
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Listen to User CBT Attempts
  useEffect(() => {
    if (!currentUser) return;
    const path = `users/${currentUser.uid}/cbt_attempts`;
    const colRef = collection(db, 'users', currentUser.uid, 'cbt_attempts');

    const unsubscribe = onSnapshot(
      colRef,
      (snapshot) => {
        const records: CbtAttemptRecord[] = [];
        snapshot.forEach((doc) => {
          records.push(doc.data() as CbtAttemptRecord);
        });
        // Sort by completedAt desc
        records.sort((a, b) => new Date(b.completedAt).getTime() - new Date(a.completedAt).getTime());
        setCbtHistory(records);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, path);
      }
    );

    return () => unsubscribe();
  }, [currentUser]);

  // Listen to User Saved Notes
  useEffect(() => {
    if (!currentUser) return;
    const path = `users/${currentUser.uid}/saved_notes`;
    const colRef = collection(db, 'users', currentUser.uid, 'saved_notes');

    const unsubscribe = onSnapshot(
      colRef,
      (snapshot) => {
        const notes: SavedNoteRecord[] = [];
        snapshot.forEach((doc) => {
          notes.push(doc.data() as SavedNoteRecord);
        });
        setSavedNotes(notes);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, path);
      }
    );

    return () => unsubscribe();
  }, [currentUser]);

  const signInWithGoogle = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error('Google Sign-in error:', error);
    }
  };

  const logout = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error('Sign-out error:', error);
    }
  };

  const updateRole = async (role: 'student' | 'lecturer') => {
    if (!currentUser || !userProfile) return;
    const userDocRef = doc(db, 'users', currentUser.uid);
    const updated = {
      ...userProfile,
      role,
      updatedAt: new Date().toISOString()
    };
    try {
      await setDoc(userDocRef, updated, { merge: true });
      setUserProfile(updated);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${currentUser.uid}`);
    }
  };

  const saveCbtAttempt = async (data: {
    totalQuestions: number;
    answered: number;
    correct: number;
    wrong: number;
    scorePercent: number;
    isPassed: boolean;
    examType: string;
  }) => {
    if (!currentUser) return;
    const attemptId = `cbt_${Date.now()}`;
    const docRef = doc(db, 'users', currentUser.uid, 'cbt_attempts', attemptId);
    const record: CbtAttemptRecord = {
      id: attemptId,
      userId: currentUser.uid,
      totalQuestions: data.totalQuestions,
      answered: data.answered,
      correct: data.correct,
      wrong: data.wrong,
      scorePercent: data.scorePercent,
      isPassed: data.isPassed,
      examType: data.examType,
      completedAt: new Date().toISOString()
    };

    try {
      await setDoc(docRef, record);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `users/${currentUser.uid}/cbt_attempts/${attemptId}`);
    }
  };

  const addSavedNote = async (moduleId: string, title: string, noteContent: string) => {
    if (!currentUser) return;
    const noteId = `note_${Date.now()}`;
    const docRef = doc(db, 'users', currentUser.uid, 'saved_notes', noteId);
    const note: SavedNoteRecord = {
      id: noteId,
      userId: currentUser.uid,
      moduleId,
      title,
      noteContent,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    try {
      await setDoc(docRef, note);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `users/${currentUser.uid}/saved_notes/${noteId}`);
    }
  };

  const deleteSavedNote = async (noteId: string) => {
    if (!currentUser) return;
    const docRef = doc(db, 'users', currentUser.uid, 'saved_notes', noteId);
    try {
      await deleteDoc(docRef);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `users/${currentUser.uid}/saved_notes/${noteId}`);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        isLoading,
        signInWithGoogle,
        logout,
        updateRole,
        saveCbtAttempt,
        cbtHistory,
        savedNotes,
        addSavedNote,
        deleteSavedNote
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
