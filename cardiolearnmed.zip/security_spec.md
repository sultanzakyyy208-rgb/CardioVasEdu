# Security Specification for CardioLearnMed

## 1. Data Invariants
1. A user document `/users/{userId}` can only be read or written by the authenticated user whose `request.auth.uid == userId`.
2. A user cannot assign themselves an arbitrary role or spoof another user's identity.
3. Subcollection documents `/users/{userId}/cbt_attempts/{attemptId}` can only be created and read by the owner `userId`.
4. Subcollection documents `/users/{userId}/saved_notes/{noteId}` can only be read, created, updated, or deleted by the owner `userId`.
5. Global catch-all default deny must reject any unmapped path.

## 2. The Dirty Dozen Payloads
1. Create `/users/victim_user` as `attacker_user`: Must be rejected (Identity spoofing).
2. Read `/users/victim_user` as `attacker_user`: Must be rejected (Privacy leak).
3. Create `/users/{userId}/cbt_attempts/attempt1` with negative score or NaN: Must be rejected.
4. Overwrite another user's exam result: Must be rejected.
5. Inject 2MB string into `title` or `noteContent`: Must be rejected by length check.
6. Write to unmapped collection `/secret_data`: Must be rejected by default deny.
7. Unauthenticated read/write to `/users/{userId}`: Must be rejected.
8. Set `userId` in `cbt_attempts` not matching `request.auth.uid`: Must be rejected.
9. Attempt update on immutable `createdAt` timestamp: Must be rejected.
10. Attempt update on immutable `userId`: Must be rejected.
11. Query `/users` without scoping by `request.auth.uid`: Must be rejected.
12. Attempt to write to another user's `saved_notes`: Must be rejected.
